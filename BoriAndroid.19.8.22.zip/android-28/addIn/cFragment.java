package bori.sangdeuk.actionbar;

class cFragment extends cControl
{
    cFragment()
    {
        super(cType.TC_FRAGMENT);
    }
    cFragment(xFragment view0)
    {
        super(cType.TC_FRAGMENT);
        view = view0;
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_VIEW = 0, FNC_COMMAND = 1, FNC_COMMAND_V = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_VIEW:
                    methodName = "setView";
                    f_setView((cFragment) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_COMMAND:
                    methodName = "command";
                    f_command((cFragment) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_COMMAND_V:
                    methodName = "command";
                    f_commandVars((cFragment) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cVars) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Fragment." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setView(cFragment frag, cString viewFile)
    {
        ((xFragment)frag.view).loadView(viewFile.text);
    }
    private static void f_command(cFragment frag, cString message) throws Exception
    {
        ((xFragment)frag.view).command(message.text, null);
    }
    private static void f_commandVars(cFragment frag, cString message, cVars vars) throws Exception
    {
        ((xFragment)frag.view).command(message.text, vars);
    }
}
