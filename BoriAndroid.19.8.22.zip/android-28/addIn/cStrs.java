package com.sangdeuk.fragment1;

import java.util.ArrayList;
import java.util.Random;

class cStrs extends cVar
{
    private ArrayList<String> list_;

    cStrs()
    {
        super(cType.TSTRS);
        list_ = new ArrayList<>();
    }
    cStrs(cStrs ss)
    {
        super(cType.TSTRS);
        list_ = new ArrayList<>();
        copyFrom(ss);
    }
    cStrs(String[] arr)
    {
        super(cType.TSTRS);
        list_ = new ArrayList<>();
        for (String s : arr) list_.add(s);
    }

    private int count () { return list_.size(); }
    void add(String s) { list_.add(s); }
    String get(int index) { return list_.get(index); }
    private void replace(int index, String s) { list_.set(index, s); }
    String[] getStringArray()
    {
        final String[] arr = new String[list_.size()];
        int index = 0;
        for (final String value : list_)
        {
            arr[index++] = value;
        }
        return arr;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cStrs)
        {
            cStrs src = (cStrs)var;
            for (String s : src.list_) list_.add(s);
        }
    }
    @Override
    public void clear()
    {
        list_.clear();
    }
    @Override
    public String toString()
    {
        int ct = list_.size();
        if (ct < 1)
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append("\"");
            sb.append(list_.get(i));
            sb.append("\"");
        }
        sb.append(" ]");
        return new String(sb);
    }

    private void shuffleSelf()
    {
        int ct = list_.size();
        Random random = new Random();
        for (int i = ct - 1; i > 0; i--)
        {
            int r = random.nextInt(i+1);
            if (r != i)
            {
                String temp = get(i);
                replace(i, get(r));
                replace(r, temp);
            }
        }
    }

    private String mergeAll(String sep)
    {
        int ct = list_.size();
        if (ct < 1)
            return "";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(sep);
            sb.append(list_.get(i));
        }
        return new String(sb);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_TEXT = 2, FNC_SHUFFLE = 3,
            FNC_REPLACE = 4, FNC_CLEAR = 5, FNC_SWAP = 6, FNC_MERGE_ALL = 7;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_ADD: f_add((cStrs)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_COUNT: f_count(ret, (cStrs)stack.get(ct-1).var); break;
            case FNC_TEXT: f_getText(ret, (cStrs)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_SHUFFLE: f_shuffle(ret, (cStrs)stack.get(ct-1).var); break;
            case FNC_REPLACE: f_replace((cStrs)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_CLEAR: f_clear((cStrs)stack.get(ct-1).var); break;
            case FNC_SWAP: f_swap((cStrs)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_MERGE_ALL: f_mergeAll(ret, (cStrs)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Strs class method:" + nfunc);
        }
    }

    private static void f_add (cStrs strs, cString text)
    {
        strs.list_.add(text.text);
    }
    private static void f_count (_Container ret, cStrs strs)
    {
        ret.var = new cInt(strs.count());
    }
    private static void f_getText (_Container ret, cStrs strs, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(strs.list_, index, "Strs.getText");
        ret.var = new cString(strs.list_.get(index));
    }
    private static void f_shuffle (_Container ret, cStrs ss)
    {
        cStrs ss2 = new cStrs(ss);
        ss2.shuffleSelf();
        ret.var = ss2;
    }
    private static void f_replace (cStrs ss, cInt n, cString value) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(ss.list_, index, "Strs.replace");
        ss.list_.set(index, value.text);
    }
    private static void f_clear (cStrs list) { list.list_.clear(); }
    private static void f_swap (cStrs list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1, "Ints.swap");
        _Util.checkIndex(list.list_, index2, "Ints.swap");
        String text = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, text);
    }
    private static void f_mergeAll (_Container ret, cStrs ss, cString sep)
    {
        ret.var = new cString(ss.mergeAll(sep.text));
    }
}
