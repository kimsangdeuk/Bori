package com.sangdeuk.fragment1;

import android.graphics.Paint;

class cPaint extends cVar
{
    Paint paint_;
    static final int FILL = 1, STROKE = 2;

    cPaint()
    {
        super(cType.TPAINT);
        paint_ = new Paint();
    }
    cPaint(Paint paint)
    {
        super(cType.TPAINT);
        paint_ = paint;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cPaint)
        {
            cPaint src = (cPaint)var;
            paint_ = src.paint_;
        }
    }

    //-----------------------------------------------------------
    private static final int FLD_FILL = 0, FLD_STROKE = 1;
    static void getVar(int n, _Container ret, _Container con)
    {
        switch(n)
        {
            case FLD_FILL: ret.var = new cInt(FILL); break;
            case FLD_STROKE: ret.var = new cInt(STROKE); break;
        }
    }

    //-----------------------------------------------------------
    private static final int FNC_SET_COLOR = 0, FNC_SET_STROKE_WIDTH = 1,
        FNC_SET_TEXT_SIZE = 2, FNC_SET_STYLE = 3, FNC_MEASURE_TEXT = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_COLOR: f_setColor((cPaint)stack.get(ct-2).var, (cColor)stack.get(ct-1).var); break;
            case FNC_SET_STROKE_WIDTH: f_setStrokeWidth((cPaint)stack.get(ct-2).var, (cDouble)stack.get(ct-1).var); break;
            case FNC_SET_TEXT_SIZE: f_setTextSize((cPaint)stack.get(ct-2).var, (cDouble)stack.get(ct-1).var); break;
            case FNC_SET_STYLE: f_setStyle((cPaint)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_MEASURE_TEXT: f_measureText(ret, (cPaint)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Paint class method:" + nfunc);
        }
    }

    private static void f_setColor(cPaint paint, cColor color)
    {
        paint.paint_.setColor(color.intValue());
    }
    private static void f_setStrokeWidth(cPaint paint, cDouble width)
    {
        paint.paint_.setStrokeWidth((float)width.value);
    }
    private static void f_setTextSize(cPaint paint, cDouble size)
    {
        paint.paint_.setTextSize((float)size.value);
    }
    private static void f_setStyle(cPaint paint, cInt options)
    {
        Paint.Style style;
        if ((options.value & FILL) != 0 && (options.value & STROKE) != 0)
            style = Paint.Style.FILL_AND_STROKE;
        else if ((options.value & FILL) != 0)
            style = Paint.Style.FILL;
        else if ((options.value & STROKE) != 0)
            style = Paint.Style.STROKE;
        else
            return;

        paint.paint_.setStyle(style);
    }
    private static void f_measureText(_Container ret, cPaint paint, cString text)
    {
        ret.var = new cDouble(paint.paint_.measureText(text.text));
    }
}
