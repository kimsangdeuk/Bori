package bori.sangdeuk.test;

import android.graphics.Canvas;
import android.support.v7.widget.LinearLayoutCompat;

import org.w3c.dom.Node;

class xLinearLayout extends LinearLayoutCompat
{
    _BoriView boriview_;
    private boolean fullFrame_;
    private String methodOnSizeChanged_ = null;
    private String methodOnDraw_ = null;
    private _ConList paramsDraw;

    xLinearLayout(_BoriView boriview, boolean fullFrame)
    {
        super(boriview.bori);
        boriview_ = boriview;
        fullFrame_ = fullFrame;

        paramsDraw = new _ConList();
        paramsDraw.add(new _Container(new cCanvas()));
    }

    void setStyle(Node node)
    {
        _Xml.setViewStyle(this, _Xml.getChildElement(node, "style"));
    }

    void setSizeChangedMethod(String method) { methodOnSizeChanged_= method; }
    void setDrawMethod(String method) { methodOnDraw_= method; }
    void setTouchMethod(String method) { _Tag.get(this).setOnTouch(method); }
    void setClickMethod(String method) { _Tag.get(this).setOnClick(method); }
    void setLongClickMethod(String method) { _Tag.get(this).setOnLongClick(method); }

    @Override
    protected void onMeasure (int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int w = getMeasuredWidth();
        int h = getMeasuredHeight();
        if (fullFrame_)
        {
            int vh = boriview_.bori.getViewHeight();
            if (h < vh)
                h = vh;
        }
        setMeasuredDimension(w, h);
    }
    @Override
    protected void onSizeChanged (int w, int h, int oldw, int oldh)
    {
        if (methodOnSizeChanged_ != null)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cInt(w)));
            params.add(new _Container(new cInt(h)));
            boriview_.call(methodOnSizeChanged_, params);
        }
    }
    @Override
    protected void onDraw (Canvas canvas)
    {
        if (methodOnDraw_ != null)
        {
            _Container con = paramsDraw.get(0);
            ((cCanvas)con.var).set(canvas);
            boriview_.call(methodOnDraw_, paramsDraw);
        }
    }
}
