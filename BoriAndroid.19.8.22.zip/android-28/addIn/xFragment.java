package bori.sangdeuk.actionbar;

import android.support.v4.app.FragmentTransaction;
import android.widget.FrameLayout;

import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.HashMap;

class xFragment extends FrameLayout
{
    private _BoriView boriview_;
    private _Fragment curFragment_ = null;

    xFragment (BoriActivity bori) { super(bori); }
    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
    }

    void loadView(String viewName)
    {
        _Fragment fragment = _Fragment.newInstance(viewName, boriview_);
        FragmentTransaction t = boriview_.bori.getSupportFragmentManager().beginTransaction();
        if (curFragment_ != null)
            t.remove(curFragment_);
        t.add(getId(), fragment);
        t.commit();

        curFragment_ = fragment;
    }

    void command(String message, cVars vars) throws Exception
    {
        if (curFragment_ != null)
            curFragment_.command(message, vars);
    }
}

