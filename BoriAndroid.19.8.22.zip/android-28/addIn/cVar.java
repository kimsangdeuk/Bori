package com.sangdeuk.fragment1;

class cVar
{
    int type;

    cVar()
    {
        type = cType.TVAR;
    }
    cVar(int type0)
    {
        type = type0;
    }

    public int getType() { return type; }

    public void copyFrom(cVar var) { }
    public void clear() { }
    public boolean isTrue() { return false; }
    public boolean isNull() { return false; }
    @Override
    public String toString() { return ""; }

    //--------------------------------------------------------------------------------------
    private static final int FNC_VAR_TOSTRING = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_VAR_TOSTRING: f_toString(ret, (cVar)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Var class method:" + nfunc);
        }
    }

    private static void f_toString(_Container ret, cVar var)
    {
        ret.var = new cString(var.toString());
    }
}
