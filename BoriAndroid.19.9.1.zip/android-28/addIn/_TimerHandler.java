package bori.android.timer_clock;

import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;

class _TimerHandler extends Handler
{
    private _BoriView boriview_;
    private final _Timer timer_;
    private String	name_;
    private final long interval_;
    private int	repeat_;
    private boolean	infinite_;
    private boolean	canceled_;
    private final int MSG = 1;

    _TimerHandler(_BoriView view, _Timer timer, String name, long interval, int repeat)
    {
        boriview_ = view;
        timer_ = timer;
        name_ = name;
        interval_ = interval;
        repeat_ = repeat;
        infinite_ = (repeat_ < 1);
        canceled_  = true;
    }

    @Override
    public void handleMessage(Message msg)
    {
        if (canceled_)
            return;

        synchronized (timer_)
        {
            long lastTickStart = SystemClock.elapsedRealtime();
            onTick();

            if (! infinite_)
            {
                repeat_--;
                if (repeat_ < 1)
                    return;
            }

            // take into account user's onTick taking time to execute
            long delay = lastTickStart + interval_ - SystemClock.elapsedRealtime();

            // special case: user's onTick took more than interval to complete, skip to next interval
            while (delay < 0)
                delay += interval_;

            sendMessageDelayed(obtainMessage(MSG), delay);
        }
    }

    void start()
    {
        canceled_ = false;
        sendMessageDelayed(obtainMessage(MSG), interval_);
    }

    private void onTick ()
    {
        boriview_.onTimer(name_);
    }

    void cancel()
    {
        canceled_  = true;
        removeMessages(MSG);
    }

}
