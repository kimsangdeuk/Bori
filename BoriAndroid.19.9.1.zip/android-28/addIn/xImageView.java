package bori.sangdeuk.rotation;

import android.content.Context;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.widget.ImageView;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xImageView extends AppCompatImageView
{
    private _BoriView boriview_;

    public xImageView (Context context) { super(context); }
    public xImageView (Context context, AttributeSet attrs) { super(context, attrs); }

    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        _Xml.setViewStyle(this, node);

        String text;
        text = _Xml.getAttributeValue(node, "image");
        if (!text.isEmpty())
            setImageDrawable(_Util.getDrawable(boriview_.bori, text));

        text = _Xml.getAttributeValue(node, "scaleType");
        try
        {
            if (!text.isEmpty())
                setScaleType(text);
        }
        catch(Exception e)
        {
            _Alert.show(boriview_.bori, "Error", "> ImageView setStyle\n" + e.getMessage());
        }
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            switch (name)
            {
                case "onClick": _Tag.get(this).setOnClick(method); break;
                case "onLongClick": _Tag.get(this).setOnLongClick(method); break;
                case "onTouch": _Tag.get(this).setOnTouch(method); break;
            }
        }
    }

    void setScaleType(String stype) throws Exception
    {
        ImageView.ScaleType type;
        switch(stype)
        {
            case "center": type = ImageView.ScaleType.CENTER; break;
            case "centerCrop": type = ImageView.ScaleType.CENTER_CROP; break;
            case "centerInside": type = ImageView.ScaleType.CENTER_INSIDE; break;
            case "fitCenter": type = ImageView.ScaleType.FIT_CENTER; break;
            case "fitEnd": type = ImageView.ScaleType.FIT_END; break;
            case "fitStart": type = ImageView.ScaleType.FIT_START; break;
            case "fitXY": type = ImageView.ScaleType.FIT_XY; break;
            case "matrix": type = ImageView.ScaleType.MATRIX; break;
            default: throw new Exception("Invalid scale type: " + stype);
        }
        setScaleType(type);
    }
}
