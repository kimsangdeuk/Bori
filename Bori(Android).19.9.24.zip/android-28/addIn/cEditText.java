package bori.sangdeuk.file_memo;

import android.text.InputFilter;

class cEditText extends cControl
{
    cEditText()
    {
        super(cType.TC_EDIT);
    }
    cEditText(xEditText view_)
    {
        super(cType.TC_EDIT);
        view = view_;
    }

    String getText()
    {
        return ((xEditText)view).getText().toString();
    }
    void setText(String text) { ((xEditText)view).setTextLimit(text); }

    //---------------------------------------------------------------------
    private static final int FNC_SET_TEXT = 0, FNC_GET_TEXT = 1, FNC_SELECT_ALL = 2,
    FNC_SELECT = 3, FNC_SELECT2 = 4, FNC_SET_FOCUS = 5, FNC_LIMIT_LENGTH = 6, FNC_LIMIT_LINES = 7;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_TEXT:
                    methodName = "setText";
                    f_setText((cEditText) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TEXT:
                    methodName = "getText";
                    f_getText(ret, (cEditText) stack.get(ct - 1).var);
                    break;
                case FNC_SELECT_ALL:
                    methodName = "selectAll";
                    f_selectAll((cEditText) stack.get(ct - 1).var);
                    break;
                case FNC_SELECT:
                    methodName = "select";
                    f_select((cEditText) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SELECT2:
                    methodName = "select";
                    f_select2((cEditText) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET_FOCUS:
                    methodName = "setFocus";
                    f_setFocus((cEditText) stack.get(ct - 1).var);
                    break;
                case FNC_LIMIT_LENGTH:
                    methodName = "limitLength";
                    f_limitLength((cEditText) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_LIMIT_LINES:
                    methodName = "limitLines";
                    f_limitLines((cEditText) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> EditText." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setText(cEditText edit, cString s)
    {
        String newText = s.text;
        if (newText.equals(edit.getText()))
            return;
        edit.setText(newText);
    }

    private static void f_getText(_Container ret, cEditText edit)
    {
        ret.var = new cString();
        ((cString)ret.var).set(edit.getText());
    }
    private static void f_selectAll(cEditText edit)
    {
        ((xEditText)edit.view).setSelectAllOnFocus(true);
    }
    private static void f_select(cEditText edit, cInt pos)
    {
        ((xEditText)edit.view).setSelection((int)pos.value - _Env.iBase);
    }
    private static void f_select2(cEditText edit, cInt start, cInt end)
    {
        ((xEditText)edit.view).setSelection((int)start.value - _Env.iBase, (int)end.value - _Env.iBase);
    }
    private static void f_setFocus(cEditText edit)
    {
        ((xEditText)edit.view).requestFocus();
    }
    private static void f_limitLength(cEditText edit, cInt length)
    {
        ((xEditText)edit.view).setFilters(new InputFilter[] {new InputFilter.LengthFilter((int)length.value)});
    }
    private static void f_limitLines(cEditText edit, cInt lines)
    {
        ((xEditText)edit.view).limitLines((int)lines.value);
    }
}
