package bori.sangdeuk.tablayout_viewpager;

class cTabLayout extends cControl
{
    cTabLayout()
    {
        super(cType.TC_TABLAYOUT);
    }
    cTabLayout(xTabLayout view0)
    {
        super(cType.TC_TABLAYOUT);
        view = view0;
    }

    //---------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_ADD_ICON = 1, FNC_REMOVE = 2, FNC_CLEAR = 3, FNC_COUNT = 4,
            FNC_SET_TAB_BACK_COLORS = 5, FNC_SET_TAB_TEXT_COLORS = 6, FNC_SET_TAB_ICON_COLORS = 7,
            FNC_SET_INDICATOR_COLOR = 8, FNC_HIDE_INDICATOR = 9,
            FNC_GET_TEXT = 10, FNC_SYNC_WITH_VIEWPAGER = 11,
            FNC_SET_CUR_ITEM = 12, FNC_SET_CUR_ITEM2 = 13;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_addItem((cTabLayout) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_ICON:
                    methodName = "add";
                    f_addItemIcon((cTabLayout)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE:
                    methodName = "remove";
                    f_removeItem((cTabLayout) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cTabLayout) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cTabLayout) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TAB_BACK_COLORS:
                    methodName = "setTabBackColors";
                    f_setBackColors((cTabLayout) stack.get(ct - 3).var, (cColor) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TAB_TEXT_COLORS:
                    methodName = "setTabTextColors";
                    f_setTextColors((cTabLayout) stack.get(ct - 3).var, (cColor) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TAB_ICON_COLORS:
                    methodName = "setTabIconColors";
                    f_setIconColors((cTabLayout) stack.get(ct - 3).var, (cColor) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_SET_INDICATOR_COLOR:
                    methodName = "setIndicatorColor";
                    f_setIndicatorColor((cTabLayout) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_HIDE_INDICATOR:
                    methodName = "hideIndicator";
                    f_hideIndicator((cTabLayout) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TEXT:
                    methodName = "getText";
                    f_getItemText(ret, (cTabLayout) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SYNC_WITH_VIEWPAGER:
                    methodName = "syncWithViewPager";
                    f_syncWithViewPager((cTabLayout) stack.get(ct - 2).var, (cViewPager) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CUR_ITEM:
                    methodName = "setCurItem";
                    f_setCurItem((cTabLayout) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CUR_ITEM2:
                    methodName = "setCurItem";
                    f_setCurItem2((cTabLayout) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> TabLayout." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_addItem(cTabLayout tabs, cString name) throws Exception
    {
        ((xTabLayout)tabs.view).addItem(name.text, null);
    }
    private static void f_addItemIcon(cTabLayout tabs, cString name, cString iconName) throws Exception
    {
        ((xTabLayout)tabs.view).addItem(name.text, iconName.text);
    }
    private static void f_removeItem(cTabLayout tabs, cInt index)
    {
        ((xTabLayout)tabs.view).removeTabAt((int)index.value - _Env.iBase);
    }
    private static void f_clear(cTabLayout tabs)
    {
        ((xTabLayout)tabs.view).removeAllTabs();
    }
    private static void f_count(_Container ret, cTabLayout tabs)
    {
        ret.var = new cInt(((xTabLayout)tabs.view).getTabCount());
    }
    private static void f_setBackColors(cTabLayout tabs, cColor normal, cColor sel)
    {
        ((xTabLayout)tabs.view).setBackColors(normal.intValue(), sel.intValue());
    }
    private static void f_setTextColors(cTabLayout tabs, cColor normal, cColor sel)
    {
        ((xTabLayout)tabs.view).setTextColors(normal.intValue(), sel.intValue());
    }
    private static void f_setIconColors(cTabLayout tabs, cColor normal, cColor sel)
    {
        ((xTabLayout)tabs.view).setIconColors(normal.intValue(), sel.intValue());
    }
    private static void f_setIndicatorColor(cTabLayout tabs, cColor color)
    {
        ((xTabLayout)tabs.view).setSelectedTabIndicatorColor(color.intValue());
    }
    private static void f_hideIndicator(cTabLayout tabs)
    {
        ((xTabLayout)tabs.view).hideIndicator();
    }
    private static void f_getItemText(_Container ret, cTabLayout tabs, cInt index) throws Exception
    {
        ret.var = new cString(((xTabLayout)tabs.view).getItemText((int)index.value - _Env.iBase));
    }
    private static void f_syncWithViewPager(cTabLayout tabs, cViewPager viewpager)
    {
        xViewPager pager = viewpager.getViewPager();
        xTabLayout tablayout = (xTabLayout)tabs.view;
        pager.syncWithTabs(tablayout);
        tablayout.syncWithViewPager(pager);
    }
    private static void f_setCurItem(cTabLayout tabs, cString name)
    {
        ((xTabLayout)tabs.view).selectTabIndex(name.text);
    }
    private static void f_setCurItem2(cTabLayout tabs, cInt index)
    {
        ((xTabLayout)tabs.view).selectTabIndex((int)index.value - _Env.iBase);
    }
}
