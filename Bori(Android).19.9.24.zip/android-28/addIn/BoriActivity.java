package bori.sangdeuk.db_memo;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Point;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.widget.ScrollView;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

class BoriActivity extends AppCompatActivity
{
    _BoriView boriview = null;
    private Node nodeBori_;
    private boolean isStatusVisible_;
    private int screenWidth_;
    private int screenHeight_;
    private Bundle prefs_;
    private boolean prefsChanged_ = false;
    private DrawerLayout drawer_;
    private NavigationView navigationView_;
    private int orientation_;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        _Util.myContext = getApplicationContext();

        try
        {
            _setBoriContentView(savedInstanceState);
        }
        catch (Exception e)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Exception");
            builder.setMessage(e.getMessage());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int id)
                        {
                            finish();
                        }
                    }
            );
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
    @Override
    protected void onStart()
    {
        super.onStart();
        boriview.onStart();
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        boriview.onResume();
    }
    @Override
    public void onBackPressed( )
    {
        if (! boriview.onBackPressed())
            finish();
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        boriview.onPause();
        savePrefs();
    }
    @Override
    protected void onStop()
    {
        super.onStop();
        boriview.onStop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        boriview.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);

        if (newConfig.orientation != orientation_)
        {
            calcScreenSize();
            boriview.onOrientationChanged();
        }
    }

    private void _setBoriContentView (Bundle savedInstanceState) throws Exception
    {
        boriview = null;

        // read project.xml
        InputStream in = getAssets().open("project.xml");
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = builder.parse(in, null);
        in.close();
        nodeBori_ = doc.getElementsByTagName("Bori").item(0);

        ActivityInfo ai = getPackageManager().getActivityInfo(getComponentName(), PackageManager.GET_META_DATA);
        Bundle aBundle = ai.metaData;
        String viewNeeded = aBundle.getString("viewfile");

        // view attributes
        isStatusVisible_ = false;

        Node nodeView = findView(viewNeeded);
        if (nodeView == null)
            throw new Exception("Can not find the view: " + viewNeeded);
        Node nodeWindow = _Xml.getChildElement(nodeView, "window");
        if (nodeWindow != null)
        {
            String s = _Xml.getAttributeValue(nodeWindow, "showStatus");
            if (s.equals("true"))
                isStatusVisible_ = true;
            s = _Xml.getAttributeValue(nodeWindow, "orientation");
            if (s.equals("portrait"))
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            else if (s.equals("landscape"))
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }

        calcScreenSize();

        drawer_ = new DrawerLayout(this);
        drawer_.setLayoutParams(new DrawerLayout.LayoutParams(DrawerLayout.LayoutParams.MATCH_PARENT, DrawerLayout.LayoutParams.MATCH_PARENT));
        drawer_.setFitsSystemWindows(true);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.MATCH_PARENT));

        // set content view
        boriview = new _BoriView(this, this, true);
        boriview.init(viewNeeded);
        scroll.addView(boriview.getLayout());

        drawer_.addView(scroll); //linear);
        setContentView(drawer_);
        boriview.onCreate(savedInstanceState, null);
    }

    void closeDrawers()
    {
        drawer_.closeDrawers();
    }
    void openDrawer(NavigationView nv)
    {
        drawer_.openDrawer(nv); //GravityCompat.START);
    }
    void attachNavigationView(NavigationView nv)
    {
        if (navigationView_ != null)
            drawer_.removeView(navigationView_);
        drawer_.addView(nv);
        navigationView_ = nv;
    }

    //-------------------------------------------------------------------
    private void calcScreenSize()
    {
        Display display = getWindowManager().getDefaultDisplay();
        Point size1 = new Point();
        display.getSize(size1);
        screenWidth_ = size1.x;
        screenHeight_ = size1.y;
        if (screenWidth_ > screenHeight_)
            orientation_ = Configuration.ORIENTATION_LANDSCAPE;
        else
            orientation_ = Configuration.ORIENTATION_PORTRAIT;

        if (isStatusVisible_)
            screenHeight_ -= getStatusBarHeight();
    }

    private int getStatusBarHeight()
    {
        //http://mrtn.me/blog/2012/03/17/get-the-height-of-the-status-bar-in-android/
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0)
        {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    int getScreenWidth() { return screenWidth_; }
    int getScreenHeight() { return screenHeight_; }

    //-------------------------------------------------------------------
    Node findView (String filename)
    {
        if (filename == null)
            return null;

        NodeList nlView = nodeBori_.getChildNodes();
        for (int i = 0, count = nlView.getLength(); i < count; i++)
        {
            Node node = nlView.item(i);
            if (node.getNodeName().equals("view"))
            {
                String viewname = _Xml.getAttributeValue(node, "name");
                if (viewname.equals(filename))
                    return node;
            }
        }
        return null;
    }

    //------------------------------------------------------------------
    Bundle getPrefs()
    {
        if (prefs_ == null)
        {
            prefs_ = new Bundle();

            SharedPreferences sp = getSharedPreferences(getPackageName(), 0);
            Map<String, ?> map = sp.getAll();
            for (String key : map.keySet())
            {
                Object obj = map.get(key);
                if (obj instanceof String)
                    prefs_.putString(key, (String) obj);
                else if (obj instanceof Integer) // for TBOOL
                {
                    int n = (Integer)obj;
                    prefs_.putByte(key, (byte)n);
                }
                else if (obj instanceof Long) // for TBIGINT, TDOUBLE
                    prefs_.putLong(key, (Long) obj);
            }
        }
        return prefs_;
    }
    void prefsChanged()
    {
        prefsChanged_ = true;
    }
    private void savePrefs()
    {
        if (! prefsChanged_)
            return;

        SharedPreferences sp = getSharedPreferences(getPackageName(), 0);
        SharedPreferences.Editor editor = sp.edit();
        for (String key : prefs_.keySet())
        {
            Object obj = prefs_.get(key);
            if (obj instanceof String)
                editor.putString(key, (String) obj);
            else if (obj instanceof Byte) // for TBOOL
                editor.putInt(key, (Byte) obj);
            else if (obj instanceof Long) // for TBIGINT, TDOUBLE
                editor.putLong(key, (Long) obj);
        }
        editor.apply();
        prefsChanged_ = false;
        prefs_ = null;
    }
}
