package bori.sangdeuk.spinner;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.AdapterView;
import android.support.v7.widget.AppCompatSpinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xSpinner extends AppCompatSpinner
{
    private _BoriView boriview_;
    private int textUnit_;
    private Float textSize_ = null;
    private Integer textColor_ = null;

    public xSpinner (Context context) { super(context); }
    public xSpinner (Context context, AttributeSet attrs) { super(context, attrs); }
    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);

        String sunit = _Xml.getAttributeValue(node, "textSizeUnit");
        if (sunit.equals("dp"))
            textUnit_ = TypedValue.COMPLEX_UNIT_DIP;
        else
            textUnit_ = TypedValue.COMPLEX_UNIT_SP;

        String size = _Xml.getAttributeValue(node, "textSize");
        if (! size.equals(""))
            textSize_ = Float.parseFloat(size);

        String color = _Xml.getAttributeValue(node, "textColor");
        if (! color.equals(""))
            textColor_ = Color.parseColor(color);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onSelected"))
            {
                final String methodOnClick = _Xml.getAttributeValue(node, "method");
                if (!methodOnClick.isEmpty())
                {
                    setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
                    {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                        {
                            if (textColor_ != null)
                                ((TextView) parent.getChildAt(0)).setTextColor(textColor_);
                            if (textSize_ != null)
                                ((TextView) parent.getChildAt(0)).setTextSize(textUnit_, textSize_);

                            _ConList params = new _ConList();
                            params.add(new _Container(new cInt(position + _Env.iBase)));
                            boriview_.call(methodOnClick, params);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent)
                        {

                        }
                    });
                }
            }
        }
    }
    void setItems(String[] items)
    {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(boriview_.bori, android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        setAdapter(adapter);
    }
    String getText()
    {
        TextView tv = (TextView)getSelectedView();
        return tv.getText().toString();
    }
}

