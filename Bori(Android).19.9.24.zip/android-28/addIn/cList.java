package bori.sangdeuk.arraytest;

import java.util.ArrayList;
import java.util.Collections;

class cList extends cVar
{
    ArrayList<cVar> list_;

    cList()
    {
        super(cType.TLIST);
        list_ = new ArrayList<>();
    }
    cList(ArrayList<cVar> list)
    {
        super(cType.TLIST);
        list_ = new ArrayList<>(list);
    }

    int count () { return list_.size(); }

    void add(cVar var)
    {
        list_.add(var);
    }

    @Override
    public void clear()
    {
        list_.clear();
    }

    cVar get(int n)
    {
        return list_.get(n);
    }
    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_GET = 2, FNC_CLEAR = 3,
            FNC_SWAP = 4, FNC_REVERSE = 5, FNC_REMOVE = 6;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add((cList) stack.get(ct - 2).var, (cVar) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cList) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_get(ret, (cList) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cList) stack.get(ct - 1).var);
                    break;
                case FNC_SWAP:
                    methodName = "swap";
                    f_swap((cList) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_REVERSE:
                    methodName = "reverse";
                    f_reverse(ret, (cList) stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE:
                    methodName = "remove";
                    f_remove((cList) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> List." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add (cList list, cVar var)
    {
        list.list_.add(var);
    }
    private static void f_count (_Container ret, cList list)
    {
        ret.var = new cInt(list.list_.size());
    }
    private static void f_get (_Container ret, cList list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index);
        ret.var = list.list_.get(index);
    }
    private static void f_clear (cList list) { list.list_.clear(); }
    private static void f_swap (cList list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1);
        _Util.checkIndex(list.list_, index2);
        cVar var = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, var);
    }
    private static void f_reverse (_Container ret, cList list)
    {
        ArrayList<cVar> listNew = new ArrayList<>(list.list_);
        Collections.reverse(listNew);
        ret.var = new cList(listNew);
    }
    private static void f_remove (cList list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index);
        list.list_.remove(index);
    }
}
