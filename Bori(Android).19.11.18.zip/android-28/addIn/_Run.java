package bori.example.actiongetimage;

import java.util.ArrayList;

class _Run
{
    _BoriView boriview_;
    private _Method method_;
    private int[] code;
    private _ConList exvars_;
    private _ConList params_;
    private _ConList lvars;
    private _ConList tvars;
    private _ConList stack;
    private ArrayList<Integer> catchs;
    private int ncode;
    private _Container ret_;
    private _Container conRTest_;
    private cBool rtest;

    // registers
    private static final int RAX = 0;
    private static final int RTEST = 1;

    // segments
    private static final int RSEG = 0; // Register Segment
    private static final int DSEG = 1; // Data Segment
    private static final int SEG_LOCAL_VAR = 2; // Local Variables inside method
    private static final int SEG_TEMP_VAR = 3; // Temporary Local Variables
    private static final int SEG_PARAM_VAR = 4; // Param variables
    private static final int SEG_EX_VAR = 5; // Local Variables
    private static final int SEG_STATIC_EX_VAR = 6; // static Local Variables


    private static final int RETURN = 0, LABEL = 1, JMP=2, JZ=3, JNZ=4, TEST=5;
    private static final int PUSH_CATCH_POS=6, POP_CATCH_POS=7, JMP_OUTER_CATCH=8;
    private static final int THROW_EXCEPTION=9, THROW_EXCEPTION2=10, THROW_EXCEPTION3=11;
    private static final int READ_THROW=12, CHECK_CATCH_TYPE=13, RE_THROW=14;
    private static final int PUSH=15, STKOFF=16;
    private static final int SVAR_ON=17, TVAR_ON=18, TVAR_OFF=19, VAR_INIT=20;
    private static final int CALL=21, CALL_THIS=22, CALL_USER=23, GETRET = 24;
    private static final int CALLVAR=25, CALL_USERVAR=26;
    private static final int RETVAL=27;
    private static final int NOT=28, UMINUS=29, BIT_NOT=30;
    private static final int EQ=31, LS=32, GR=33, LE=34, GE=35, NE=36;
    private static final int PLUS=37, MINUS=38, MULTI=39, DIVID=40, MOD=41;
    private static final int BIT_AND=42, BIT_INCLUSIVE_OR=43, BIT_EXCLUSIVE_OR=44, LSHIFT=45, RSHIFT=46, URSHIFT=47;
    private static final int ASSIGN_STR_DATA_2_STRING=48;
    private static final int ASSIGN_BOOL_DATA_2_VAR=49, _ASSIGN_CHAR_DATA_2_VAR_ = 50, ASSIGN_BIGINT_DATA_2_VAR=51, ASSIGN_DOUB_DATA_2_VAR=52;
    private static final int ASSIGN_VAR_2_VAR=53, ASSIGN_TYPEVAR_2_VAR=54, CLONE_VAR_2_VAR=55, CAST_VAR_2_VAR=56;
    private static final int ADD_ELEMENT_TO_ARRAY=57;

    _Run(_BoriView boriview, _Method method, _ConList exvars, _ConList params)
    {
        boriview_ = boriview;
        method_ = method;
        exvars_ = exvars;
        params_ = params;
        lvars = new _ConList();
        tvars = new _ConList();
        stack = new _ConList();
        catchs = new ArrayList<>();
        rtest = new cBool();
        conRTest_ = new _Container(rtest);
    }

    void runVar() throws Exception
    {
        ret_ = new _Container();
        _run();
        for (int i = 0, ct = lvars.size(); i < ct; i++)
        {
            exvars_.add(lvars.get(i));
        }
    }

    void run()
    {
        try
        {
            ret_ = new _Container();
            _run();
        }
        catch (Exception e)
        {
            _Alert.showException(boriview_.bori, "> " + method_.name + "\n" + e.getMessage());
        }
    }
    void run(_Container ret)
    {
        try
        {
            ret_ = ret;
            _run();
        }
        catch (Exception e)
        {
            _Alert.showException(boriview_.bori, "> " + method_.name + "\n" + e.getMessage());
        }
    }

    private void _run() throws Exception
    {
        if (method_ == null)
            return;
        code = method_.code;
        if (code == null || code.length < 1)
            return;
        ncode = 0;
        while (true)
        {
            int cmd = next();
            if (cmd == RETURN)
                break;
            switch(cmd)
            {
                case LABEL:
                    next();
                    break;
                case JMP: // 2
                    ncode = next();
                    break;
                case JZ: // 3
                {
                    int n = next();
                    if (!rtest.isTrue())
                        ncode = n;
                    break;
                }
                case JNZ: // 4
                {
                    int n = next();
                    if (rtest.isTrue())
                        ncode = n;
                    break;
                }
                case TEST: // 5
                {
                    _Container con = getObject();
                    rtest.set(con.var.isTrue());
                    break;
                }
                case PUSH_CATCH_POS: // 6
                    catchs.add(next());
                    break;
                case POP_CATCH_POS:
                case JMP_OUTER_CATCH:
                case THROW_EXCEPTION:
                case THROW_EXCEPTION2:
                case THROW_EXCEPTION3:
                case READ_THROW:
                case CHECK_CATCH_TYPE:
                case RE_THROW:
                    throw new Exception("Unsupported command: " + cmd);
                case PUSH: // 15
                    stack.add(getObject());
                    break;
                case STKOFF:
                {
                    int ct = next();
                    int stacksize = stack.size();
                    if (ct > stacksize)
                        throw new Exception("STKOFF overflow.");
                    for ( ; ct > 0; stacksize--, ct--)
                        stack.remove(stacksize - 1);
                    break;
                }
                case SVAR_ON:
                    lvars.add(cType.alloc(boriview_.bori, next()));
                    break;
                case TVAR_ON:
                    tvars.add(cType.alloc(boriview_.bori, next()));
                    break;
                case TVAR_OFF:
                {
                    int lastDeclared = next();
                    int ctvar = tvars.size();
                    if (ctvar < lastDeclared)
                        throw new Exception("TVAROFF overflow.");
                    while (ctvar > lastDeclared)
                    {
                        ctvar--;
                        tvars.remove(ctvar);
                    }
                    break;
                }
                case VAR_INIT:
                {
                    int index = next();
                    _Container con = lvars.get(index);
                    con.var.clear();
                    break;
                }
                case CALL:
                {
                    int classType = next();
                    int func = next();
                    cType.call(boriview_, classType, func, ret_, stack);
                    break;
                }
                case CALL_THIS:
                {
                    int func = next();
                    boriview_.call(ret_, func, stack);
                    break;
                }
                case CALL_USER:
                    throw new Exception("Unsupported command: " + cmd);
                case GETRET:
                {
                    _Container con = getObject();
                    if (cType.isAssignable(con.var.type, ret_.var.type))
                        con.var = ret_.var;
                    else
                        throw new Exception("Different type value returned.");
                    break;
                }
                case CALLVAR:
                    callVar();
                    break;
                case CALL_USERVAR:
                    throw new Exception("Unsupported command: " + cmd);
                case RETVAL:
                {
                    _Container con = getObject();
                    ret_.var = con.var;
                    break;
                }
                case NOT:
                {
                    _Container conD = getObject();
                    _Container conS = getObject();
                    ((cBool)conD.var).set(!(conS.var).isTrue());
                    break;
                }
                case UMINUS:
                    uminus();
                    break;
                case BIT_NOT:
                    throw new Exception("Unsupported command: " + cmd);
                case EQ:
                case LS:
                case GR:
                case LE:
                case GE:
                case NE:
                {
                    _Container conD = getObject();
                    _Container con1 = getObject();
                    _Container con2 = getObject();
                    ((cBool)conD.var).set(compare(cmd, con1.var, con2.var));
                    break;
                }
                case PLUS:
                case MINUS:
                case MULTI:
                case DIVID:
                case MOD:
                case BIT_AND:
                case BIT_INCLUSIVE_OR:
                case BIT_EXCLUSIVE_OR:
                {
                    _Container conD = getObject();
                    _Container conS = getObject();
                    if (conD.var.type != conS.var.type)
                        throw new Exception("Trying to calculate two different type values.");
                    switch (conD.var.type)
                    {
                        case cType.TCH:	oper_char(cmd, conD.var, conS.var);	break;
                        case cType.TBIGINT:	oper_int(cmd, conD.var, conS.var);	break;
                        case cType.TDOUBLE:	oper_double (cmd, conD.var, conS.var);	break;
                        default:
                            throw new Exception("Trying to calculate uncountable values.");
                    }
                    break;
                }
                case LSHIFT:
                case RSHIFT:
                case URSHIFT:
                    throw new Exception("Unsupported command: " + cmd);
                case ASSIGN_STR_DATA_2_STRING:
                {
                    _Container con = getObject();
                    if (con.var.getType() != cType.TSTRING)
                        throw new Exception("Trying to assign str value to a different type var.");
                    ((cString)con.var).set(next_string_data());
                    break;
                }
                case ASSIGN_BOOL_DATA_2_VAR:
                {
                    _Container con = getObject();
                    if (con.var.getType() != cType.TBOOL)
                        throw new Exception("Trying to assign bool value to a different type var.");
                    ((cBool)con.var).set(next_bool_data());
                    break;
                }
                case _ASSIGN_CHAR_DATA_2_VAR_:
                {
                    _Container con = getObject();
                    if (con.var.getType() != cType.TCH)
                        throw new Exception("Trying to assign char value to a different type var.");
                    ((cChar)con.var).set(next_char_data());
                    break;
                }
                case ASSIGN_BIGINT_DATA_2_VAR:
                {
                    _Container con = getObject();
                    if (con.var.getType() != cType.TBIGINT)
                        throw new Exception("Trying to assign int value to a different type var.");
                    ((cInt)con.var).value = next_long_data();
                    break;
                }
                case ASSIGN_DOUB_DATA_2_VAR:
                {
                    _Container con = getObject();
                    if (con.var.getType() != cType.TDOUBLE)
                        throw new Exception("Trying to assign double value to a different type var.");
                    ((cDouble)con.var).value = next_double_data();
                    break;
                }
                case ASSIGN_VAR_2_VAR:
                    throw new Exception("Yet unsupported command: " + cmd);
                case ASSIGN_TYPEVAR_2_VAR:
                case CLONE_VAR_2_VAR:
                {
                    _Container conD = getObject();
                    _Container conS = getObject();
                    conD.var.copyFrom(conS.var);
                    break;
                }
                case CAST_VAR_2_VAR:
                    castVar();
                    break;
                case ADD_ELEMENT_TO_ARRAY:
                    add_element_to_list();
                    break;
                default:
                    throw new Exception("Unsupported command: " + cmd);
            }
        }
    }

    private int next()
    {
        return code[ncode++];
    }

    private String next_string_data() throws Exception
    {
        int seg = next();
        int of = next();
        if (seg != DSEG)
            throw new Exception("Invalid Data Segment");
        int len = method_.data[of];
        char[] arr = new char[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = (char)(method_.data[of+i+1]);
        }
        return new String(arr);
    }

    private boolean next_bool_data() throws Exception
    {
        int seg = next();
        int of = next();
        if (seg != DSEG)
            throw new Exception("Invalid Data Segment");
        int len = method_.data[of];
        char[] arr = new char[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = (char)(method_.data[of+i+1]);
        }
        String s = new String(arr);
        return s.equals("true");
    }
    private int next_char_data() throws Exception
    {
        int seg = next();
        int of = next();
        if (seg != DSEG)
            throw new Exception("Invalid Data Segment");
        int len = method_.data[of];
        char[] arr = new char[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = (char)(method_.data[of+i+1]);
        }
        return Integer.parseInt(new String(arr));
    }
    private long next_long_data() throws Exception
    {
        int seg = next();
        int of = next();
        if (seg != DSEG)
            throw new Exception("Invalid Data Segment");
        int len = method_.data[of];
        char[] arr = new char[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = (char)(method_.data[of+i+1]);
        }
        return Long.parseLong(new String(arr));
    }
    private double next_double_data() throws Exception
    {
        int seg = next();
        int of = next();
        if (seg != DSEG)
            throw new Exception("Invalid Data Segment");
        int len = method_.data[of];
        char[] arr = new char[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = (char)(method_.data[of+i+1]);
        }
        return Double.parseDouble(new String(arr));
    }

    private _Container getObject () throws Exception
    {
        _Container con = null;
        int seg = next();
        int of = next();

        if (seg == RSEG)
        {
            switch (of)
            {
                case RAX:
                    //var = rax;
                    //break;
                    throw new Exception("RSEG-RAX.");
                case RTEST:
                    con = conRTest_;
                    break;
                default:
                    throw new Exception("Invalid register.");
            }
        }
        else
        {
            switch (seg)
            {
                case SEG_EX_VAR:
                    con = exvars_.get(of);
                    break;
                case SEG_PARAM_VAR:
                    con = params_.get(of);
                    break;
                case SEG_LOCAL_VAR:
                    con = lvars.get(of);
                    break;
                case SEG_TEMP_VAR:
                    con = tvars.get(of);
                    break;
                case SEG_STATIC_EX_VAR:
                    //con = pfhCur_ -> listVar_.get(of);
                    break;
                default:
                    throw new Exception("Invalid Segment.");
            }
        }
        if (con == null)
            throw new Exception("Null object.");
        return con;
    }

    private void callVar() throws Exception
    {
        _Container conD = getObject();
        _Container conS = getObject();
        int type = next();
        int index = next();
        cType.callVar(type, index, conD, conS);
    }

    private void castVar() throws Exception
    {
        _Container conD = getObject();
        _Container conS = getObject();

        int dtype = conD.var.type;
        int stype = conS.var.type;

        if (dtype == stype)
        {
            conD.var.copyFrom(conS.var);
            return;
        }
        if (dtype > cType.TC_FIRST && dtype <= cType.TC_LAST)
        {
            if (stype == cType.TCONTROL)
            {
                conD.var.copyFrom(conS.var);
                return;
            }
        }
        switch (dtype)
        {
            case cType.TCONTROL:
                if (stype > cType.TC_FIRST && stype <= cType.TC_LAST)
                {
                    conD.var.copyFrom(conS.var);
                    return;
                }
                break;
            case cType.TBOOL:
            {
                ((cBool)conD.var).set(conS.var.isTrue());
                return;
            }
            case cType.TCH:
            {
                cChar d = (cChar)conD.var;
                if (stype == cType.TBIGINT)
                {
                    cInt s = (cInt) conS.var;
                    d.ch_ = (char)s.value;
                    return;
                }
                break;
            }
            case cType.TBIGINT:
            {
                cInt d = (cInt)conD.var;
                switch (stype)
                {
                    case cType.TCH:
                    {
                        cChar s = (cChar)(conS.var);
                        d.set(s.ch_);
                        return;
                    }
                    case cType.TDOUBLE:
                    {
                        cDouble s = (cDouble)(conS.var);
                        if (s.isNull())
                            d.setNull();
                        else
                            d.set((long)(s.value));
                        return;
                    }
                }
                break;
            }
            case cType.TDOUBLE:
            {
                cDouble d = (cDouble)conD.var;
                if (stype == cType.TBIGINT)
                {
                    cInt s = (cInt) conS.var;
                    d.set(s.value);
                    return;
                }
                break;
            }
            case cType.TSTRS:
            {
                cStrs strs = (cStrs)conD.var;
                strs.clear();
                if (stype == cType.TLIST)	// inner function
                {
                    cList list = (cList) conS.var;
                    for (int i = 0, ct = list.count(); i < ct; i++)
                    {
                        cVar var = list.get(i);
                        if (var instanceof cString)
                        {
                            cString s = (cString) var;
                            strs.add(s.text);
                        }
                    }
                    return;
                }
                break;
            }
            case cType.TINTS:
            {
                cInts is = (cInts)conD.var;
                is.clear();
                if (stype == cType.TLIST)	// inner function
                {
                    cList list = (cList) conS.var;
                    for (int i = 0, ct = list.count(); i < ct; i++)
                    {
                        cVar var = list.get(i);
                        if (var instanceof cInt)
                        {
                            cInt n = (cInt) var;
                            is.add(n.value);
                        }
                    }
                    return;
                }
                break;
            }
            case cType.TDOUBS:
            {
                cDoubles ds = (cDoubles)conD.var;
                ds.clear();
                switch (stype)
                {
                    case cType.TINTS:
                    {
                        cInts is = (cInts)conS.var;
                        for (int i = 0, ct = is.count(); i < ct; i++)
                        {
                            long v = is.get(i);
                            ds.add(v);
                        }
                        return;
                    }
                    case cType.TLIST:	// inner function
                    {
                        cList list = (cList) conS.var;
                        for (int i = 0, ct = list.count(); i < ct; i++)
                        {
                            cVar var = list.get(i);
                            if (var instanceof cInt)
                            {
                                cInt n = (cInt) var;
                                ds.add(n.value);
                            }
                            else if (var instanceof cDouble)
                            {
                                cDouble d = (cDouble) var;
                                ds.add(d.value);
                            }
                            else
                                ds.add(cDouble.NULL);
                        }
                    }
                    return;
                }
                break;
            }
        }

        throw new Exception("Invalid casting from " + stype + " to " + dtype);
    }

    private boolean compare (int op, cVar var1, cVar var2) throws Exception
    {
        int type = var1.type;

        if (type != var2.type)
            throw new Exception("Compared with different type.");
        if (var1 == var2)
            return true;

        int cmp = -1;
        if (type >= cType.TC_FIRST && type <= cType.TC_LAST)
        {
            if (((cControl)var1).view == ((cControl)var2).view)
                cmp = 0;
        }
        else
        {
            switch (type)
            {
                case cType.TBOOL:
                {
                    boolean b1 = var1.isTrue();
                    boolean b2 = var2.isTrue();
                    if (op == EQ)	return (b1 == b2);
                    else if (op == NE)	return (b1 != b2);
                    return false;
                }
                case cType.TSTRING:
                    cmp = ((cString)var1).compareTo((cString)var2);
                    break;
                case cType.TCH:
                {
                    cChar v1 = (cChar)var1;
                    cChar v2 = (cChar)var2;
                    if (v1.ch_ > v2.ch_)	cmp = 1;
                    else if (v1.ch_ == v2.ch_)	cmp = 0;
                    else cmp = -1;
                    break;
                }
                case cType.TBIGINT:
                {
                    cInt v1 = (cInt)var1;
                    cInt v2 = (cInt)var2;
                    if (v1.isNull() && v2.isNull())
                        cmp = 0;
                    else if (v1.isNull() || v2.isNull())
                        return false;
                    else if (v1.value > v2.value)	cmp = 1;
                    else if (v1.value == v2.value)	cmp = 0;
                    else cmp = -1;
                    break;
                }
                case cType.TDOUBLE:
                {
                    cDouble v1 = (cDouble)var1;
                    cDouble v2 = (cDouble)var2;
                    if (v1.isNull() && v2.isNull())
                        cmp = 0;
                    else if (v1.isNull() || v2.isNull())
                        return false;
                    else if (v1.value > v2.value)	cmp = 1;
                    else if (v1.value == v2.value)	cmp = 0;
                    else cmp = -1;
                    break;
                }
                default:
                    throw new Exception("Unsupported comparison.");
            }
        }
        switch (op)
        {
            case EQ:
                if (cmp == 0)	return true;
                break;
            case LS:
                if (cmp < 0)	return true;
                break;
            case GR:
                if (cmp > 0)	return true;
                break;
            case LE:
                if (cmp <= 0)	return true;
                break;
            case GE:
                if (cmp >= 0)	return true;
                break;
            case NE:
                if (cmp != 0)	return true;
                break;
        }
        return false;
    }

    private void oper_char (int cmd, cVar varD, cVar varS) throws Exception
    {
        cChar d = (cChar)varD;
        cChar s = (cChar)varS;
        switch (cmd)
        {
            case PLUS:
                d.ch_ += s.ch_;
                break;
            case MINUS:
                d.ch_ -= s.ch_;
                break;
            default:
                throw new Exception("Unsupported operation in oper_char().");
        }
    }
    private void oper_int (int cmd, cVar varD, cVar varS) throws Exception
    {
        cInt d = (cInt)varD;
        cInt s = (cInt)varS;
        if (d.value == cInt.NULL || s.value == cInt.NULL)
            d.value = cInt.NULL;
        else
        {
            switch (cmd)
            {
                case PLUS:	d.value += s.value;	break;
                case MINUS:	d.value -= s.value;	break;
                case MULTI:	d.value *= s.value;	break;
                case DIVID:
                    if (s.value == 0)
                        throw new Exception("divide by zero");
                    d.value /= s.value;
                    break;
                case MOD:
                    if (s.value == 0)
                        throw new Exception("divide by zero");
                    d.value %= s.value;
                    break;
                case BIT_AND:	d.value &= s.value;	break;
                case BIT_INCLUSIVE_OR:	d.value |= s.value;	break;
                case BIT_EXCLUSIVE_OR:	d.value ^= s.value;	break;
            }
        }
    }
    private void oper_double (int cmd, cVar varD, cVar varS) throws Exception
    {
        cDouble d = (cDouble)varD;
        cDouble s = (cDouble)varS;
        if (d.value == cDouble.NULL || s.value == cDouble.NULL)
            d.value = cDouble.NULL;
        else
        {
            switch (cmd)
            {
                case PLUS:	d.value += s.value;	break;
                case MINUS:	d.value -= s.value;	break;
                case MULTI:	d.value *= s.value;	break;
                case DIVID:
                    if (s.value == 0)
                        throw new Exception("divide by zero");
                    d.value /= s.value;
                    break;
                case MOD:
                    if (s.value == 0)
                        throw new Exception("divide by zero");
                    d.value %= s.value;
                    break;
                default:
                    throw new Exception("Unsupported operation in oper_double().");
            }
        }
    }

    private void uminus() throws Exception
    {
        _Container dcon = getObject();
        _Container scon = getObject();
        switch (scon.var.type)
        {
            case cType.TBIGINT:
            {
                cInt di = (cInt)(dcon.var);
                cInt si = (cInt)(scon.var);
                if (si.isNull())
                    di.setNull();
                else
                    di.value = si.value * (-1);
            }
            break;
            case cType.TDOUBLE:
            {
                cDouble dval = (cDouble)(dcon.var);
                cDouble sval = (cDouble)(scon.var);
                if (sval.isNull())
                    dval.setNull();
                else
                    dval.value = sval.value * (-1.0);
            }
            break;
            default:
                throw new Exception("Unsupported type in uminus().");
        }

    }

    private void add_element_to_list () throws Exception
    {
        _Container conD = getObject();
        _Container conS = getObject();
        ((cList)conD.var).add(conS.var);
    }

}
