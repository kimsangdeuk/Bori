package bori.android.memo;

import okhttp3.Headers;
import okhttp3.Response;

class cHttpResponse extends cVar
{
    private Response response_;
    String stringContent_;

    cHttpResponse()
    {
        super(cType.THTTPRESPONSE);
    }
    cHttpResponse(Response res)
    {
        super(cType.THTTPRESPONSE);
        response_ = res;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cHttpResponse)
        {
            cHttpResponse src = (cHttpResponse)var;
            response_ = src.response_;
        }
    }

    //-------------------------------------------------------------
    private static final int FNC_STRING_CONTENT = 0, FNC_HEADER = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_STRING_CONTENT:
                    methodName = "stringContent";
                    f_stringContent(ret, (cHttpResponse) stack.get(ct - 1).var);
                    break;
                case FNC_HEADER:
                    methodName = "header";
                    f_header(ret, (cHttpResponse) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> HttpResponse." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_stringContent(_Container ret, cHttpResponse response) throws Exception
    {
        ret.var = new cString(response.stringContent_); //response.response_.body().string());
    }

    private static void f_header(_Container ret, cHttpResponse response) throws Exception
    {
        Headers h = response.response_.headers();
        StringBuilder sb = new StringBuilder();
        for (int i = 0, ct = h.size(); i < ct; i++)
        {
            if (i > 0)
                sb.append("\n");
            String name = h.name(i);
            String value = h.value(i);
            sb.append(name);
            sb.append(" = ");
            sb.append(value);
        }
        ret.var = new cString(sb.toString());
    }
}
