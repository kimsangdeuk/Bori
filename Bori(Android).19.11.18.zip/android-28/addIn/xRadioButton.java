package bori.android.check_radio;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v7.widget.AppCompatRadioButton;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xRadioButton extends AppCompatRadioButton
{
    private _BoriView boriview_;
    String	group_;
    private String methodOnChanged = null;

    public xRadioButton (Context context)
    {
        super(context);
    }
    public xRadioButton (Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        init();
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void init()
    {
        setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                checkRadioGroup((xRadioButton)v);
            }
        });

        setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (methodOnChanged != null)
                {
                    _ConList params = new _ConList();

                    cControl control= new cControl(buttonView);
                    params.add(new _Container(control));
                    cBool b = new cBool(isChecked);
                    params.add(new _Container(b));

                    boriview_.call(methodOnChanged, params);
                }

            }
        });
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setTextStyle(this, node);
        _Xml.setViewStyle(this, node);
        group_ = _Xml.getAttributeValue(node, "group");
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onCheckedChanged"))
                methodOnChanged = _Xml.getAttributeValue(node, "method");
        }
    }

    void checkRadioGroup(xRadioButton radioSelected)
    {
        if (radioSelected.group_ == null || radioSelected.group_.length() < 1)
            return;

        _Item item;
        xRadioButton radio;

        ArrayList<_Item> listItems = boriview_.getItemList();

        int ct = listItems.size();
        for (int i = 0; i < ct; i++)
        {
            item = listItems.get(i);
            if (!(item.view() instanceof xRadioButton))
                continue;
            radio = (xRadioButton) item.view();
            if (radio == radioSelected)
                continue;
            if (radioSelected.group_.equals(radio.group_))
            {
                radio.setChecked(false);
            }
        }
    }
}

