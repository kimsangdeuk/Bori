package bori.android.listview;

import android.view.View;

class _Item
{
    private String name_;
    private View view_;

    _Item(String name, View view)
    {
        name_ = name;
        view_ = view;
    }

    String name ()	{ return name_; }
    View view ()	{ return view_; }
}

