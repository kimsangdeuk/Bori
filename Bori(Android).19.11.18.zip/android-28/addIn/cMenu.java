package bori.android.menu;

import android.view.Menu;
import android.view.MenuItem;

class cMenu extends cVar
{
    Menu menu;

    cMenu()
    {
        super(cType.TMENU);
    }
    cMenu(Menu menu0)
    {
        super(cType.TMENU);
        menu = menu0;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cMenu)
            menu = ((cMenu)var).menu;
    }

    private static final int FNC_ADD = 0, FNC_ADD2 = 1, FNC_FIND_ITEM = 2, FNC_ADD_SUBMENU = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add(ret, (cMenu) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ADD2:
                    methodName = "add";
                    f_add2(boriview, ret, (cMenu) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var,
                            (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_FIND_ITEM:
                    methodName = "findItem";
                    f_findItem(ret, (cMenu) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_SUBMENU:
                    methodName = "addSubMenu";
                    f_addSubMenu(ret, (cMenu) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Menu." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add(_Container ret, cMenu menu, cInt id, cString text)
    {
        ret.var = new cMenuItem(menu.menu.add(Menu.NONE, (int)id.value, Menu.NONE, text.text));
    }
    private static void f_add2(_BoriView boriview, _Container ret, cMenu menu, cInt id,
                               cString text, cString iconResource)
    {
        MenuItem item = menu.menu.add(Menu.NONE, (int)id.value, Menu.NONE, text.text);
        int resId = boriview.bori.getResources().getIdentifier(iconResource.text, null, boriview.bori.getPackageName());
        item.setIcon(resId);
        ret.var = new cMenuItem(item);
    }
    private static void f_findItem(_Container ret, cMenu menu, cInt id)
    {
        ret.var = new cMenuItem(menu.menu.findItem((int)id.value));
    }
    private static void f_addSubMenu(_Container ret, cMenu menu, cString text)
    {
        ret.var = new cMenu(menu.menu.addSubMenu(text.text));
    }
}
