package bori.sangdeuk.alertdialog;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;

class cAlertDialog extends cVar
{
    private String title_;
    private String message_;
    private String positiveButtonText_;
    private String neutralButtonText_;
    private String negativeButtonText_;
    private String positiveButtonMethod_;
    private String neutralButtonMethod_;
    private String negativeButtonMethod_;
    private boolean cancelable_ = true;

    cAlertDialog()
    {
        super(cType.TALERTDIALOG);
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_TITLE = 0, FNC_SET_MESSAGE = 1,
            FNC_SET_POSITIVE_BUTTON = 2, FNC_SET_POSITIVE_BUTTON_M = 3,
            FNC_SET_NEUTRAL_BUTTON = 4, FNC_SET_NEUTRAL_BUTTON_M = 5,
            FNC_SET_NEGATIVE_BUTTON = 6, FNC_SET_NEGATIVE_BUTTON_M = 7,
            FNC_SET_CANCELABLE = 8, FNC_SHOW = 9;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_TITLE:
                    methodName = "setTitle";
                    f_setTitle(ret, (cAlertDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_MESSAGE:
                    methodName = "setMessage";
                    f_setMessage(ret, (cAlertDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_POSITIVE_BUTTON:
                    methodName = "setPositiveButton";
                    f_setPositiveButton(ret, (cAlertDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_POSITIVE_BUTTON_M:
                    methodName = "setPositiveButton";
                    f_setPositiveButtonM(ret, (cAlertDialog) stack.get(ct - 3).var,
                            (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_NEUTRAL_BUTTON:
                    methodName = "setNeutralButton";
                    f_setNeutralButton(ret, (cAlertDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_NEUTRAL_BUTTON_M:
                    methodName = "setNeutralButton";
                    f_setNeutralButtonM(ret, (cAlertDialog) stack.get(ct - 3).var,
                            (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_NEGATIVE_BUTTON:
                    methodName = "setNegativeButton";
                    f_setNegativeButton(ret, (cAlertDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_NEGATIVE_BUTTON_M:
                    methodName = "setNegativeButton";
                    f_setNegativeButtonM(ret, (cAlertDialog) stack.get(ct - 3).var,
                            (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CANCELABLE:
                    methodName = "setCancelable";
                    f_setCancelable(ret, (cAlertDialog) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_SHOW:
                    methodName = "show";
                    f_show(boriview, (cAlertDialog) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> AlertDialog." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setTitle(_Container ret, cAlertDialog dlg, cString title)
    {
        dlg.title_ = title.text;
        ret.var = dlg;
    }
    private static void f_setMessage(_Container ret, cAlertDialog dlg, cString msg)
    {
        dlg.message_ = msg.text;
        ret.var = dlg;
    }
    private static void f_setPositiveButton(_Container ret, cAlertDialog dlg, cString text)
    {
        dlg.positiveButtonText_ = text.text;
        ret.var = dlg;
    }
    private static void f_setPositiveButtonM(_Container ret, cAlertDialog dlg, cString text, cString method)
    {
        dlg.positiveButtonText_ = text.text;
        dlg.positiveButtonMethod_ = method.text;
        ret.var = dlg;
    }
    private static void f_setNeutralButton(_Container ret, cAlertDialog dlg, cString text)
    {
        dlg.neutralButtonText_ = text.text;
        ret.var = dlg;
    }
    private static void f_setNeutralButtonM(_Container ret, cAlertDialog dlg, cString text, cString method)
    {
        dlg.neutralButtonText_ = text.text;
        dlg.neutralButtonMethod_ = method.text;
        ret.var = dlg;
    }
    private static void f_setNegativeButton(_Container ret, cAlertDialog dlg, cString text)
    {
        dlg.negativeButtonText_ = text.text;
        ret.var = dlg;
    }
    private static void f_setNegativeButtonM(_Container ret, cAlertDialog dlg, cString text, cString method)
    {
        dlg.negativeButtonText_ = text.text;
        dlg.negativeButtonMethod_ = method.text;
        ret.var = dlg;
    }
    private static void f_setCancelable(_Container ret, cAlertDialog dlg, cBool cancelable)
    {
        dlg.cancelable_ = cancelable.isTrue();
        ret.var = dlg;
    }
    private static void f_show(_BoriView boriview, cAlertDialog dlg) throws Exception
    {
        if (dlg.title_ == null)
            throw new Exception("Title is not specified.");
        if (dlg.message_ == null)
            throw new Exception("Message is not specified.");
        if (dlg.positiveButtonText_ == null)
            throw new Exception("Positive button text is not specified.");

        _DialogFragment fdlg = _DialogFragment.newInstance(boriview, dlg.title_, dlg.message_,
                dlg.positiveButtonText_, dlg.neutralButtonText_, dlg.negativeButtonText_,
                dlg.positiveButtonMethod_, dlg.neutralButtonMethod_, dlg.negativeButtonMethod_);
        fdlg.setCancelable(dlg.cancelable_);
        fdlg.show(boriview.bori.getSupportFragmentManager(), dlg.title_);
    }

    public static class _DialogFragment extends DialogFragment
    {
        private _BoriView boriview_;
        private String title_;
        private String message_;
        private String positiveButtonText_;
        private String neutralButtonText_;
        private String negativeButtonText_;
        private String positiveButtonMethod_;
        private String neutralButtonMethod_;
        private String negativeButtonMethod_;

        public static _DialogFragment newInstance(
                _BoriView boriview, String title, String message,
                String positiveButtonText, String neutralButtonText, String negativeButtonText,
                String positiveButtonMethod, String neutralButtonMethod, String negativeButtonMethod)
        {
            _DialogFragment dlg = new _DialogFragment();
            dlg.boriview_ = boriview;
            dlg.title_ = title;
            dlg.message_ = message;
            dlg.positiveButtonText_ = positiveButtonText;
            dlg.neutralButtonText_ = neutralButtonText;
            dlg.negativeButtonText_ = negativeButtonText;
            dlg.positiveButtonMethod_ = positiveButtonMethod;
            dlg.neutralButtonMethod_ = neutralButtonMethod;
            dlg.negativeButtonMethod_ = negativeButtonMethod;
            return dlg;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

            builder.setTitle(title_);
            builder.setMessage(message_);
            if (positiveButtonMethod_ == null)
                builder.setPositiveButton(positiveButtonText_, null);
            else
                builder.setPositiveButton(positiveButtonText_,
                        new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialog, int which)
                            {
                                _ConList params = new _ConList();
                                boriview_.call(positiveButtonMethod_ + "()", params);
                            }
                        });
            if (neutralButtonText_ != null)
            {
                if (neutralButtonMethod_ == null)
                    builder.setNeutralButton(neutralButtonText_, null);
                else
                    builder.setNeutralButton(neutralButtonText_,
                            new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick(DialogInterface dialog, int which)
                                {
                                    _ConList params = new _ConList();
                                    boriview_.call(neutralButtonMethod_ + "()", params);
                                }
                            });
            }
            if (negativeButtonText_ != null)
            {
                if (negativeButtonMethod_ == null)
                    builder.setNegativeButton(negativeButtonText_, null);
                else
                    builder.setNegativeButton(negativeButtonText_,
                            new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick(DialogInterface dialog, int which)
                                {
                                    _ConList params = new _ConList();
                                    boriview_.call(negativeButtonMethod_ + "()", params);
                                }
                            });
            }

            return builder.create();
        }
    }
}
