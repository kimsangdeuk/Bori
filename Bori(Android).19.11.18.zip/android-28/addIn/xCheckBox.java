package com.sangdeuk.fragment;

import android.content.Context;
import android.support.v7.widget.AppCompatCheckBox;
import android.util.AttributeSet;
import android.widget.CompoundButton;

import org.w3c.dom.Node;

import java.util.ArrayList;

public class xCheckBox extends AppCompatCheckBox
{
    private _BoriView boriview_;
    private String methodOnChanged = null;

    public xCheckBox (Context context) { super(context); }
    public xCheckBox (Context context, AttributeSet attrs) { super(context, attrs); }
    public xCheckBox (Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }

    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        init();
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void init()
    {
        setOnCheckedChangeListener(new OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                if (methodOnChanged != null)
                {
                    _ConList params = new _ConList();

                    cControl control= new cControl(buttonView);
                    params.add(new _Container(control));
                    cBool b = new cBool(isChecked);
                    params.add(new _Container(b));

                    boriview_.call(methodOnChanged, params);
                }

            }
        });
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setTextStyle(this, node);
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onCheckedChanged"))
                methodOnChanged = _Xml.getAttributeValue(node, "method");
        }
    }
}
