package com.sangdeuk.fragment1;

import android.graphics.Bitmap;

class cBitmap extends cVar
{
    Bitmap bmp_;

    cBitmap()
    {
        super(cType.TBITMAP);
        bmp_ = null;
    }
    cBitmap(Bitmap b)
    {
        super(cType.TBITMAP);
        bmp_ = b;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cBitmap)
        {
            cBitmap src = (cBitmap)var;
            bmp_ = src.bmp_;
        }
    }

    boolean isEmpty()
    {
        return (bmp_ == null || bmp_.getHeight() == 0 || bmp_.getWidth() == 0);
    }
    int getWidth()
    {
        return bmp_ == null ? 0 : bmp_.getWidth();
    }
    int getHeight()
    {
        return bmp_ == null ? 0 : bmp_.getHeight();
    }
    //-----------------------------------------------------------
    private static final int FNC_FROM_RESOURCE = 0, FNC_FROM_ASSET = 1, FNC_IS_EMPTY = 2,
            FNC_GET_WIDTH = 3, FNC_GET_HEIGHT = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_FROM_RESOURCE: f_fromResource(boriview, ret, (cString)stack.get(ct-3).var,
                    (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_FROM_ASSET: f_fromAsset(boriview, ret, (cString)stack.get(ct-3).var,
                    (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_IS_EMPTY: f_isEmpty(ret, (cBitmap)stack.get(ct-1).var); break;
            case FNC_GET_WIDTH: f_getWidth(ret, (cBitmap)stack.get(ct-1).var); break;
            case FNC_GET_HEIGHT: f_getHeight(ret, (cBitmap)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Bitmap class method:" + nfunc);
        }
    }

    private static void f_fromResource(_BoriView boriview, _Container ret, cString name,
                                       cInt minWidth, cInt minHeight) throws Exception
    {
        Bitmap bmp;
        try
        {
            bmp = _Util.decodeSampledBitmapFromResource(boriview.bori, name.text,
                    (int)minWidth.value, (int)minHeight.value);
        }
        catch (Exception e)
        {
            throw new Exception("> Bitmap.fromResource()\n" + e.getMessage());
        }
        ret.var = new cBitmap(bmp);
    }
    private static void f_fromAsset(_BoriView boriview, _Container ret, cString filename,
                                       cInt minWidth, cInt minHeight) throws Exception
    {
        Bitmap bmp;
        try
        {
            bmp = _Util.decodeSampledBitmapFromAsset(boriview.bori, filename.text,
                    (int)minWidth.value, (int)minHeight.value);
        }
        catch (Exception e)
        {
            throw new Exception("> Bitmap.fromAsset()\n" + e.getMessage());
        }
        ret.var = new cBitmap(bmp);
    }
    private static void f_isEmpty(_Container ret, cBitmap b)
    {
        ret.var = new cBool(b.isEmpty());
    }
    private static void f_getWidth(_Container ret, cBitmap b)
    {
        ret.var = new cInt(b.getWidth());
    }
    private static void f_getHeight(_Container ret, cBitmap b)
    {
        ret.var = new cInt(b.getHeight());
    }
}
