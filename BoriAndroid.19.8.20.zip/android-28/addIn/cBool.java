package bori.android.actbranches;

import android.os.Parcel;
import android.os.Parcelable;

class cBool extends cVar implements Parcelable
{
    private byte value;
    private static final byte TRUE = 1;
    private static final byte FALSE = 0;
    static final byte NULL = -1;

    cBool()
    {
        super(cType.TBOOL);
        value = NULL;
    }
    cBool(cBool b)
    {
        super(cType.TBOOL);
        value = b.value;
    }
    cBool(boolean b)
    {
        super(cType.TBOOL);
        value = b ? TRUE : FALSE;
    }
    cBool(Parcel parcel)
    {
        super(cType.TBOOL);
        readFromParcel(parcel);
    }
    void set(boolean b)
    {
        value = (b) ? TRUE : FALSE;
    }
    byte getValue() { return value; }
    void setValue(byte bt)
    {
        if (bt == TRUE || bt == FALSE) value = bt;
        else value = NULL;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cBool)
            value = ((cBool)var).value;
    }
    @Override
    public void clear()
    {
        value = NULL;
    }
    @Override
    public boolean isTrue() { return value == TRUE; }
    @Override
    public boolean isNull() { return value == NULL; }
    @Override
    public String toString()
    {
        if (value == NULL)
            return "NA";
        return (value == TRUE) ? "true" : "false";
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeByte(value);
    }

    private void readFromParcel(Parcel in)
    {
        value = in.readByte();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cColor createFromParcel(Parcel in) {
            return new cColor(in);
        }

        public cColor[] newArray(int size) {
            return new cColor[size];
        }
    };

}
