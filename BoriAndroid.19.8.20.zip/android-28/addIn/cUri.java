package com.sangdeuk.fragment1;

import android.net.Uri;

class cUri extends cVar
{
    Uri uri_;

    cUri()
    {
        super(cType.TURI);
    }
    cUri(Uri uri)
    {
        super(cType.TURI);
        uri_ = uri;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cUri)
            uri_ = ((cUri)var).uri_;
    }
    public String toString()
    {
        return uri_.toString();
    }

    //-----------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_IS_EMPTY = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_NEW: f_new(ret, (cString)stack.get(ct-1).var); break;
            case FNC_IS_EMPTY: f_isEmpty(ret, (cUri)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Uri class method:" + nfunc);
        }
    }

    private static void f_new(_Container ret, cString suri)
    {
        ret.var = new cUri(Uri.parse(suri.text));
    }
    private static void f_isEmpty(_Container ret, cUri uri)
    {
        ret.var = new cBool(uri == null || uri.toString().isEmpty());
    }
}
