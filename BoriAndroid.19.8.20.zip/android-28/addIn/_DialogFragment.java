package bori.sangdeuk.test;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class _DialogFragment extends DialogFragment
{
    private String viewName_;
    private _BoriView parent_;
    private _BoriView boriview_;

    public static _DialogFragment newInstance(String viewName, _BoriView parent)
    {
        _DialogFragment dlg = new _DialogFragment();
        dlg.parent_ = parent;
        dlg.viewName_ = viewName;
        return dlg;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        xLinearLayout layout = null;
        try
        {
            boriview_ = new _BoriView((BoriActivity) getActivity(), this, false);
            boriview_.init(viewName_ + ".view");
            layout = boriview_.getLayout();
        }
        catch (Exception e)
        {
            _Alert.show(getActivity(), "Error", "Can not load " + viewName_);
        }
        return layout;
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);
        boriview_.onCreate(savedInstanceState);
    }

    @Override
    public void onStart()
    {
        super.onStart();
        boriview_.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        int padding = getDimensionFromAttribute(boriview_.bori, R.attr.dialogPreferredPadding);
        ViewGroup.LayoutParams params = getDialog().getWindow().getAttributes();
        params.width = boriview_.getViewWidth() + padding;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        getDialog().getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);
    }

    // used in notifyToParent() of _BoriView
    void notify(String message, cVars vars)
    {
        dismiss();
        parent_.onNotify(viewName_, message, vars);
    }

    int getDimensionFromAttribute(Context context, int attr)
    {
        TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(attr, typedValue, true))
            return TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics());
        return 0;
    }
}
