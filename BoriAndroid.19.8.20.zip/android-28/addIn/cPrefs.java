package com.sangdeuk.fragment1;

public class cPrefs extends cVar
{
    cPrefs()
    {
        super(cType.TPREFS);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_SET_BOOL = 0, FNC_SET_STRING = 1, FNC_SET_INT = 2, FNC_SET_DOUBLE = 3,
            FNC_GET_BOOL = 4, FNC_GET_STRING = 5, FNC_GET_INT = 6, FNC_GET_DOUBLE = 7;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_BOOL: f_setBool(boriview, (cString)stack.get(ct-2).var, (cBool)stack.get(ct-1).var); break;
            case FNC_SET_STRING: f_setString(boriview, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_SET_INT: f_setInt(boriview, (cString)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_SET_DOUBLE: f_setDouble(boriview, (cString)stack.get(ct-2).var, (cDouble)stack.get(ct-1).var); break;
            case FNC_GET_BOOL: f_getBool(boriview, ret, (cString)stack.get(ct-2).var, (cBool)stack.get(ct-1).var); break;
            case FNC_GET_STRING: f_getString(boriview, ret, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_GET_INT: f_getInt(boriview, ret, (cString)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_GET_DOUBLE: f_getDouble(boriview, ret, (cString)stack.get(ct-2).var, (cDouble)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Prefs class method:" + nfunc);
        }
    }

    private static void f_setBool (_BoriView boriview, cString key, cBool val)
    {
        boriview.bori.getPrefs().putByte(key.text, val.getValue());
        boriview.bori.prefsChanged();
    }
    private static void f_setString (_BoriView boriview, cString key, cString val)
    {
        boriview.bori.prefsChanged();
        boriview.bori.getPrefs().putString(key.text, val.text);
    }
    private static void f_setInt (_BoriView boriview, cString key, cInt val)
    {
        boriview.bori.getPrefs().putLong(key.text, val.value);
        boriview.bori.prefsChanged();
    }
    private static void f_setDouble (_BoriView boriview, cString key, cDouble val)
    {
        long lval = Double.doubleToLongBits(val.value);
        boriview.bori.getPrefs().putLong(key.text, lval);
        boriview.bori.prefsChanged();
    }
    private static  void f_getBool (_BoriView boriview, _Container ret, cString key, cBool defVal)
    {
        byte b = boriview.bori.getPrefs().getByte(key.text, defVal.getValue());
        ret.var = new cBool();
        ((cBool)ret.var).setValue(b);
    }
    private static void f_getString (_BoriView boriview, _Container ret, cString key, cString defVal)
    {
        ret.var = new cString(boriview.bori.getPrefs().getString(key.text, defVal.text));
    }
    private static void f_getInt (_BoriView boriview, _Container ret, cString key, cInt defVal)
    {
        ret.var = new cInt(boriview.bori.getPrefs().getLong(key.text, defVal.value));
    }
    private static void f_getDouble (_BoriView boriview, _Container ret, cString key, cDouble defVal)
    {
        long defLVal = Double.doubleToLongBits(defVal.value);
        long lval = boriview.bori.getPrefs().getLong(key.text, defLVal);
        ret.var = new cDouble(Double.longBitsToDouble(lval));
    }

}
