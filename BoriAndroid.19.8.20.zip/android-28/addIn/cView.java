package bori.sangdeuk.dialog;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import org.w3c.dom.Node;

class cView extends cVar
{
    cView()
    {
        super(cType.TVIEW);
    }

    private static final int FNC_OPENVIEW = 0, FNC_OPENVIEW_VARS = 1,
            FNC_SET_RESULT = 2,
            FNC_FINISH = 3,
            FNC_TOAST = 4,
            FNC_ALERT = 5, FNC_HIDE_KEYBOARD = 6,
            FNC_SET_TIMER = 7, FNC_SET_TIMER_COUNT = 8, FNC_KILL_TIMER = 9, FNC_IS_TIMER_RUNNING = 10,
            FNC_REPAINT = 11, FNC_GET_INTENT = 12, FNC_SET_VOLUME_CONTROL_STREAM = 13,
            FNC_START_ACTIVITY = 14, FNC_NOTIFY = 15, FNC_NOTIFY_V = 16,
            FNC_SET_BACK_COLOR = 17;


    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_OPENVIEW:
                    methodName = "openView";
                    f_openView(boriview, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_OPENVIEW_VARS:
                    methodName = "openView";
                    f_openViewWithVars(boriview, (cString) stack.get(ct - 2).var, (cVars) stack.get(ct - 1).var);
                    break;
                case FNC_SET_RESULT:
                    methodName = "setResult";
                    f_setResult(boriview, (cInt) stack.get(ct - 2).var, (cVars) stack.get(ct - 1).var);
                    break;
                case FNC_FINISH:
                    methodName = "finish";
                    f_finish(boriview);
                    break;
                case FNC_TOAST:
                    methodName = "toast";
                    f_toast(boriview, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ALERT:
                    methodName = "alert";
                    f_alert(boriview, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_HIDE_KEYBOARD:
                    methodName = "hideKeyboard";
                    f_hideKeyboard(boriview);
                    break;
                case FNC_SET_TIMER:
                    methodName = "setTimer";
                    f_setTimer(boriview, (cString) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TIMER_COUNT:
                    methodName = "setTimer";
                    f_setTimerCount(boriview, (cString) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_KILL_TIMER:
                    methodName = "killTimer";
                    f_killTimer(boriview, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_IS_TIMER_RUNNING:
                    methodName = "isTimerRunning";
                    f_isTimerRunning(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_REPAINT:
                    methodName = "repaint";
                    f_repaint(boriview);
                    break;
                case FNC_GET_INTENT:
                    methodName = "getIntent";
                    f_getIntent(boriview, ret);
                    break;
                case FNC_SET_VOLUME_CONTROL_STREAM:
                    methodName = "setVolumeControlStream";
                    f_setVolumeControlStream(boriview, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_START_ACTIVITY:
                    methodName = "startActivity";
                    f_startActivity(boriview, (cIntent) stack.get(ct - 1).var);
                    break;
                case FNC_NOTIFY:
                    methodName = "notify";
                    f_notify(boriview, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_NOTIFY_V:
                    methodName = "notify";
                    f_notifyV(boriview, (cString) stack.get(ct - 2).var, (cVars) stack.get(ct - 1).var);
                    break;
                case FNC_SET_BACK_COLOR:
                    methodName = "setBackColor";
                    f_setBackColor(boriview, (cColor) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> View." + methodName + "\n" + e.getMessage());
        }
    }

    private static void shouldNotFragment(_BoriView boriview) throws Exception
    {
        if (boriview.parent_ instanceof _Fragment)
            throw new Exception("Do not use this method in the Fragment.");
    }
    private static Class getClassFromView (BoriActivity bori, String viewName) throws Exception
    {
        Node node = bori.findView(viewName);
        String act = _Xml.getAttributeValue(node, "activity");
        if (act.equals(""))
            throw new Exception("Target activity is missing.");
        String full = bori.getPackageName() + "." + act;
        return Class.forName(full);
    }

    private static void f_openView(_BoriView boriview, cString viewName) throws Exception
    {
        shouldNotFragment(boriview);
        String viewFile = viewName.text;
        if (!viewFile.endsWith(".view"))
            viewFile += ".view";
        Class cls = getClassFromView(boriview.bori, viewFile);
        Intent intent = new Intent(boriview.bori, cls);
        boriview.bori.openView(viewFile, intent);
    }

    private static void f_openViewWithVars(_BoriView boriview, cString viewName, cVars vars) throws Exception
    {
        shouldNotFragment(boriview);
        String viewFile = viewName.text;
        if (!viewFile.endsWith(".view"))
            viewFile += ".view";
        Class cls = getClassFromView(boriview.bori, viewFile);
        Intent intent = new Intent(boriview.bori, cls);
        Bundle bundle = _Bundle.getBundle(vars.map);
        intent.putExtras(bundle);
        boriview.bori.openView(viewFile, intent);
    }

    private static void f_setResult(_BoriView boriview, cInt resultCode, cVars vars) throws Exception
    {
        shouldNotFragment(boriview);
        Intent intent = new Intent();
        Bundle bundle = _Bundle.getBundle(vars.map);
        intent.putExtras(bundle);
        boriview.bori.setResult((int)resultCode.value, intent);
    }

    private static void f_finish(_BoriView boriview) throws Exception
    {
        shouldNotFragment(boriview);
        boriview.bori.finish();
    }

    private static void f_toast(_BoriView boriview, cString csText)
    {
        Toast.makeText(boriview.bori, csText.text(), Toast.LENGTH_SHORT).show();
    }
    private static void f_alert(_BoriView boriview, cString msg, cString title)
    {
        _Alert.show(boriview.bori, title.text, msg.text);
    }
    private static void f_hideKeyboard(_BoriView boriview)
    {
        InputMethodManager imm = (InputMethodManager) boriview.bori.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(boriview.getLayout().getWindowToken(), 0);
    }
    private static void f_setTimer(_BoriView boriview, cString name, cInt interval)
    {
        boriview.setTimer(name.text, (int)interval.value, 0);
    }
    private static void f_setTimerCount(_BoriView boriview, cString name, cInt interval, cInt repeat)
    {
        boriview.setTimer(name.text, (int)interval.value, (int)repeat.value);
    }
    private static void f_killTimer(_BoriView boriview, cString name)
    {
        boriview.killTimer(name.text);
    }
    private static void f_isTimerRunning(_BoriView boriview, _Container ret, cString name)
    {
        ret.var = new cBool(boriview.isTimerRunning(name.text));
    }
    private static void f_repaint(_BoriView boriview)
    {
        boriview.repaint();
    }
    private static void f_getIntent(_BoriView boriview, _Container ret) throws Exception
    {
        shouldNotFragment(boriview);
        ret.var = new cIntent(boriview.bori.getIntent());
    }
    private static void f_setVolumeControlStream(_BoriView boriview, cInt streamType)
    {
        boriview.bori.setVolumeControlStream((int)streamType.value);
    }
    private static void f_startActivity(_BoriView boriview, cIntent intent)
    {
        boriview.bori.startActivity(intent.getIntent());
    }
    private static void f_notify(_BoriView boriview, cString message) throws Exception
    {
        boriview.notifyToParent(message.text, null);
    }
    private static void f_notifyV(_BoriView boriview, cString message, cVars vars) throws Exception
    {
        boriview.notifyToParent(message.text, vars);
    }
    private static void f_setBackColor(_BoriView boriview, cColor color)
    {
        boriview.setBackColor(color.intValue());
    }
}
