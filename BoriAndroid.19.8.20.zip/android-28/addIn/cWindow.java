package bori.sangdeuk.actionbar2;

import android.support.v4.content.ContextCompat;
import android.view.Window;
import android.view.WindowManager;

class cWindow extends cVar
{
    cWindow()
    {
        super(cType.TWINDOW);
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_STATUSBAR_COLOR = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_STATUSBAR_COLOR:
                    methodName = "setStatusBarColor";
                    f_setStatusBarColor(boriview, (cColor) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Window." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setStatusBarColor(_BoriView boriview, cColor color)
    {
        Window window = boriview.bori.getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(color.intValue());
    }
}
