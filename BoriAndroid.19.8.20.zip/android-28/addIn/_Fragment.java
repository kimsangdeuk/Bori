package bori.sangdeuk.test;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class _Fragment extends Fragment
{
    String viewName_;
    private _BoriView boriview_;
    private _BoriView parent_;

    public  _Fragment()
    {
        // Required empty public constructor
    }

    public static _Fragment newInstance(String viewName, _BoriView parent)
    {
        _Fragment fragment = new _Fragment();
        fragment.parent_ = parent;
        fragment.viewName_ = viewName;
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState)
    {
        xLinearLayout layout = null;
        try
        {
            if (boriview_ == null)
            {
                boriview_ = new _BoriView((BoriActivity) getActivity(), this, false);
                boriview_.init(viewName_ + ".view");
            }
            layout = boriview_.getLayout();
        }
        catch (Exception e)
        {
            _Alert.show(getActivity(), "Error", "Can not load " + viewName_);
        }
        return layout;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);
        boriview_.onCreate(savedInstanceState);
    }

    @Override
    public void onStart()
    {
        super.onStart();
        boriview_.onStart();
    }
    @Override
    public void onResume()
    {
        super.onResume();
        boriview_.onResume();
    }
    @Override
    public void onPause()
    {
        super.onPause();
        boriview_.onPause();
    }
    @Override
    public void onStop()
    {
        super.onStop();
        boriview_.onStop();
    }

    void command(String message, cVars vars) throws Exception
    {
        if (boriview_ == null)
            throw new Exception("This fragment is not fully initialized.");
        boriview_.onCommand(message, vars);
    }

    // used in notifyToParent() of _BoriView
    void notify(String message, cVars vars) { parent_.onNotify(viewName_, message, vars); }
}
