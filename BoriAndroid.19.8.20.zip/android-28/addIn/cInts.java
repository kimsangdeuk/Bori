package com.sangdeuk.fragment1;

import java.util.ArrayList;
import java.util.Random;

class cInts extends cVar
{
    private ArrayList<Long> list_;

    cInts()
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
    }
    cInts(cInts is)
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
        copyFrom(is);
    }
    cInts(Long[] arr)
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
        for (Long v : arr) list_.add(v);
    }

    int count () { return list_.size(); }
    void add(long value) { list_.add(value); }
    long get(int index) { return list_.get(index); }
    long[] getLongArray()
    {
        final long[] arr = new long[list_.size()];
        int index = 0;
        for (final Long value : list_)
        {
            arr[index++] = value;
        }
        return arr;
    }
    int[] getIntArray()
    {
        final int[] arr = new int[list_.size()];
        int index = 0;
        for (final Long value : list_)
        {
            arr[index++] = value.intValue();
        }
        return arr;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cInts)
        {
            cInts src = (cInts)var;
            for (Long val : src.list_) list_.add(val);
        }
    }
    @Override
    public void clear()
    {
        list_.clear();
    }
    @Override
    public String toString()
    {
        int ct = list_.size();
        if (ct < 1)
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append(list_.get(i));
        }
        sb.append(" ]");
        return new String(sb);
    }

    private void shuffleSelf()
    {
        int ct = list_.size();
        Random random = new Random();
        for (int i = ct - 1; i > 0; i--)
        {
            int r = random.nextInt(i+1);
            if (r != i)
            {
                long temp = list_.get(i);
                list_.set(i, list_.get(r));
                list_.set(r, temp);
            }
        }
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_GET = 2, FNC_SHUFFLE = 3,
    FNC_REPLACE = 4, FNC_CLEAR = 5, FNC_SWAP = 6;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_ADD: f_add((cInts)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_COUNT: f_count(ret, (cInts)stack.get(ct-1).var); break;
            case FNC_GET: f_getValue(ret, (cInts)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_SHUFFLE: f_shuffle(ret, (cInts)stack.get(ct-1).var); break;
            case FNC_REPLACE: f_replace((cInts)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_CLEAR: f_clear((cInts)stack.get(ct-1).var); break;
            case FNC_SWAP: f_swap((cInts)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Ints class method:" + nfunc);
        }
    }

    private static void f_add (cInts strs, cInt val)
    {
        strs.list_.add(val.value);
    }
    private static void f_count (_Container ret, cInts list)
    {
        ret.var = new cInt(list.list_.size());
    }
    private static void f_getValue (_Container ret, cInts list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index, "Ints.getValue");
        ret.var = new cInt(list.list_.get(index));
    }
    private static void f_shuffle (_Container ret, cInts is)
    {
        cInts is2 = new cInts(is);
        is2.shuffleSelf();
        ret.var = is2;
    }
    private static void f_replace (cInts is, cInt n, cInt value) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(is.list_, index, "Ints.replace");
        is.list_.set(index, value.value);
    }
    private static void f_clear (cInts list) { list.list_.clear(); }
    private static void f_swap (cInts list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1, "Ints.swap");
        _Util.checkIndex(list.list_, index2, "Ints.swap");
        long value = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, value);
    }
}
