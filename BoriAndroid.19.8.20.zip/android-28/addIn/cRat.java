package com.sangdeuk.fragment1;

import android.os.Parcel;
import android.os.Parcelable;

public class cRat extends cVar implements Parcelable
{
    long numerator;
    long denominator;
    static final int CMP_EQ = 0, CMP_LS = 1, CMP_GR = 2, CMP_LE = 3, CMP_GE = 4, CMP_NE = 5;

    cRat()
    {
        super(cType.TRAT);
        numerator = cInt.NULL;
        denominator = 1;
    }
    cRat(long value_)
    {
        super(cType.TRAT);
        numerator = value_;
        denominator = 1;
    }
    cRat(cRat r)
    {
        super(cType.TRAT);
        set(r);
    }
    cRat(cRat nu, cRat de)
    {
        super(cType.TRAT);
        set(nu, de);
    }
    cRat(Parcel parcel)
    {
        super(cType.TRAT);
        readFromParcel(parcel);
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeLong(numerator);
        dest.writeLong(denominator);
    }

    private void readFromParcel(Parcel in)
    {
        numerator = in.readLong();
        denominator = in.readLong();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cRat createFromParcel(Parcel in) {
            return new cRat(in);
        }

        public cRat[] newArray(int size) {
            return new cRat[size];
        }
    };

    //------------------------------------------------------------------
    void set(cRat rat)
    {
        set(rat.numerator, rat.denominator);
    }
    void set(long val)
    {
        numerator = val;
        denominator = 1;
    }
    void set(cRat nu, cRat de)
    {
        set(nu.numerator * de.denominator, nu.denominator * de.numerator);
    }
    void set(long nu, long de)
    {
        if (de == 0)
        {
            numerator = cInt.NULL;
            denominator = 1;
            return;
        }
        numerator = nu;
        denominator = de;
        if (isNull())
            return;
        if (denominator < 0)
        {
            numerator *= -1;
            denominator *= -1;
        }
        long gcd = getGcd(numerator, denominator);
        numerator /= gcd;
        denominator /= gcd;
    }
    void setNull()
    {
        numerator = cInt.NULL;
        denominator = 1;
    }
    private long getGcd(long smaller, long larger)
    {
        long rest;

        smaller = (smaller < 0) ? (-smaller) : smaller;	// get abs
        larger = (larger < 0) ? (-larger) : larger;	// get abs

        if (smaller == 0)
            return larger;
        else if (larger == 0)
            return smaller;

        if (smaller > larger)
        {
            rest = larger;
            larger = smaller;
            smaller = rest;
        }

        while ((rest = larger % smaller) != 0)
        {
            larger = smaller;
            smaller = rest;
        }
        return smaller;
    }


    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cRat)
        {
            numerator = ((cRat) var).numerator;
            denominator = ((cRat) var).denominator;
        }
    }
    @Override
    public void clear()
    {
        numerator = cInt.NULL;
        denominator = 1;
    }
    @Override
    public boolean isNull() { return numerator == cInt.NULL; }
    @Override
    public String toString()
    {
        if (isNull())
            return "NA";

        if (denominator == 1)
        {
            cInt int64 = new cInt(numerator);
            return int64.toString();
        }

        StringBuilder sb = new StringBuilder();
        // Integer part
        long n = numerator / denominator;
        long mod = numerator % denominator;
        if (n == 0)
        {
            if (numerator < 0 && mod != 0)
                sb.append("-0");
            else
                sb.append("0");
        }
        else
        {
            cInt int64 = new cInt(n);
            sb.append(int64.toString());
        }
        // 소수 부분
        if (mod != 0)
        {
            if (mod < 0)
                mod *= -1;
            StringBuilder sb2 = new StringBuilder();
            int decimal = 0;
            while (mod > 0 && decimal < 6)
            {
                mod *= 10;
                n = mod / denominator;
                mod = mod % denominator;
                sb2.append((char)(n + '0'));
                decimal++;
            }
            //if (mod > 0)
            //    sb2.append("..");
            sb.append('.');
            sb.append(sb2);
        }
        return new String(sb);
    }

    long getLong()
    {
        if (isNull())
            return cInt.NULL;
        return (numerator / denominator);
    }
    double getDouble()
    {
        if (isNull())
            return cDouble.NULL;
        return (double)numerator / (double)denominator;
    }

    void plusAssign(cRat r)
    {
        long nu = (numerator * r.denominator) + (r.numerator * denominator);
        long de = denominator * r.denominator;
        set(nu, de);
    }
    void minusAssign(cRat r)
    {
        long nu = (numerator * r.denominator) - (r.numerator * denominator);
        long de = denominator * r.denominator;
        set(nu, de);
    }
    void multiplyAssign(cRat r)
    {
        long nu = numerator * r.numerator;
        long de = denominator * r.denominator;
        set(nu, de);
    }
    void multiplyAssign(long val)
    {
        set(numerator * val, denominator);
    }
    void divAssign(cRat r)
    {
        long nu = numerator * r.denominator;
        long de = denominator * r.numerator;
        set(nu, de);
    }
    void modAssign(cRat r)
    {
        cRat t = new cRat(this, r);
        long	quo = t.getLong();
        t.set(r.numerator * quo, r.denominator);
        minusAssign(t);
    }

    static cRat parse(String s)
    {
        cRat rat = new cRat();

        if (s == null)
            return rat;
        int len = s.length();
        if (len == 0)
            return rat;

        int index = 0;
        boolean negative = false;
        if (s.charAt(index) == '+')
            index++;
        else if (s.charAt(index) == '-')
        {
            negative = true;
            index++;
        }
        long d = 1;
        boolean decimal_part = false;
        boolean exp_part = false;
        boolean exp_negative = false;
        StringBuilder bs = new StringBuilder();
        StringBuilder es = new StringBuilder();
        while (index < len)
        {
            char ch = s.charAt(index);
            if (ch == ',')
            {
                if (exp_part) // comma not allowed in exp part
                    return rat;
                index++;
                continue;
            }
            if (ch >= '0' && ch <= '9')
            {
                if (exp_part)
                {
                    if (es.length() > 1) // too big for exponent
                        return rat;
                    es.append(ch);
                }
                else
                {
                    bs.append(ch);
                    if (decimal_part)
                        d *= 10;
                }
            }
            else if (ch == '.')
            {
                if (exp_part || decimal_part) // not allowed
                    return rat;
                decimal_part = true;
            }
            else if (ch == 'e' || ch == 'E')
            {
                if (exp_part)
                    return rat;
                if (decimal_part)
                    decimal_part = false;
                exp_part = true;
                if (s.charAt(index + 1) == '-')
                {
                    index++;
                    exp_negative = true;
                }
                else if (s.charAt(index + 1) == '+')
                    index++;
            }
            else
                return rat;
            index++;
        }

        long n = Long.parseLong(new String(bs));

        int exp = es.length() > 0 ? Integer.parseInt(new String(es)) : 0;
        if (exp > 0)
        {
            if (exp_negative)
            {
                while (exp-- > 0)
                    d *= 10;
            }
            else
            {
                while (exp-- > 0)
                    n *= 10;
            }
        }

        rat.numerator = (negative) ? (n * -1) : n;
        rat.denominator = d;
        return rat;
    }

    int compare(cRat r)
    {
        int cmp = 0;

        if (isNull() && r.isNull())
            cmp = 0;
        else if (isNull())
            cmp = -1;
        else if (r.isNull())
            cmp = 1;
        else if (numerator == r.numerator && denominator == r.denominator)
            cmp = 0;
        else
        {
            boolean negative = numerator < 0;
            boolean negativeR = r.numerator < 0;
            if (negative != negativeR)
            {
                if (negativeR)
                    cmp = 1;
                else
                    cmp = -1;
            }
            else if (numerator * r.denominator < denominator * r.numerator)
                cmp = -1;
            else
                cmp = 1;
        }
        return cmp;
    }

    private cRat abs()
    {
        cRat r = new cRat(this);    // copy
        if (!r.isNull())
        {
            if (r.numerator < 0)
                r.numerator *= -1;
        }
        return r;
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_PARSE = 1, FNC_TOSTRING = 2, FNC_ABS = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_NEW:
                // static method - don't use ct-2
                f_new(ret, (cRat)stack.get(ct-1).var);
                break;
            case FNC_PARSE:
                // static method - don't use ct-2
                f_parse(ret, (cString)stack.get(ct-1).var);
                break;
            case FNC_TOSTRING: f_toString(ret, (cRat)stack.get(ct-1).var); break;
            case FNC_ABS: f_abs(ret, (cRat)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Rat class method:" + nfunc);
        }
    }

    private static void f_new(_Container ret, cRat in)
    {
        ret.var = new cRat(in);
    }
    private static void f_parse(_Container ret, cString s)
    {
        ret.var = cRat.parse(s.text);
    }
    private static void f_toString(_Container ret, cRat val)
    {
        ret.var = new cString();
        ((cString)ret.var).set(val.toString());
    }
    private static void f_abs(_Container ret, cRat val)
    {
        ret.var = val.abs();
    }
}
