package com.sangdeuk.fragment1;

public class cCheckBox extends cControl
{
    cCheckBox()
    {
        super(cType.TC_CHECK);
    }
    cCheckBox(xCheckBox view_)
    {
        super(cType.TC_CHECK);
        view = view_;
    }

    String getText() { return ((xCheckBox)view).getText().toString(); }
    void setText(String text) { ((xCheckBox)view).setText(text); }

    //---------------------------------------------------------------------
    private static final int FNC_SET_CHECKED = 0, FNC_IS_CHECKED = 1, FNC_SET_TEXT = 2, FNC_GET_TEXT = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_CHECKED: f_setChecked((cCheckBox)stack.get(ct-2).var, (cBool)stack.get(ct-1).var); break;
            case FNC_IS_CHECKED: f_isChecked(ret, (cCheckBox)stack.get(ct-1).var); break;
            case FNC_SET_TEXT: f_setText((cCheckBox)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_GET_TEXT: f_getText(ret, (cCheckBox)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported CheckBox class method:" + nfunc);
        }
    }

    private static void f_setChecked(cCheckBox checkBox, cBool checked)
    {
        ((xCheckBox)checkBox.view).setChecked(checked.isTrue());
    }
    private static void f_isChecked(_Container ret, cCheckBox checkBox)
    {
        ret.var = new cBool();
        ((cBool)ret.var).set(((xCheckBox)checkBox.view).isChecked());
    }
    private static void f_setText(cCheckBox checkBox, cString s)
    {
        checkBox.setText(s.text());
    }
    private static void f_getText(_Container ret, cCheckBox checkBox)
    {
        ret.var = new cString(checkBox.getText());
    }
}
