package bori.sangdeuk.test;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xPaper extends View
{
    private _BoriView boriview_;
    private String methodOnDraw_ = null;
    private String methodOnSizeChanged_ = null;
    private _ConList paramsDraw;

    xPaper(Context context)
    {
        super(context);
    }

    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));

        paramsDraw = new _ConList();
        paramsDraw.add(new _Container(new cCanvas()));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            switch (name)
            {
                case "onDraw": methodOnDraw_ = method; break;
                case "onSizeChanged": methodOnSizeChanged_ = method; break;
                case "onClick": _Tag.get(this).setOnClick(method); break;
                case "onLongClick": _Tag.get(this).setOnLongClick(method); break;
                case "onTouch": _Tag.get(this).setOnTouch(method); break;
            }
        }
    }

    @Override
    protected void onDraw (Canvas canvas)
    {
        if (methodOnDraw_ != null)
        {
            _Container con = paramsDraw.get(0);
            ((cCanvas)con.var).set(canvas);
            boriview_.call(methodOnDraw_, paramsDraw);
        }
    }

    @Override
    protected void onSizeChanged (int w, int h, int oldw, int oldh)
    {
        if (methodOnSizeChanged_ != null)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cInt(w)));
            params.add(new _Container(new cInt(h)));
            boriview_.call(methodOnSizeChanged_, params);
        }
    }
}

