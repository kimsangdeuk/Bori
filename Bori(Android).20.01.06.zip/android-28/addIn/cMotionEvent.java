package com.sangdeuk.fragment1;

import android.view.MotionEvent;

class cMotionEvent extends cVar
{
    private MotionEvent event_;

    cMotionEvent()
    {
        super(cType.TMOTIONEVENT);
    }
    cMotionEvent(MotionEvent event)
    {
        super(cType.TMOTIONEVENT);
        event_ = event;
    }

    //-----------------------------------------------------------
    private static final int FLD_ACTION_DOWN = 0, FLD_ACTION_MOVE = 1, FLD_ACTION_UP = 2;
    static void getVar(int n, _Container ret, _Container con)
    {
        switch(n)
        {
            case FLD_ACTION_DOWN: ret.var = new cInt(MotionEvent.ACTION_DOWN); break;
            case FLD_ACTION_MOVE: ret.var = new cInt(MotionEvent.ACTION_MOVE); break;
            case FLD_ACTION_UP: ret.var = new cInt(MotionEvent.ACTION_UP); break;
        }
    }

    //-----------------------------------------------------------
    private static final int FNC_GET_ACTION_MASKED = 0, FN_GET_X = 1, FN_GET_Y = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_GET_ACTION_MASKED: f_getActionMasked(ret, (cMotionEvent)stack.get(ct-1).var); break;
            case FN_GET_X: f_getX(ret, (cMotionEvent)stack.get(ct-1).var); break;
            case FN_GET_Y: f_getY(ret, (cMotionEvent)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported MotionEvent class method:" + nfunc);
        }
    }

    private static void f_getActionMasked(_Container ret, cMotionEvent event)
    {
        ret.var = new cInt(event.event_.getActionMasked());
    }
    private static void f_getX(_Container ret, cMotionEvent event)
    {
        ret.var = new cDouble(event.event_.getX());
    }
    private static void f_getY(_Container ret, cMotionEvent event)
    {
        ret.var = new cDouble(event.event_.getY());
    }
}
