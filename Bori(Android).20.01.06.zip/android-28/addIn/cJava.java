package bori.example.whereru;

import android.os.Bundle;

class cJava extends cVar
{
    cJava()
    {
        super(cType.TJAVA);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_CALL = 0, FNC_CALL_IN = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_CALL:
                    methodName = "call";
                    f_call(boriview, ret, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_CALL_IN:
                    methodName = "call";
                    f_call2(boriview, ret, (cString)stack.get(ct - 2).var, (cVars)stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Java." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_call (_BoriView boriview, _Container ret, cString name) throws Exception
    {
        f_call2(boriview, ret, name, new cVars());
    }
    private static void f_call2 (_BoriView boriview, _Container ret, cString name, cVars in) throws Exception
    {
        Bundle out = JavaCall.call(boriview.bori, name.text, _Bundle.getBundle(in));
        ret.var = _Bundle.readBundle(out);
    }
}
