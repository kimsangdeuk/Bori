package bori.example.time;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.widget.DatePicker;
import android.widget.TimePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

class cTime extends cVar
{
    private GregorianCalendar cal_;

    cTime()
    {
        super(cType.TTIME);
        cal_ = new GregorianCalendar();
    }

    //---------------------------------------------------------------------
    private static final int FNC_YEAR = 0, FNC_MONTH = 1, FNC_DAY = 2, FNC_HOUR = 3, FNC_MINUTE = 4, FNC_SECOND = 5, FNC_MILLISECOND = 6,
            FNC_DAY_OF_WEEK = 7, FNC_TOSTRING = 8, FNC_TOSTRING2 = 9,
            FNC_DATEPICKER = 10, FNC_TIMEPICKER = 11,
            FNC_GET_TIME_IN_MILLIS = 12, FNC_SET_TIME_IN_MILLIS = 13,
            FNC_SET = 14, FNC_SET2 = 15,
            FNC_ADD_YEARS = 16, FNC_ADD_MONTHS = 17, FNC_ADD_DAYS = 18,
            FNC_ADD_HOURS = 19, FNC_ADD_MINUTES = 20, FNC_ADD_SECONDS = 21;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_YEAR:
                    methodName = "year";
                    f_year(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_MONTH:
                    methodName = "month";
                    f_month(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_DAY:
                    methodName = "day";
                    f_day(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_HOUR:
                    methodName = "hour";
                    f_hour(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_MINUTE:
                    methodName = "minute";
                    f_minute(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_SECOND:
                    methodName = "second";
                    f_second(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_MILLISECOND:
                    methodName = "millisecond";
                    f_millisecond(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_DAY_OF_WEEK:
                    methodName = "dayOfWeek";
                    f_dayOfWeek(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_TOSTRING:
                    methodName = "toString";
                    f_toString(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_TOSTRING2:
                    methodName = "toString";
                    f_toString2(ret, (cTime) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_DATEPICKER:
                    methodName = "datePicker";
                    f_datePicker(boriview, (cInt) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var,
                            (cInt) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_TIMEPICKER:
                    methodName = "timePicker";
                    f_timePicker(boriview, (cInt) stack.get(ct - 4).var,
                            (cInt) stack.get(ct - 3).var, (cBool) stack.get(ct - 2).var,
                            (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TIME_IN_MILLIS:
                    methodName = "getTimeInMillis";
                    f_getTimeInMillis(ret, (cTime) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TIME_IN_MILLIS:
                    methodName = "setTimeInMillis";
                    f_setTimeInMillis((cTime) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET:
                    methodName = "set";
                    f_set((cTime) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET2:
                    methodName = "set";
                    f_set2((cTime) stack.get(ct - 7).var, (cInt) stack.get(ct - 6).var, (cInt) stack.get(ct - 5).var, (cInt) stack.get(ct - 4).var,
                            (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_YEARS:
                    methodName = "addYears";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.YEAR, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_MONTHS:
                    methodName = "addMonths";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.MONTH, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_DAYS:
                    methodName = "addDays";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.DAY_OF_MONTH, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_HOURS:
                    methodName = "addHours";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.HOUR_OF_DAY, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_MINUTES:
                    methodName = "addMinutes";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.MINUTE, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_SECONDS:
                    methodName = "addSeconds";
                    f_add((cTime) stack.get(ct - 2).var, Calendar.SECOND, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Time." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_year(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.YEAR));
    }
    private static void f_month(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.MONTH) + 1);
    }
    private static void f_day(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.DATE));
    }
    private static void f_hour(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.HOUR_OF_DAY));
    }
    private static void f_minute(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.MINUTE));
    }
    private static void f_second(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.SECOND));
    }
    private static void f_millisecond(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.MILLISECOND));
    }
    private static void f_dayOfWeek(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.get(Calendar.DAY_OF_WEEK));
    }
    private static void f_toString(_Container ret, cTime time)
    {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/dd H:m:s");
        String s = sdf.format(time.cal_.getTime());
        ret.var = new cString(s);
    }
    private static void f_toString2(_Container ret, cTime time, cString pattern)
    {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat(pattern.text);
        String s = sdf.format(time.cal_.getTime());
        ret.var = new cString(s);
    }
    private static void f_datePicker(_BoriView boriview, cInt year, cInt month, cInt day, cString methodName)
    {
        _DatePickerDialog dlg = _DatePickerDialog.newInstance(boriview, (int) year.value, (int)month.value, (int)day.value, methodName.text);
        dlg.show(boriview.bori.getSupportFragmentManager(), "datePicker");
    }
    private static void f_timePicker(_BoriView boriview, cInt hour, cInt minute, cBool is24Hour, cString methodName)
    {
        _TimePickerDialog dlg = _TimePickerDialog.newInstance(boriview, (int)hour.value, (int)minute.value,
                is24Hour.isTrue(), methodName.text);
        dlg.show(boriview.bori.getSupportFragmentManager(), "timePicker");
    }
    private static void f_getTimeInMillis(_Container ret, cTime time)
    {
        ret.var = new cInt(time.cal_.getTimeInMillis());
    }
    private static void f_setTimeInMillis(cTime time, cInt millis)
    {
        time.cal_.setTimeInMillis(millis.value);
    }
    private static void f_set(cTime time, cInt year, cInt month, cInt day)
    {
        time.cal_.set((int)year.value, (int)month.value - 1, (int)day.value, 0, 0, 0);
    }
    private static void f_set2(cTime time, cInt year, cInt month, cInt day, cInt hour, cInt minute, cInt second)
    {
        time.cal_.set((int)year.value, (int)month.value - 1, (int)day.value, (int)hour.value, (int)minute.value, (int)second.value);
    }
    private static void f_add(cTime time, int field, cInt amount)
    {
        time.cal_.add(field, (int)amount.value);
    }

    //-----------------------------------------------------------------------------
    public static class _DatePickerDialog extends DialogFragment implements DatePickerDialog.OnDateSetListener
    {
        private _BoriView boriview_;
        private int year_;
        private int month_;
        private int day_;
        private String methodName_;

        public static _DatePickerDialog newInstance (_BoriView boriview, int year, int month, int day, String methodName)
        {
            _DatePickerDialog dlg = new _DatePickerDialog();
            dlg.boriview_ = boriview;
            dlg.year_ = year;
            dlg.month_ = month;
            dlg.day_ = day;
            dlg.methodName_ = methodName;
            return dlg;
        }

        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState)
        {
            return new DatePickerDialog(boriview_.bori, this, year_, month_ - 1, day_);
        }

        @Override
        public void onDateSet(DatePicker view, int year, int month, int day)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cInt(year)));
            params.add(new _Container(new cInt(month+1)));
            params.add(new _Container(new cInt(day)));
            boriview_.call(methodName_ + "(Int,Int,Int)", params);
        }
    }
    public static class _TimePickerDialog extends DialogFragment implements TimePickerDialog.OnTimeSetListener
    {
        private _BoriView boriview_;
        private int hour_;
        private int minute_;
        private boolean is24Hour_;
        private String methodName_;

        public static _TimePickerDialog newInstance (_BoriView boriview, int hour, int minute, boolean is24Hour, String methodName)
        {
            _TimePickerDialog dlg = new _TimePickerDialog();
            dlg.boriview_ = boriview;
            dlg.hour_ = hour;
            dlg.minute_ = minute;
            dlg.is24Hour_ = is24Hour;
            dlg.methodName_ = methodName;
            return dlg;
        }

        @NonNull
        @Override
        public Dialog onCreateDialog(@Nullable Bundle savedInstanceState)
        {
            return new TimePickerDialog(boriview_.bori, this, hour_, minute_, is24Hour_);
        }

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cInt(hourOfDay)));
            params.add(new _Container(new cInt(minute)));
            boriview_.call(methodName_ + "(Int,Int)", params);
        }
    }
}
