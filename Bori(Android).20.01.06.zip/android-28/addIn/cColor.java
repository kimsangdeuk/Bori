package bori.sangdeuk.tablayout_viewpager;

import android.graphics.Color;
import android.os.Parcel;
import android.os.Parcelable;

class cColor extends cVar implements Parcelable
{
    private int alpha_;
    private int red_;
    private int green_;
    private int blue_;

    cColor()
    {
        super(cType.TCOLOR);
         alpha_ = 0xFF;
         red_ = 0;
         green_ = 0;
         blue_ = 0;
    }
    cColor(int alpha, int red, int green, int blue)
    {
        super(cType.TCOLOR);
        alpha_ = alpha;
        red_ = red;
        green_ = green;
        blue_ = blue;
    }
    cColor(int red, int green, int blue)
    {
        super(cType.TCOLOR);
        alpha_ = 0xFF;
        red_ = red;
        green_ = green;
        blue_ = blue;
    }
    cColor(int value)
    {
        super(cType.TCOLOR);
        alpha_ = (value >> 24) & 0xff;
        red_ = (value >> 16) & 0xff;
        green_ = (value >> 8) & 0xff;
        blue_ = (value) & 0xff;
    }
    cColor(Parcel parcel)
    {
        super(cType.TCOLOR);
        readFromParcel(parcel);
    }
    int intValue()
    {
        return (alpha_ & 0xff) << 24 | (red_ & 0xff) << 16 | (green_ & 0xff) << 8 | (blue_ & 0xff);
    }
    private void set(int red, int green, int blue)
    {
        alpha_ = 0xFF;
        red_ = red;
        green_ = green;
        blue_ = blue;
    }
    private void set(int alpha, int red, int green, int blue)
    {
        alpha_ = alpha;
        red_ = red;
        green_ = green;
        blue_ = blue;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cColor)
        {
            cColor src = (cColor)var;
            alpha_ = src.alpha_;
            red_ = src.red_;
            green_ = src.green_;
            blue_ = src.blue_;
        }
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(alpha_);
        dest.writeInt(red_);
        dest.writeInt(green_);
        dest.writeInt(blue_);
    }

    private void readFromParcel(Parcel in)
    {
        alpha_ = in.readInt();
        red_ = in.readInt();
        green_ = in.readInt();
        blue_ = in.readInt();
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cColor createFromParcel(Parcel in) {
            return new cColor(in);
        }

        public cColor[] newArray(int size) {
            return new cColor[size];
        }
    };

    //-----------------------------------------------------------
    private static final int FLD_BLACK = 0, FLD_BLUE = 1, FLD_CYAN = 2, FLD_DKGRAY = 3, FLD_GRAY = 4, FLD_GREEN = 5,
            FLD_LTGRAY = 6, FLD_MAGENTA = 7, FLD_RED = 8, FLD_TRANSPARENT = 9, FLD_WHITE = 10, FLD_YELLOW = 11;
    static void getVar(int n, _Container ret, _Container con)
    {
        switch (n)
        {
            case FLD_BLACK: ret.var = new cColor(Color.BLACK); break;
            case FLD_BLUE: ret.var = new cColor(Color.BLUE); break;
            case FLD_CYAN: ret.var = new cColor(Color.CYAN); break;
            case FLD_DKGRAY: ret.var = new cColor(Color.DKGRAY); break;
            case FLD_GRAY: ret.var = new cColor(Color.GRAY); break;
            case FLD_GREEN: ret.var = new cColor(Color.GREEN); break;
            case FLD_LTGRAY: ret.var = new cColor(Color.LTGRAY); break;
            case FLD_MAGENTA: ret.var = new cColor(Color.MAGENTA); break;
            case FLD_RED: ret.var = new cColor(Color.RED); break;
            case FLD_TRANSPARENT: ret.var = new cColor(Color.TRANSPARENT); break;
            case FLD_WHITE: ret.var = new cColor(Color.WHITE); break;
            case FLD_YELLOW: ret.var = new cColor(Color.YELLOW); break;
        }
    }

    //-------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_NEW2 = 1, FNC_SET = 2, FNC_SET2 = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_NEW2:
                    methodName = "new";
                    f_new2(ret, (cInt) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET:
                    methodName = "set";
                    f_set((cColor) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET2:
                    methodName = "set";
                    f_set2((cColor) stack.get(ct - 5).var, (cInt) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Color." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cInt red, cInt green, cInt blue)
    {
        ret.var = new cColor((int)red.value, (int)green.value, (int)blue.value);
    }
    private static void f_new2(_Container ret, cInt alpha, cInt red, cInt green, cInt blue)
    {
        ret.var = new cColor((int)alpha.value, (int)red.value, (int)green.value, (int)blue.value);
    }
    private static void f_set(cColor color, cInt red, cInt green, cInt blue)
    {
        color.set((int)red.value, (int)green.value, (int)blue.value);
    }
    private static void f_set2(cColor color, cInt alpha, cInt red, cInt green, cInt blue)
    {
        color.set((int)alpha.value, (int)red.value, (int)green.value, (int)blue.value);
    }
}
