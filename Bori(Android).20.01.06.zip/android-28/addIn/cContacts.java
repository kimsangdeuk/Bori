package bori.example.contacts;

import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

class cContacts extends cVar
{
    cContacts()
    {
        super(cType.TCONTACTS);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_LIST = 0, FNC_SEARCH = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_LIST:
                    methodName = "getList";
                    f_getList(boriview, ret);
                    break;
                case FNC_SEARCH:
                    methodName = "search";
                    f_search(boriview, ret, (cString)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Contacts." + methodName + "\n" + e.getMessage());
        }
    }

    private static Cursor _getList (_BoriView boriview, String selection) throws Exception
    {
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = new String[]{
                ContactsContract.Contacts._ID,
                //ContactsContract.Contacts.PHOTO_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                "data2"
        };

        String sortOrder = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC";

        return boriview.bori.getContentResolver().query(uri, projection, selection, null, sortOrder);
    }

    private static void f_getList (_BoriView boriview, _Container ret) throws Exception
    {
        ret.var = cRset.fromCursor(_getList(boriview, null));
    }
    private static void f_search (_BoriView boriview, _Container ret, cString name, cString number, cString type) throws Exception
    {
        String selection = null;
        if (! name.text.isEmpty())
            selection = "display_name LIKE '%" + name.text + "%'";
        if (! number.text.isEmpty())
        {
            if (selection == null)
                selection = "";
            else
                selection += " AND ";
            selection += "data1 LIKE '%" + number.text + "%'";
        }
        if (! type.text.isEmpty())
        {
            if (selection == null)
                selection = "";
            else
                selection += " AND ";
            selection += "data2 = '" + type.text + "'";
        }
        ret.var = cRset.fromCursor(_getList(boriview, selection));
    }
}
