package bori.sangdeuk.floatingactionbutton;

import android.view.View;
import android.view.ViewGroup;

class cControl extends cVar
{
    View view;

    cControl()
    {
        super(cType.TCONTROL);
    }
    cControl(int type0)
    {
        super(type0);
    }
    cControl(View view0)
    {
        super(cType.TCONTROL);
        view = view0;
    }

    @Override
    public void copyFrom(cVar var)
    {
        view = null;
        if (var instanceof cControl)
            view = ((cControl)var).view;
    }

    @Override
    public void clear()
    {
        view = null;
    }

    //---------------------------------------------------------------------
    private static final int FNC_SET_VALUE = 0, FNC_GET_VALUE = 1, FNC_FIND_CHILD = 2, FNC_REPAINT = 3,
        FNC_SET_ENABLED = 4, FNC_SET_VISIBLE = 5,
            FNC_SET_ON_CLICK = 6, FNC_SET_ON_TOUCH = 7, FNC_GET_NAME = 8, FNC_SET_PADDING = 9,
            FNC_SET_BACK_COLOR = 10,
            FNC_GET_WIDTH = 11, FNC_GET_HEIGHT = 12, FNC_IS_SHOWN = 13;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_VALUE:
                    methodName = "setValue";
                    f_setValue((cControl) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_GET_VALUE:
                    methodName = "getValue";
                    f_getValue(ret, (cControl) stack.get(ct - 1).var);
                    break;
                case FNC_FIND_CHILD:
                    methodName = "findChild";
                    f_findChild(ret, (cControl) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_REPAINT:
                    methodName = "repaint";
                    f_repaint((cControl) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ENABLED:
                    methodName = "setEnabled";
                    f_setEnabled((cControl) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_SET_VISIBLE:
                    methodName = "setVisible";
                    f_setVisible((cControl) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ON_CLICK:
                    methodName = "setOnClick";
                    f_setOnClick((cControl) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ON_TOUCH:
                    methodName = "setOnTouch";
                    f_setOnTouch((cControl) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_NAME:
                    methodName = "getName";
                    f_getName(ret, (cControl) stack.get(ct - 1).var);
                    break;
                case FNC_SET_PADDING:
                    methodName = "setPadding";
                    f_setPadding((cControl) stack.get(ct - 5).var,
                            (cInt) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var,
                            (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SET_BACK_COLOR:
                    methodName = "setBackColor";
                    f_setBackColor((cControl) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_GET_WIDTH:
                    methodName = "getWidth";
                    f_getWidth(ret, (cControl) stack.get(ct - 1).var);
                    break;
                case FNC_GET_HEIGHT:
                    methodName = "getHeight";
                    f_getHeight(ret, (cControl) stack.get(ct - 1).var);
                    break;
                case FNC_IS_SHOWN:
                    methodName = "isShown";
                    f_isShown(ret, (cControl) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Control." + methodName + "\n" + e.getMessage());
        }
    }

    private static void checkNullTag(_Tag info) throws Exception
    {
        if (info == null)
            throw new Exception("View tag is null.");

    }
    private static void f_setValue(cControl control, cInt v) throws Exception
    {
        _Tag info = _Tag.get(control.view);
        checkNullTag(info);
        info.value = v.value;
    }
    private static void f_getValue(_Container ret, cControl control) throws Exception
    {
        _Tag info = _Tag.get(control.view);
        checkNullTag(info);
        ret.var = new cInt(info.value);
    }
    private static View findChild(ViewGroup group, String name)
    {
        for (int i = 0, ct = group.getChildCount(); i < ct; i++)
        {
            View child = group.getChildAt(i);
            if (child instanceof ViewGroup)
            {
                child = findChild((ViewGroup) child, name);
                if (child != null)
                    return child;
            }
            else
            {
                _Tag info = _Tag.get(child);
                if (info != null)
                {
                    if (info.getName().equals(name))
                        return child;
                }
            }
        }
        return null;
    }
    private static void f_findChild(_Container ret, cControl parent, cString name) throws Exception
    {
        if (!(parent.view instanceof ViewGroup))
            throw new Exception("The control does not have children.");
        ViewGroup vgroup = (ViewGroup)parent.view;
        View child = findChild(vgroup, name.text);
        if (child == null)
            throw new Exception("Can not find the control by the name '" + name.text + "'.");
        ret.var = new cControl(child);
    }
    private static void f_repaint(cControl control)
    {
        control.view.invalidate();
    }
    private static void f_setEnabled(cControl control, cBool enabled)
    {
        control.view.setEnabled(enabled.isTrue());
    }
    private static void f_setVisible(cControl control, cBool visible)
    {
        control.view.setVisibility(visible.isTrue() ? View.VISIBLE : View.INVISIBLE);
    }
    private static void f_setOnClick(cControl control, cString funcName) throws Exception
    {
        String sig = funcName + "(Control)";
        _Tag info = _Tag.get(control.view);
        checkNullTag(info);
        info.setOnClick(sig);
    }
    private static void f_setOnTouch(cControl control, cString funcName) throws Exception
    {
        String sig = funcName + "(Control,MotionEvent)";
        _Tag info = _Tag.get(control.view);
        checkNullTag(info);
        info.setOnTouch(sig);
    }
    private static void f_getName(_Container ret, cControl control) throws Exception
    {
        _Tag info = _Tag.get(control.view);
        checkNullTag(info);
        ret.var = new cString(info.getName());
    }
    private static void f_setPadding(cControl control, cInt left, cInt top, cInt right, cInt bottom)
    {
        ((View)control.view).setPadding((int)left.value, (int)top.value, (int)right.value, (int)bottom.value);
    }
    private static void f_setBackColor(cControl control, cColor color)
    {
        ((View)control.view).setBackgroundColor(color.intValue());
    }
    private static void f_getWidth(_Container ret, cControl control) throws Exception
    {
        ret.var = new cInt(control.view.getWidth());
    }
    private static void f_getHeight(_Container ret, cControl control) throws Exception
    {
        ret.var = new cInt(control.view.getWidth());
    }
    private static void f_isShown(_Container ret, cControl control) throws Exception
    {
        ret.var = new cBool(control.view.isShown());
    }
}
