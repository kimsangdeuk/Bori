package bori.sangdeuk.string;

import android.graphics.Typeface;

class cTypeface extends cVar
{
    Typeface tf_;

    cTypeface()
    {
        super(cType.TTYPEFACE);
        tf_ = Typeface.DEFAULT;
    }
    cTypeface(Typeface tf)
    {
        super(cType.TTYPEFACE);
        tf_ = tf;
    }

    //-----------------------------------------------------------
    private static final int FLD_DEFAULT = 0, FLD_MONOSPACE = 1, FLD_SANS_SERIF = 2, FLD_SERIF = 3,
            FLD_BOLD = 4, FLD_BOLD_ITALIC = 5, FLD_ITALIC = 6, FLD_NORMAL = 7;
    static void getVar(int n, _Container ret, _Container con)
    {
        cTypeface t = (cTypeface)con.var;
        switch(n)
        {
            case FLD_DEFAULT: ret.var = new cTypeface(Typeface.DEFAULT); break;
            case FLD_MONOSPACE: ret.var = new cTypeface(Typeface.MONOSPACE); break;
            case FLD_SANS_SERIF: ret.var = new cTypeface(Typeface.SANS_SERIF); break;
            case FLD_SERIF: ret.var = new cTypeface(Typeface.SERIF); break;
            case FLD_BOLD: ret.var = new cInt(Typeface.BOLD); break;
            case FLD_BOLD_ITALIC: ret.var = new cInt(Typeface.BOLD_ITALIC); break;
            case FLD_ITALIC: ret.var = new cInt(Typeface.ITALIC); break;
            case FLD_NORMAL: ret.var = new cInt(Typeface.NORMAL); break;
        }
    }

}
