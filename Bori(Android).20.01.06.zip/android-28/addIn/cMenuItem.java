package com.sangdeuk.fragment1;

import android.view.MenuItem;

public class cMenuItem extends cVar
{
    MenuItem item;

    cMenuItem()
    {
        super(cType.TMENUITEM);
    }
    cMenuItem(MenuItem item0)
    {
        super(cType.TMENUITEM);
        item = item0;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cMenuItem)
            item = ((cMenuItem)var).item;
    }

    private static final int FNC_GET_ID = 0, FNC_GET_TEXT = 1, FNC_SET_ICON = 2,
            FNC_SET_SHOW_AS_ACTION = 3, FNC_SET_ENABLED = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_GET_ID: f_getId(ret, (cMenuItem)stack.get(ct-1).var); break;
            case FNC_GET_TEXT: f_getText(ret, (cMenuItem)stack.get(ct-1).var); break;
            case FNC_SET_ICON: f_setIcon(boriview, (cMenuItem)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_SET_SHOW_AS_ACTION: f_setShowAsAction((cMenuItem)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_SET_ENABLED: f_setEnabled((cMenuItem)stack.get(ct-2).var, (cBool)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported MenuItem class method:" + nfunc);
        }
    }

    private static void f_getId(_Container ret, cMenuItem item)
    {
        ret.var = new cInt();
        ((cInt)ret.var).value = item.item.getItemId();
    }
    private static void f_getText(_Container ret, cMenuItem item)
    {
        ret.var = new cString();
        ((cString)ret.var).text = item.item.getTitle().toString();
    }
    private static void f_setIcon(_BoriView boriview, cMenuItem item, cString iconName)
    {
        int id = boriview.bori.getResources().getIdentifier(iconName.text, null, boriview.bori.getPackageName());
        item.item.setIcon(id);
    }
    private static void f_setShowAsAction(cMenuItem item, cString soption) throws Exception
    {
       int  option;
       switch(soption.text)
       {
           case "always": option = MenuItem.SHOW_AS_ACTION_ALWAYS; break;
           case "never": option = MenuItem.SHOW_AS_ACTION_NEVER; break;
           case "ifRoom": option = MenuItem.SHOW_AS_ACTION_IF_ROOM; break;
           default:
               throw new Exception("Invalid option in setShowAsAction():" + soption.text);
       }
       item.item.setShowAsAction(option);
    }
    private static void f_setEnabled(cMenuItem item, cBool enabled)
    {
        item.item.setEnabled(enabled.isTrue());
    }
}
