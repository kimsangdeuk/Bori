package com.sangdeuk.fragment1;

import android.media.MediaPlayer;

class cMediaPlayer extends cVar
{
    MediaPlayer mp_;

    cMediaPlayer()
    {
        super(cType.TMEDIAPLAYER);
    }
    cMediaPlayer(MediaPlayer mp)
    {
        super(cType.TMEDIAPLAYER);
        mp_ = mp;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cMediaPlayer)
            mp_ = ((cMediaPlayer)var).mp_;
    }

    private static final int FNC_FROM_RESOURCE = 0, FN_START = 1, FN_STOP = 2, FN_RELEASE = 3,
            FNC_IS_PLAYING = 4, FNC_PREPARE = 5;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_FROM_RESOURCE: f_fromResource(boriview, ret, (cString)stack.get(ct-1).var); break;
            case FN_START: f_start((cMediaPlayer)stack.get(ct-1).var); break;
            case FN_STOP: f_stop((cMediaPlayer)stack.get(ct-1).var); break;
            case FN_RELEASE: f_release((cMediaPlayer)stack.get(ct-1).var); break;
            case FNC_IS_PLAYING: f_isPlaying(ret, (cMediaPlayer)stack.get(ct-1).var); break;
            case FNC_PREPARE: f_prepare((cMediaPlayer)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported MediaPlayer class method:" + nfunc);
        }
    }

    private static void checkNullPlayer(MediaPlayer mp, String methodName) throws Exception
    {
        if (mp == null)
            throw new Exception("> MediaPlayer." + methodName + "\nNull media player.");
    }

    private static void f_fromResource(_BoriView boriview, _Container ret, cString resname) throws Exception
    {
        MediaPlayer mp = MediaPlayer.create(boriview.bori, _Util.getResID(boriview.bori, resname.text));
        checkNullPlayer(mp, "fromResource");
        ret.var = new cMediaPlayer(mp);
    }
    private static void f_start(cMediaPlayer mp) throws Exception
    {
        checkNullPlayer(mp.mp_, "start");
        mp.mp_.start();
    }
    private static void f_stop(cMediaPlayer mp) throws Exception
    {
        checkNullPlayer(mp.mp_, "stop");
        mp.mp_.stop();
    }
    private static void f_release(cMediaPlayer mp) throws Exception
    {
        checkNullPlayer(mp.mp_, "release");
        mp.mp_.release();
        mp.mp_ = null;
    }
    private static void f_isPlaying(_Container ret, cMediaPlayer mp) throws Exception
    {
        checkNullPlayer(mp.mp_, "isPlaying");
        ret.var = new cBool(mp.mp_.isPlaying());
    }
    private static void f_prepare(cMediaPlayer mp) throws Exception
    {
        checkNullPlayer(mp.mp_, "prepare");
        mp.mp_.prepare();
    }
}
