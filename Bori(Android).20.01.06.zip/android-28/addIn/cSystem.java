package com.sangdeuk.fragment1;

public class cSystem extends cVar
{
    cSystem()
    {
        super(cType.TSYSTEM);
    }

    private static final int FNC_CURRENT_TIME_MILLIS = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_CURRENT_TIME_MILLIS: f_currentTimeMillis(ret); break;
            default:
                throw new Exception("Unsupported System class method:" + nfunc);
        }
    }

    private static void f_currentTimeMillis(_Container ret)
    {
        ret.var = new cInt(System.currentTimeMillis());
    }
}
