package bori.android.check_radio;

public class cRadioButton extends cButton
{
    cRadioButton()
    {
        super(cType.TC_RADIO);
    }
    cRadioButton(xRadioButton view_)
    {
        super(cType.TC_RADIO);
        view = view_;
    }

    String getText() { return ((xRadioButton)view).getText().toString(); }
    void setText(String text) { ((xRadioButton)view).setText(text); }

    //---------------------------------------------------------------------
    private static final int FNC_SET_CHECKED = 0, FNC_IS_CHECKED = 1, FNC_SET_TEXT = 2, FNC_GET_TEXT = 3,
    FNC_SET_BUTTON_COLOR = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_CHECKED:
                    methodName = "setChecked";
                    f_setChecked((cRadioButton) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_IS_CHECKED:
                    methodName = "isChecked";
                    f_isChecked(ret, (cRadioButton) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TEXT:
                    methodName = "setText";
                    f_setText((cRadioButton) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TEXT:
                    methodName = "getText";
                    f_getText(ret, (cRadioButton) stack.get(ct - 1).var);
                    break;
                case FNC_SET_BUTTON_COLOR:
                    methodName = "setButtonColor";
                    f_setButtonColor((cRadioButton) stack.get(ct - 3).var, (cColor) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported RadioButton class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> RadioButton." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setChecked(cRadioButton radioButton, cBool checked)
    {
        ((xRadioButton)radioButton.view).setChecked(checked.isTrue());
    }
    private static void f_isChecked(_Container ret, cRadioButton radioButton)
    {
        ret.var = new cBool();
        ((cBool)ret.var).set(((xRadioButton)radioButton.view).isChecked());
    }
    private static void f_setText(cRadioButton radioButton, cString s)
    {
        radioButton.setText(s.text());
    }
    private static void f_getText(_Container ret, cRadioButton radioButton)
    {
        ret.var = new cString(radioButton.getText());
    }
    private static void f_setButtonColor(cRadioButton radioButton, cColor color, cColor colorChecked)
    {
        ((xRadioButton)radioButton.view).setButtonTintList(_Util.getColorStateList(color.intValue(), colorChecked.intValue()));
    }
}
