package bori.example.imagecapture_fileprovider;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;

class cIntent extends cVar
{
    private Intent intent_;

    cIntent()
    {
        super(cType.TINTENT);
        intent_ = new Intent();
    }
    cIntent(Intent intent)
    {
        super(cType.TINTENT);
        intent_ = intent;
    }
    Intent getIntent() { return intent_; }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cIntent)
        {
            cIntent intent = (cIntent)var;
            intent_ = intent.intent_;
        }
    }

    private void putExtra(String name, cVar var) throws Exception
    {
        if (var instanceof cString)
            intent_.putExtra(name, ((cString)var).text);
        else if (var instanceof cBool)
            intent_.putExtra(name, var.isTrue());
        else if (var instanceof cInt)
            intent_.putExtra(name, ((cInt)var).value);
        else if (var instanceof cDouble)
            intent_.putExtra(name, ((cDouble)var).value);
        else if (var instanceof cStrs)
            intent_.putExtra(name, ((cStrs)var).getStringArray());
        else if (var instanceof cInts)
            intent_.putExtra(name, ((cInts)var).getIntArray());
        else if (var instanceof cInts)
            intent_.putExtra(name, ((cInts)var).getIntArray());
        else if (var instanceof cUri)
            intent_.putExtra(name, ((cUri)var).uri_);
        else
            throw new Exception("Unsupported type: " + var.type);
    }

    //-------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_NEW_URI = 1, FNC_IS_NULL = 2,
            FNC_GET_ACTION = 3, FNC_GET_TYPE = 4, FNC_SET_TYPE = 5,
            FNC_SET_DATA = 6, FNC_PUT_EXTRA = 7,
            FNC_RESOLVE_ACTIVITY = 8,
            FNC_GET_EXTRAS = 9, FNC_GET_STR_EXTRA = 10, FNC_GET_URI_EXTRA = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_NEW_URI:
                    methodName = "new";
                    f_newUri(ret, (cString)stack.get(ct - 2).var, (cUri)stack.get(ct - 1).var);
                    break;
                case FNC_IS_NULL:
                    methodName = "isNull";
                    f_isNull(ret, (cIntent)stack.get(ct - 1).var);
                    break;
                case FNC_GET_ACTION:
                    methodName = "getAction";
                    f_getAction(ret, (cIntent)stack.get(ct - 1).var);
                    break;
                case FNC_GET_TYPE:
                    methodName = "getType";
                    f_getType(ret, (cIntent)stack.get(ct - 1).var);
                    break;
                case FNC_SET_TYPE:
                    methodName = "setType";
                    f_setType((cIntent)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_SET_DATA:
                    methodName = "setData";
                    f_setData((cIntent)stack.get(ct - 2).var, (cUri)stack.get(ct - 1).var);
                    break;
                case FNC_PUT_EXTRA:
                    methodName = "putExtra";
                    f_putExtra((cIntent)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, stack.get(ct - 1).var);
                    break;
                case FNC_RESOLVE_ACTIVITY:
                    methodName = "resolveActivity";
                    f_resolveActivity(boriview, ret, (cIntent)stack.get(ct - 1).var);
                    break;
                case FNC_GET_EXTRAS:
                    methodName = "getExtras";
                    f_getExtras(ret, (cIntent)stack.get(ct - 1).var);
                    break;
                case FNC_GET_STR_EXTRA:
                    methodName = "getStringExtra";
                    f_getStrExtra(ret, (cIntent)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_GET_URI_EXTRA:
                    methodName = "getUriExtra";
                    f_getUriExtra(ret, (cIntent)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Intent." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cString action)
    {
        ret.var = new cIntent(new Intent(action.text));
    }
    private static void f_newUri(_Container ret, cString action, cUri uri)
    {
        ret.var = new cIntent(new Intent(action.text, uri.uri_));
    }
    private static void f_isNull(_Container ret, cIntent intent)
    {
        ret.var = new cBool(intent.intent_ == null);
    }
    private static void f_getAction(_Container ret, cIntent intent)
    {
        ret.var = new cString(intent.intent_.getAction());
    }
    private static void f_getType(_Container ret, cIntent intent)
    {
        ret.var = new cString(intent.intent_.getType());
    }
    private static void f_setType(cIntent intent, cString type)
    {
        intent.intent_.setType(type.text);
    }
    private static void f_setData(cIntent intent, cUri uri)
    {
        intent.intent_.setData(uri.uri_);
    }
    private static void f_putExtra(cIntent intent, cString name, cVar value) throws Exception
    {
        intent.putExtra(name.text, value);
    }
    private static void f_resolveActivity(_BoriView boriview, _Container ret, cIntent intent)
    {
        ComponentName name = intent.intent_.resolveActivity(boriview.bori.getPackageManager());
        if (name == null)
            ret.var = new cString();
        else
            ret.var = new cString(name.flattenToString());
    }
    private static void f_getExtras(_Container ret, cIntent intent)
    {
        ret.var = new cBundle(intent.intent_.getExtras());
    }
    private static void f_getStrExtra(_Container ret, cIntent intent, cString dataName)
    {
        ret.var = new cString(intent.intent_.getStringExtra(dataName.text));
    }
    private static void f_getUriExtra(_Container ret, cIntent intent, cString dataName) throws Exception
    {
        Uri uri;
        try
        {
            uri = intent.intent_.getParcelableExtra(dataName.text);
        }
        catch(Exception e)
        {
            throw new Exception("> Intent.getUriExtra()\n" + e.getMessage());
        }
        ret.var = new cUri(uri);
    }
}
