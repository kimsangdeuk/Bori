package bori.sangdeuk.db_memo;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;

class _Alert
{
    static void show(Context context, String title, String message)
    {
        // build dialog box to display when user clicks the flag
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int id)
                    {
                        dialog.dismiss();
                    }
                }
        );
        AlertDialog alert = builder.create();
        alert.show();
    }
    static void showException(Context context, String message)
    {
        show(context, "Exception", message);
    }
}
