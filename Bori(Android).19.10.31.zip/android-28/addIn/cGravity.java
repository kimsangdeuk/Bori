package bori.sangdeuk.actionbar;

import android.view.Gravity;

class cGravity extends cVar
{
    cGravity()
    {
        super(cType.TGRAVITY);
    }
    //-----------------------------------------------------------
    private static final int FLD_LEFT = 0, FLD_RIGHT = 1, FLD_TOP = 2, FLD_BOTTOM = 3, FLD_START = 4, FLD_END = 5;
    static void getVar(int n, _Container ret, _Container con)
    {
        cRectD r = (cRectD)con.var;
        switch(n)
        {
            case FLD_LEFT: ret.var = new cInt(Gravity.LEFT); break;
            case FLD_TOP: ret.var = new cInt(Gravity.TOP); break;
            case FLD_RIGHT: ret.var = new cInt(Gravity.RIGHT); break;
            case FLD_BOTTOM: ret.var = new cInt(Gravity.BOTTOM); break;
            case FLD_START: ret.var = new cInt(Gravity.START); break;
            case FLD_END: ret.var = new cInt(Gravity.END); break;
        }
    }

}
