package bori.sangdeuk.tablayout_fragment;

import android.graphics.Color;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;

public class _Xml
{
    static Node getChildElement (Node parent, String name)
    {
        if (parent == null)
            return null;

        NodeList nl = parent.getChildNodes();
        for (int i = 0, ct = nl.getLength(); i < ct; i++)
        {
            Node child = nl.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE)
            {
                if (child.getNodeName().equals(name))
                    return child;
            }
        }

        return null;
    }

    static ArrayList<Node> getChildList (Node parent, String name)
    {
        ArrayList<Node> list = new ArrayList<>();
        if (parent == null)
            return list;

        NodeList nl = parent.getChildNodes();
        for (int i = 0, ct = nl.getLength(); i < ct; i++)
        {
            Node child = nl.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE)
            {
                if (child.getNodeName().equals(name))
                    list.add(child);
            }
        }
        return list;
    }

    static String getAttributeValue (Node node, String name)
    {
        if (node == null)
            return "";
        NamedNodeMap nnm = node.getAttributes();
        if (nnm == null)
            return "";
        Node nodeA = nnm.getNamedItem(name);
        if (nodeA == null)
            return "";
        return nodeA.getNodeValue();
    }

    static String getText (Node node)
    {
        String content = "";

        if (node == null)
            return content;
        NodeList nl = node.getChildNodes();
        for (int i = 0, ct = nl.getLength(); i < ct; i++)
        {
            Node child = nl.item(i);
            if (child.getNodeType() == Node.TEXT_NODE)
            {
                content = child.getNodeValue();
                break;
            }
        }

        return content;
    }

    private static final String[] sgravity = { "center", "center_horizontal", "center_vertical",
            "left", "right", "top", "bottom", "start", "end" };
    private static final int[] ngravity = { Gravity.CENTER, Gravity.CENTER_HORIZONTAL, Gravity.CENTER_VERTICAL,
            Gravity.LEFT, Gravity.RIGHT, Gravity.TOP, Gravity.BOTTOM, Gravity.START, Gravity.END };

    private static void setGravity (TextView view, Node node)
    {
        String sGravity = _Xml.getAttributeValue(node, "gravity");
        if (sGravity.equals(""))
            return;

        String[] arr = sGravity.split("\\|", 0);

        int gravity = Gravity.NO_GRAVITY;
        for (int i = 0, ct = arr.length; i < ct; i++)
        {
            String s = arr[i];
            for (int k = 0, ctk = sgravity.length; k < ctk; k++)
            {
                if (s.equals(sgravity[k]))
                    gravity |= ngravity[k];
            }
        }
        if (gravity != Gravity.NO_GRAVITY)
            view.setGravity(gravity);
    }

    static void setTextStyle(TextView view, Node node)
    {
        String singleLine = _Xml.getAttributeValue(node, "singleLine");
        view.setSingleLine(singleLine.equals("true"));

        String text = _Xml.getAttributeValue(node, "text");
        view.setText(text);

        String sunit = _Xml.getAttributeValue(node, "textSizeUnit");
        int unit;
        if (sunit.equals("dp"))
            unit = TypedValue.COMPLEX_UNIT_DIP;
        else
            unit = TypedValue.COMPLEX_UNIT_SP;

        String size = _Xml.getAttributeValue(node, "textSize");
        if (! size.equals(""))
            view.setTextSize(unit, Float.parseFloat(size));

        String color = _Xml.getAttributeValue(node, "textColor");
        if (! color.equals(""))
            view.setTextColor(Color.parseColor(color));

        setGravity(view, node);
    }

    static void setViewStyle(View view, Node node)
    {
        String text;
        text = _Xml.getAttributeValue(node, "backColor");
        if (! text.isEmpty())
            view.setBackgroundColor(Color.parseColor(text));

        text = _Xml.getAttributeValue(node, "hidden");
        if (text.equals("true"))
            view.setVisibility(View.INVISIBLE);

        text = _Xml.getAttributeValue(node, "backImage");
        if (! text.isEmpty())
        {
            try
            {
                view.setBackgroundResource(_Util.getResID(view.getContext(), text));
            }
            catch(Exception e)
            {
            }
        }
    }
}
