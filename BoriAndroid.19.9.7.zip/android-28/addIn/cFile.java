package bori.android.filereadtext;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

class cFile extends cVar
{
    cFile()
    {
        super(cType.TFILE);
    }

    private static String readText(InputStream is) throws Exception
    {
        StringBuilder text = new StringBuilder();
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(is)))
        {
            String line;
            boolean isFirst = true;
            while ((line = reader.readLine()) != null)
            {
                if(isFirst)
                    isFirst = false;
                else
                    text.append('\n');
                text.append(line);
            }
        }
        return new String(text);
    }

    //---------------------------------------------------------------------
    private static final int FNC_READ_TEXT_ASSET = 0, FNC_READ_TEXT_RESOURCE = 1,
            FNC_READ_ALL_TEXT = 2, FNC_WRITE_ALL_TEXT = 3, FNC_EXISTS = 4,
    FNC_DELETE = 5, FNC_GET_FILE_LIST = 6;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_READ_TEXT_ASSET:
                    methodName = "readTextAsset";
                    f_readTextAsset(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_READ_TEXT_RESOURCE:
                    methodName = "readTextResource";
                    f_readTextResource(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_READ_ALL_TEXT:
                    methodName = "readAllText";
                    f_readAllText(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_WRITE_ALL_TEXT:
                    methodName = "writeAllText";
                    f_writeAllText(boriview, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_EXISTS:
                    methodName = "exists";
                    f_exists(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_DELETE:
                    methodName = "delete";
                    f_delete(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_FILE_LIST:
                    methodName = "getFileList";
                    f_getFileList(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> File." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_readTextAsset(_BoriView boriview, _Container ret, cString fileName) throws Exception
    {
        InputStream is = boriview.bori.getAssets().open(fileName.text);
        ret.var = new cString(readText(is));
        is.close();
    }
    private static void f_readTextResource(_BoriView boriview, _Container ret, cString resName) throws Exception
    {
        InputStream is = boriview.bori.getResources().openRawResource(_Util.getResID(boriview.bori, resName.text));
        ret.var = new cString(readText(is));
        is.close();
    }
    private static void f_readAllText(_BoriView boriview, _Container ret, cString fileName) throws Exception
    {
        FileInputStream fis = boriview.bori.openFileInput(fileName.text);
        ret.var = new cString(readText(fis));
        fis.close();
    }
    private static void f_writeAllText(_BoriView boriview, cString fileName, cString text) throws Exception
    {
        FileOutputStream fos = boriview.bori.openFileOutput(fileName.text, Context.MODE_PRIVATE);
        fos.write(text.text.getBytes());
        fos.close();
    }
    private static void f_exists(_BoriView boriview, _Container ret, cString fileName)
    {
        File file = boriview.bori.getFileStreamPath(fileName.text);
        ret.var = new cBool(file.exists());
    }
    private static void f_delete(_BoriView boriview, _Container ret, cString fileName)
    {
        File file = boriview.bori.getFileStreamPath(fileName.text);
        ret.var = new cBool(file.delete());
    }
    private static void f_getFileList(_BoriView boriview, _Container ret)
    {
        String[] listOfFiles = boriview.bori.getFilesDir().list();
        ret.var = new cStrs(listOfFiles);
    }
}
