package com.sangdeuk.fragment1;

public class cInt extends cVar
{
    long value; // 64bits

    static final long SMALLEST = (-9223372036854775807L);
    static final long NULL = (-9223372036854775807L - 1);

    cInt()
    {
        super(cType.TBIGINT);
        value = NULL;
    }
    cInt(cInt n)
    {
        super(cType.TBIGINT);
        value = n.value;
    }
    cInt(long value_)
    {
        super(cType.TBIGINT);
        value = value_;
    }

    void setNull()
    {
        value = NULL;
    }
    void set(long value0)
    {
        value = value0;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cInt)
            value = ((cInt)var).value;
    }
    @Override
    public void clear()
    {
        value = NULL;
    }
    @Override
    public boolean isTrue() { return (value!=0); }
    @Override
    public boolean isNull() { return value == NULL; }
    @Override
    public String toString()
    {
        if (value == NULL)
            return "NA";
        return Long.toString(value);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_PARSE = 0, FNC_TOSTRING = 1, FNC_ABS = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_PARSE: f_parse(ret, (cString)stack.get(ct-1).var); break;
            case FNC_TOSTRING: f_toString(ret, (cInt)stack.get(ct-1).var); break;
            case FNC_ABS: f_abs(ret, (cInt)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Int class method:" + nfunc);
        }
    }

    private static void f_parse(_Container ret, cString s)
    {
        long val = (s.text.equals("")) ? NULL : Long.parseLong(s.text);
        ret.var = new cInt(val);
    }
    private static void f_toString(_Container ret, cInt val)
    {
        ret.var = new cString(Long.toString(val.value));
    }
    private static void f_abs(_Container ret, cInt val)
    {
        ret.var = new cInt(val.value < 0 ? -(val.value) : val.value);
    }
}
