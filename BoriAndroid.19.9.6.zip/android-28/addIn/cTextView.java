package bori.sangdeuk.actionbar;

import android.view.View;

class cTextView extends cControl
{
    cTextView()
    {
        super(cType.TC_TEXTVIEW);
    }
    cTextView(View view0)
    {
        super(cType.TC_TEXTVIEW);
        view = view0;
    }

    String getText()
    {
        return ((xTextView)view).getText().toString();
    }
    void setText(String text)
    {
        ((xTextView)view).setText(text);
    }

    //---------------------------------------------------------------------
    private static final int FNC_SET_TEXT = 0, FNC_GET_TEXT = 1, FNC_SET_BACK_COLOR = 2, FNC_SET_TEXT_COLOR = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_TEXT:
                    methodName = "setText";
                    f_setText((cTextView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TEXT:
                    methodName = "getText";
                    f_getText(ret, (cTextView) stack.get(ct - 1).var);
                    break;
                case FNC_SET_TEXT_COLOR:
                    methodName = "setTextColor";
                    f_setTextColor((cTextView) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_SET_BACK_COLOR:
                    methodName = "setBackColor";
                    f_setBackColor((cTextView) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> TextView." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setText(cTextView textView, cString s)
    {
       textView.setText(s.text());
    }

    private static void f_getText(_Container ret, cTextView textView)
    {
        ret.var = new cString(textView.getText());
    }
    private static void f_setTextColor(cTextView textView, cColor color)
    {
        ((xTextView)textView.view).setTextColor(color.intValue());
    }
    private static void f_setBackColor(cTextView textView, cColor color)
    {
        ((xTextView)textView.view).setBackgroundColor(color.intValue());
    }
}
