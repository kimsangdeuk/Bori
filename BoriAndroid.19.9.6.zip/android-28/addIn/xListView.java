package bori.sangdeuk.test;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xListView extends ScrollView
{
    private _BoriView boriview_;
    private String methodItemClick_ = null;
    private LinearLayout linear_ = null;
    private ArrayList<xLinearLayout> listItems_;

    xListView(Context context) { super(context); }

    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        listItems_ = new ArrayList<>();

        // init linear
        linear_ = new LinearLayout(boriview.bori);
        linear_.setLayoutParams((new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT)));
        linear_.setOrientation(LinearLayout.VERTICAL);
        addView(linear_);

        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String value = _Xml.getAttributeValue(node, "method");
            if (name.equals("onItemClick"))
                methodItemClick_ = value;
        }
    }

    xLinearLayout addItem(String viewName) throws Exception
    {
        if (! viewName.endsWith(".view"))
            viewName += ".view";
        _BoriView boriview = new _BoriView(boriview_.bori, this, false);
        boriview.init(viewName);
        xLinearLayout layout = boriview.getLayout();
        listItems_.add(layout);
        setClickListener(boriview);
        linear_.addView(layout);

        View divider = new View(boriview_.bori);
        divider.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2));
        divider.setBackgroundColor(0xFFd0d0d0);
        linear_.addView(divider);

        return layout;
    }

    private void setClickListener(_BoriView boriview)
    {
        if (methodItemClick_ != null)
        {
            ArrayList<_Item> items = boriview.getItemList();
            for (_Item item : items)
            {
                View view = item.view();
                view.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        _Tag info = _Tag.get(v);
                        xLinearLayout parent = info.getParent();

                        _ConList params = new _ConList();

                        // param1 : index
                        cInt index = new cInt(listItems_.indexOf(parent) + 1);
                        params.add(new _Container(index));

                        cControl control= new cControl(info.getParent());
                        params.add(new _Container(control));

                        cString name = new cString(info.getName());
                        params.add(new _Container(name));

                        boriview_.call(methodItemClick_, params);
                    }
                });
            }
        }
    }

    private void checkIndex(int index) throws Exception
    {
        if (index < 0 || index >= listItems_.size())
        throw new Exception("Index out of bounds: " + (index + _Env.iBase));
    }
    void removeItem(int index) throws Exception
    {
        checkIndex(index);
        listItems_.remove(index);

        linear_.removeViewAt(index * 2 + 1);
        linear_.removeViewAt(index * 2);
    }
    void clear()
    {
        linear_.removeAllViews();
        listItems_.clear();
    }
    int count()
    {
        return listItems_.size();
    }
    xLinearLayout getItem(int index) throws Exception
    {
        checkIndex(index);
        return listItems_.get(index);
    }
    void scrollTo(int index, boolean smooth) throws Exception
    {
        checkIndex(index);
        xLinearLayout item = listItems_.get(index);
        if (smooth)
            smoothScrollTo(0, (int)item.getY());
        else
            scrollTo(0, (int)item.getY());
    }
}

