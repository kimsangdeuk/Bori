package bori.sangdeuk.actionbar;

import android.support.v7.widget.PopupMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

class cPopupMenu extends cVar
{
    private PopupMenu pm_ = null;

    cPopupMenu()
    {
        super(cType.TPOPUPMENU);
    }
    private cPopupMenu(PopupMenu pm)
    {
        super(cType.TPOPUPMENU);
        pm_ = pm;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cPopupMenu)
        {
            cPopupMenu src = (cPopupMenu)var;
            pm_ = src.pm_;
        }
    }
    //-----------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_GET_MENU = 1, FNC_SET_ON_MENUITEM_CLICK = 2,
            FNC_SET_GRAVITY = 3, FNC_SHOW = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(boriview, ret, (cControl) stack.get(ct - 1).var);
                    break;
                case FNC_GET_MENU:
                    methodName = "getMenu";
                    f_getMenu(ret, (cPopupMenu) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ON_MENUITEM_CLICK:
                    methodName = "setOnMenuItemClick";
                    f_setOnMenuItemClick(boriview, (cPopupMenu) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_GRAVITY:
                    methodName = "setGravity";
                    f_setGravity((cPopupMenu) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SHOW:
                    methodName = "show";
                    f_show((cPopupMenu) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> PopupMenu." + methodName + "\n" + e.getMessage());
        }
    }

    private static void mustSetAnchor(cPopupMenu popup) throws Exception
    {
        if (popup.pm_ == null)
            throw new Exception("Anchor control is not specified.");
    }
    private static void f_new(_BoriView boriview, _Container ret, cControl control)
    {
        PopupMenu pm = new PopupMenu(boriview.bori, control.view, Gravity.RIGHT);
        try
        {
            Field[] fields = pm.getClass().getDeclaredFields();
            for (Field field : fields)
            {
                if ("mPopup".equals(field.getName()))
                {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(pm);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod(
                            "setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        ret.var = new cPopupMenu(pm);
    }

    private static void f_getMenu(_Container ret, cPopupMenu popup) throws Exception
    {
        mustSetAnchor(popup);
        ret.var = new cMenu(popup.pm_.getMenu());
    }
    private static void f_setOnMenuItemClick(final _BoriView boriview, cPopupMenu popup, final cString method) throws Exception
    {
        mustSetAnchor(popup);
        popup.pm_.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener()
        {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem)
            {
                _ConList params = new _ConList();
                params.add(new _Container(new cMenuItem(menuItem)));
                boriview.call(method.text + "(MenuItem)", params);
                return false;
            }
        });
    }
    private static void f_setGravity(cPopupMenu popup, cInt gravity)
    {
        popup.pm_.setGravity((int)gravity.value);
    }
    private static void f_show(cPopupMenu popup) throws Exception
    {
        mustSetAnchor(popup);
        popup.pm_.show();
    }
}
