package bori.sangdeuk.string;

class cString extends cVar
{
    String text = "";

    cString() { super(cType.TSTRING); }
    cString(cString s) { super(cType.TSTRING); text = s.text; }
    cString(String text0) { super(cType.TSTRING); set(text0); }

    void set(cString s)
    {
        text = s.text;
    }
    void set(String text0)
    {
        if (text0 == null)
            text = "";
        else
            text = text0;
    }
    String text()
    {
        return text;
    }
    int compareTo(cString s)
    {
        return text.compareTo(s.text);
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cString)
            set((cString)var);
    }
    @Override
    public void clear()
    {
        text = "";
    }
    @Override
    public boolean isTrue() { return (text != null && !text.equals("")); }
    @Override
    public String toString() { return text; }

    //-----------------------------------------------------------
    private static final int FLD_NEWLINE = 0;
    static void getVar(int n, _Container ret, _Container con)
    {
        if (n == FLD_NEWLINE) ret.var = new cString(System.getProperty("line.separator"));
    }

    //-----------------------------------------------------------
    private static final int FNC_PLUS = 0, FNC_PLUSASSIGN = 1, FNC_LSHIFT = 2,
            FNC_STARTS_WITH = 3, FNC_ENDS_WITH = 4,
            FNC_COUNT = 5, FNC_SUBSTR = 6, FNC_SPLIT = 7,
            FNC_TOUPPER = 8, FNC_TOLOWER = 9, FNC_GET_CHAR = 10,
            FNC_REPLACE = 11, FNC_REPLACE_ALL = 12;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_PLUS:
                methodName = "+";
                f_plus(ret, (cString)stack.get(ct-2).var, stack.get(ct-1).var); break;
            case FNC_PLUSASSIGN:
                methodName = "+=";
                f_plusAssign((cString)stack.get(ct-2).var, stack.get(ct-1).var); break;
            case FNC_LSHIFT:
                methodName = "<<";
                f_lshift(ret, (cString)stack.get(ct-2).var, stack.get(ct-1).var); break;
            case FNC_STARTS_WITH:
                methodName = "startsWith";
                f_startsWith(ret, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_ENDS_WITH:
                methodName = "endsWith";
                f_endsWith(ret, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_COUNT:
                methodName = "count";
                f_count(ret, (cString)stack.get(ct-1).var); break;
            case FNC_SUBSTR:
                methodName = "substring";
                f_substring(ret, (cString)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_SPLIT:
                methodName = "split";
                f_split(ret, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_TOUPPER:
                methodName = "toUpper";
                f_toUpper(ret, (cString)stack.get(ct-1).var); break;
            case FNC_TOLOWER:
                methodName = "toLower";
                f_toLower(ret, (cString)stack.get(ct-1).var); break;
            case FNC_GET_CHAR:
                methodName = "getChar";
                f_getChar(ret, (cString)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_REPLACE:
                methodName = "replace";
                f_replace(ret, (cString)stack.get(ct-3).var,
                        (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_REPLACE_ALL:
                methodName = "replaceAll";
                f_replaceAll(ret, (cString)stack.get(ct-3).var,
                        (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported class method:" + nfunc);
        }
        }
        catch(Exception e)
        {
            throw new Exception("> Str." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_plus(_Container ret, cString s, cVar var)
    {
        ret.var = new cString();
        ((cString)ret.var).set(s.text() + var.toString());
    }

    private static void f_plusAssign(cString s, cVar var)
    {
        s.text += var.toString();
    }

    private static void f_lshift(_Container ret, cString s, cVar var)
    {
        s.text += var.toString();
        ret.var = s;
    }
    private static void f_startsWith(_Container ret, cString s, cString s2)
    {
        ret.var = new cBool();
        ((cBool)ret.var).set(s.text.startsWith(s2.text));
    }
    private static void f_endsWith(_Container ret, cString s, cString s2)
    {
        ret.var = new cBool();
        ((cBool)ret.var).set(s.text.endsWith(s2.text));
    }
    private static void f_count(_Container ret, cString s)
    {
        ret.var = new cInt(s.text.length());
    }
    private static void f_substring(_Container ret, cString s, cInt start, cInt count) throws Exception
    {
        int startIndex = (int)start.value - _Env.iBase;
        if (startIndex < 0 || startIndex >= s.text.length())
            throw new Exception("The index is out of bounds.\n> Str.substring()\nCount: "
                    + s.text.length() + ", Index: " + (startIndex + _Env.iBase));
        int length = s.text.length();
        int endIndex = startIndex + (int)count.value;
        if (endIndex > length)
            endIndex = length;
        ret.var = new cString(s.text.substring(startIndex, endIndex));
    }
    private static void f_split(_Container ret, cString s, cString sep)
    {
        String[] arr = s.text.split(sep.text, 0);
        ret.var = new cStrs(arr);
    }
    private static void f_toUpper(_Container ret, cString s)
    {
        ret.var = new cString(s.text.toUpperCase());
    }
    private static void f_toLower(_Container ret, cString s)
    {
        ret.var = new cString(s.text.toLowerCase());
    }
    private static void f_getChar(_Container ret, cString s, cInt index) throws Exception
    {
        int idx = (int)index.value - _Env.iBase;
        _Util.checkIndex(s.text.length(), idx);
        ret.var = new cChar((int)(s.text.charAt(idx)));
    }
    private static void f_replace(_Container ret, cString s, cString regex, cString replacement)
    {
        ret.var = new cString(s.text.replaceFirst(regex.text, replacement.text));
    }
    private static void f_replaceAll(_Container ret, cString s, cString regex, cString replacement)
    {
        ret.var = new cString(s.text.replaceAll(regex.text, replacement.text));
    }
}
