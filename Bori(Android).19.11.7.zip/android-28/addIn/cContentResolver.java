package bori.example.actiongetimage;

import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.MediaStore;

import java.io.File;

class cContentResolver extends cVar
{
    private ContentResolver resolver_;

    cContentResolver()
    {
        super(cType.TCONTENTRESOLVER);
    }
    cContentResolver(ContentResolver resolver)
    {
        super(cType.TCONTENTRESOLVER);
        resolver_ = resolver;
    }
    @Override
    public void copyFrom(cVar var)
    {
        resolver_ = null;
        if (var instanceof cContentResolver)
            resolver_ = ((cContentResolver)var).resolver_;
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_IMAGE_FILE = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_IMAGE_FILE:
                    methodName = "getImageFile";
                    f_getImageFile(ret, (cContentResolver)stack.get(ct-2).var, (cUri)stack.get(ct-1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> ContentResolver." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getImageFile(_Container ret, cContentResolver cr, cUri uri) throws Exception
    {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = cr.resolver_.query(uri.uri_, proj, null, null, null);
        if (cursor.moveToFirst())
        {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        ret.var = new cFile(new File(res));
    }
}
