package bori.sangdeuk.viewpager;

class _Env
{
    static final int iBase = 1;
    static int id = 100;
    static int nextID()
    {
        id++;
        return id;
    }
}
