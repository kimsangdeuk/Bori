package bori.example.contacts;

import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

class cContacts extends cVar
{
    cContacts()
    {
        super(cType.TCONTACTS);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_LIST = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_LIST:
                    methodName = "getList";
                    f_getList(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Contacts." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getList (_BoriView boriview, _Container ret) throws Exception
    {
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = new String[]{
                ContactsContract.Contacts._ID,
                //ContactsContract.Contacts.PHOTO_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
        };

        String sortOrder = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC";

        Cursor cursor = boriview.bori.getContentResolver().query(uri, projection, null, null, sortOrder);
        ret.var = cRset.fromCursor(cursor);
    }
}
