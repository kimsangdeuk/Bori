package bori.sangdeuk.file_memo;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.v4.content.res.ResourcesCompat;

import java.io.InputStream;
import java.util.ArrayList;

class _Util
{
    static Context myContext;

    static void checkIndex(ArrayList<?> list, int index) throws Exception
    {
        if (index < 0 || index >= list.size())
            throw new Exception("The index is out of bounds.\n"
                    + "Count: " + list.size() + ", Index: " + (index + _Env.iBase));

    }
    static void checkIndex(int count, int index) throws Exception
    {
        if (index < 0 || index >= count)
            throw new Exception("The index is out of bounds.\nCount: " + count + ", Index: " + (index + _Env.iBase));
    }

    static int getResID(Context context, String resName) throws Exception
    {
        Resources res = context.getResources();
        int id = res.getIdentifier(resName, null, context.getPackageName());
        if (id == 0)
            throw new Exception("Resource name '" + resName + "' not found");
        return id;
    }

    @SuppressWarnings("deprecation")
    static Drawable getDrawable(Context context, String resourceName)
    {
        Resources res = context.getResources();
        final int resourceId = res.getIdentifier(resourceName, null, context.getPackageName());
        return  res.getDrawable(resourceId);
    }

    static Bitmap decodeSampledBitmapFromResource(Context context, String resourceName,
                                                          int minWidth, int minHeight) throws Exception
    {
        Resources res = context.getResources();
        final int resId = res.getIdentifier(resourceName, null, context.getPackageName());

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        int height = options.outHeight;
        int width = options.outWidth;
        if (height > minHeight && width > minWidth)
        {
            int inSampleSize = 4;
            height = (int)(height * 0.75);
            width = (int)(width * 0.75);

            while (height > minHeight && width > minWidth)
            {
                height = height / 2;
                width = width / 2;
                if (height <= minHeight || width <= minWidth)
                    break;
                inSampleSize *= 2;
            }
            options.inSampleSize = inSampleSize;
        }

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        Bitmap bmp = BitmapFactory.decodeResource(res, resId, options);
        if (bmp == null)
            throw new Exception("decodeResource returned null.");
        return bmp;
    }

    static Bitmap decodeSampledBitmapFromAsset(Context context, String fileName,
                                                  int minWidth, int minHeight) throws Exception
    {
        Bitmap	bmp;
        InputStream is = null;
        try
        {
            AssetManager am = context.getAssets();
            is = am.open(fileName);
            // First decode with inJustDecodeBounds=true to check dimensions
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, options);
            is.close();

            int height = options.outHeight;
            int width = options.outWidth;
            if (height > minHeight && width > minWidth)
            {
                int inSampleSize = 2;
                height = (int)(height * 0.5);
                width = (int)(width * 0.5);

                while (height > minHeight && width > minWidth)
                {
                    height = height / 2;
                    width = width / 2;
                    if (height <= minHeight || width <= minWidth)
                        break;
                    inSampleSize *= 2;
                }
                options.inSampleSize = inSampleSize;
            }

            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            is = am.open(fileName);
            bmp = BitmapFactory.decodeStream(is, null, options);
        }
        catch (Exception e)
        {
            throw e;
        }
        finally
        {
            if (is != null)
            {
                try { is.close(); } catch (Exception e) { }
            }
        }
        if (bmp == null)
            throw new Exception("decodeStream returned null.");
        return bmp;
    }

    static ColorStateList getColorStateList(int color, int colorChecked)
    {
        ColorStateList colorStateList = new ColorStateList(
                new int[][]{
                        new int[]{-android.R.attr.state_checked}, // unchecked
                        new int[]{android.R.attr.state_checked}  // checked
                },
                new int[]{
                        color, // uncheckedColor,
                        colorChecked // checkedColor
                }
        );
        return colorStateList;
    }
}
