package bori.sangdeuk.file_storage;

import android.content.Context;
import android.os.Environment;
import android.os.storage.StorageManager;

import java.io.File;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class cEnvironment extends cVar
{
    cEnvironment()
    {
        super(cType.TENVIRONMENT);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_EXTERNAL_STORAGE_PUBLIC_DIRECTORY = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_EXTERNAL_STORAGE_PUBLIC_DIRECTORY:
                    methodName = "getExternalStoragePublicDirectory";
                    f_getExternalStoragePublicDirectory(ret, (cString) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Context." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getExternalStoragePublicDirectory (_Container ret, cString folder) throws Exception
    {
//        ret.var = new cFile(Environment.getExternalStoragePublicDirectory(folder.text));
        ret.var = new cFile(new File(getExternalStoragePath(_Util.myContext, false)));
    }
    private static String getExternalStoragePath(Context mContext, boolean is_removable) throws Exception
    {

        StorageManager mStorageManager = (StorageManager) mContext.getSystemService(Context.STORAGE_SERVICE);
        Class<?> storageVolumeClazz = null;
        storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
        Method getVolumeList = mStorageManager.getClass().getMethod("getVolumeList");
        Method getPath = storageVolumeClazz.getMethod("getPath");
        Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
        Object result = getVolumeList.invoke(mStorageManager);
        final int length = Array.getLength(result);
        for (int i = 0; i < length; i++)
        {
            Object storageVolumeElement = Array.get(result, i);
            String path = (String) getPath.invoke(storageVolumeElement);
            boolean removable = (Boolean) isRemovable.invoke(storageVolumeElement);
            if (is_removable == removable)
            {
                return path;
            }
        }
        return null;
    }
}
