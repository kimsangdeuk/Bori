package bori.example.actiongetimage;

import android.net.Uri;

class cUri extends cVar
{
    Uri uri_;

    cUri()
    {
        super(cType.TURI);
    }
    cUri(Uri uri)
    {
        super(cType.TURI);
        uri_ = uri;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cUri)
            uri_ = ((cUri)var).uri_;
    }
    public String toString()
    {
        return uri_.toString();
    }

    //-----------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_IS_NULL = 1, FNC_FROM_FILE = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_IS_NULL:
                    methodName = "isNull";
                    f_isNull(ret, (cUri) stack.get(ct - 1).var);
                    break;
                case FNC_FROM_FILE:
                    methodName = "fromFile";
                    f_fromFile(ret, (cFile) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Uri." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cString suri)
    {
        ret.var = new cUri(Uri.parse(suri.text));
    }
    private static void f_isNull(_Container ret, cUri uri)
    {
        ret.var = new cBool(uri.uri_ == null || uri.toString().isEmpty());
    }
    private static void f_fromFile(_Container ret, cFile file)
    {
        ret.var = new cUri(Uri.fromFile(file.file_));
    }
}
