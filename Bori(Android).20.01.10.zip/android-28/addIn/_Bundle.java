package bori.example.whereru;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

class _Bundle
{
    private static final String boriKey = "_bori_vars_";
    private static final String boriIdentifier = "*14%5tg";

    static Bundle getBundle(cVars vars) throws Exception
    {
        return getBundle(vars.map);
    }
    static Bundle getBundle(HashMap<String, _Container> map) throws Exception
    {
        Bundle bundle = new Bundle();
        bundle.putString(boriKey, boriIdentifier);
        for (Map.Entry<String, _Container> entry : map.entrySet())
        {
            String key = entry.getKey();
            _Container con = entry.getValue();
            bundle.putParcelable(key, getParcelableFromVar(con.var));
        }
        return bundle;
    }

    static Parcelable getParcelableFromVar(cVar var) throws Exception
    {
        switch (var.type)
        {
            case cType.TCH: return (cChar)var;
            case cType.TSTRING: return (cString)var;
            case cType.TBIGINT: return (cInt)var;
            case cType.TDOUBLE: return (cDouble)var;
            case cType.TBOOL: return (cBool)var;
            case cType.TSTRS: return (cStrs)var;
            case cType.TINTS: return (cInts)var;
            case cType.TDOUBS: return (cDoubles)var;
            case cType.TCOLOR: return (cColor)var;
            case cType.TURI: return ((cUri)var).uri_;
            case cType.TINTENT: return ((cIntent)var).getIntent();
            case cType.TBITMAP: return ((cBitmap)var).bmp_;
            default:
                throw new Exception("Unsupported type for getParcelableFromVar(): " + var.type);
        }
    }

    static boolean isBoriBundle(Intent intent)
    {
        String id = intent.getStringExtra(boriKey);
        return (id != null && id.equals(boriIdentifier));
    }

    static cVars readBundle(Bundle bundle) throws Exception
    {
        cVars vars = new cVars();
        if (bundle == null)
            return vars;
        Set<String> set = bundle.keySet();
        if (set == null)
            return vars;

        for (String key : set)
        {
            if (key.equals(boriKey))
                continue;
            Parcelable p = bundle.getParcelable(key);
            vars.set(key, new _Container(getVarFromParcelable(p)));
        }
        return vars;
    }

    static cVar getVarFromParcelable(Parcelable obj) throws Exception
    {
        if (obj instanceof cBool) return (cBool)obj;
        else if (obj instanceof cChar) return (cChar)obj;
        else if (obj instanceof cString) return (cString)obj;
        else if (obj instanceof cInt) return (cInt)obj;
        else if (obj instanceof cDouble) return (cDouble)obj;
        else if (obj instanceof cStrs) return (cStrs)obj;
        else if (obj instanceof cInts) return (cInts)obj;
        else if (obj instanceof cDoubles) return (cDoubles)obj;
        else if (obj instanceof cColor) return (cColor)obj;
        else if (obj instanceof Uri) return (new cUri((Uri)obj));
        else if (obj instanceof Intent) return (new cIntent((Intent)obj));
        else if (obj instanceof Bitmap) return (new cBitmap((Bitmap)obj));
        else throw new Exception("Unsupported type for getVarFromParcelable()");
    }
}

