package bori.android.check_radio;

class cButton extends cTextView
{
    cButton()
    {
        super(cType.TC_BUTTON);
    }
    cButton(int type0)
    {
        super(type0);
    }
    cButton(xButton view_)
    {
        super(cType.TC_BUTTON);
        view = view_;
    }

    String getText()
    {
        return ((xButton)view).getText().toString();
    }
    void setText(String text) { ((xButton)view).setText(text); }

    //---------------------------------------------------------------------
    private static final int FNC_SET_TEXT = 0, FNC_GET_TEXT = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_TEXT: f_setText((cButton)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_GET_TEXT: f_getText(ret, (cButton)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Button class method:" + nfunc);
        }
    }

    private static void f_setText(cButton button, cString s)
    {
        button.setText(s.text());
    }

    private static void f_getText(_Container ret, cButton button)
    {
        ret.var = new cString(button.getText());
    }
}
