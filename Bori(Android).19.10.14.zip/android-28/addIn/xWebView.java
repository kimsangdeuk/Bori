package com.sangdeuk.fragment;

import android.content.Context;
import android.util.AttributeSet;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

class xWebView extends WebView
{
    private _BoriView boriview_;

    xWebView (Context context)
    {
        super(context);
    }
    void init(_BoriView boriview)
    {
        boriview_ = boriview;
        WebSettings ws = getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setUseWideViewPort(true);	// horizontal scroll
        ws.setBuiltInZoomControls(true);	// zoom
        setWebViewClient(new WebViewClient());
    }
}

