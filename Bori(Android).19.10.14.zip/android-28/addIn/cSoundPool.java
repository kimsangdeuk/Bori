package com.sangdeuk.fragment1;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;

import static android.content.Context.AUDIO_SERVICE;

class cSoundPool extends cVar
{
    private SoundPool pool_;

    cSoundPool()
    {
        super(cType.TSOUNDPOOL);
    }
    private cSoundPool(SoundPool pool)
    {
        super(cType.TSOUNDPOOL);
        pool_ = pool;

    }
    @Override
    public void copyFrom(cVar var)
    {
        if (var instanceof cSoundPool)
            pool_ = ((cSoundPool)var).pool_;
    }

    private static final int FNC_NEW = 0, FNC_LOAD = 1, FNC_PLAY = 2, FNC_PLAY_REPEAT = 3, FNC_RELEASE = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_NEW: f_new(ret, (cInt)stack.get(ct-1).var); break;
            case FNC_LOAD: f_load(boriview, ret, (cSoundPool)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_PLAY: f_play(boriview, (cSoundPool)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_PLAY_REPEAT: f_playRepeat(boriview, (cSoundPool)stack.get(ct-3).var, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            case FNC_RELEASE: f_release((cSoundPool)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported SoundPool class method:" + nfunc);
        }
    }

    private static void checkNullPool(cSoundPool sp, String methodName) throws Exception
    {
        if (sp.pool_ == null)
            throw new Exception("> SoundPool." + methodName + "\nNull sound pool. Use new(int) method.");
    }

    private static void f_new(_Container ret, cInt maxStreams)
    {
        SoundPool.Builder builder = new SoundPool.Builder();
        builder.setMaxStreams((int)maxStreams.value);
        builder.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build());
        ret.var = new cSoundPool(builder.build());
    }
    private static void f_load(_BoriView boriview, _Container ret, cSoundPool sp, cString resName) throws Exception
    {
        checkNullPool(sp, "load");
        ret.var = new cInt(sp.pool_.load(boriview.bori, _Util.getResID(boriview.bori, resName.text), 1));
    }
    private static float getVolume(_BoriView boriview)
    {
        AudioManager audioManager = (AudioManager) boriview.bori.getSystemService(AUDIO_SERVICE);
        float actualVolume = (float) audioManager
                .getStreamVolume(AudioManager.STREAM_MUSIC);
        float maxVolume = (float) audioManager
                .getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        return actualVolume / maxVolume;
    }
    private static void f_play(_BoriView boriview, cSoundPool sp, cInt soundID) throws Exception
    {
        checkNullPool(sp, "play");
        float volume = getVolume(boriview);
        sp.pool_.play((int)soundID.value, volume, volume, 1, 0, 1f);
    }
    private static void f_playRepeat(_BoriView boriview, cSoundPool sp, cInt soundID, cInt loop) throws Exception
    {
        checkNullPool(sp, "play");
        float volume = getVolume(boriview);
        sp.pool_.play((int)soundID.value, volume, volume, 1, (int)loop.value, 1f);
    }
    private static void f_release(cSoundPool sp) throws Exception
    {
        checkNullPool(sp, "release");
        sp.pool_.release();
        sp.pool_ = null;
    }
}
