package com.sangdeuk.fragment1;

import java.util.Random;

public class cRandom extends cVar
{
    cRandom()
    {
        super(cType.TRANDOM);
    }

    private static final int FNC_NEXT_INT = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_NEXT_INT: f_nextInt(ret, (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Random class method:" + nfunc);
        }
    }

    private static void f_nextInt(_Container ret, cInt cmin, cInt cmax)
    {
        int min = (int)cmin.value;
        int max = (int)cmax.value;
        if (max < min)
        {
            int t = max;
            max = min;
            min = t;
        }
        int random = new Random().nextInt((max - min) + 1) + min;
        ret.var = new cInt(random);
    }
}

