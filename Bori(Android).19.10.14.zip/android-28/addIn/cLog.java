package bori.sangdeuk.db_memo;

import android.util.Log;

class cLog extends cVar
{
    cLog()
    {
        super(cType.TLOG);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_D = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_D:
                    methodName = "d";
                    f_d((cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Log." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_d (cString tag, cString msg)
    {
        Log.d(tag.text, msg.text);
    }
}
