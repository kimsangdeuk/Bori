package bori.sangdeuk.file_storage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

class cFile extends cVar
{
    protected File file_;

    cFile()
    {
        super(cType.TFILE);
    }
    cFile(int type0)
    {
        super(type0);
    }
    cFile(File f)
    {
        super(cType.TFILE);
        file_ = f;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cFile)
        {
            cFile file = (cFile)var;
            file_ = file.file_;
        }
    }

    private static String readText(InputStream is) throws Exception
    {
        StringBuilder text = new StringBuilder();
        try(BufferedReader reader = new BufferedReader(new InputStreamReader(is)))
        {
            String line;
            boolean isFirst = true;
            while ((line = reader.readLine()) != null)
            {
                if(isFirst)
                    isFirst = false;
                else
                    text.append('\n');
                text.append(line);
            }
        }
        return new String(text);
    }

    //---------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_NEW2 = 1,
            FNC_READ_TEXT_ASSET = 2, FNC_READ_TEXT_RESOURCE = 3,
            FNC_READ_ALL_TEXT = 4, FNC_WRITE_ALL_TEXT = 5,
            FNC_EXISTS = 6, FNC_DELETE = 7, FNC_LIST = 8,
            FNC_TOSTRING = 9,
            FNC_IS_DIRECTORY = 10, FNC_IS_FILE = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_NEW2:
                    methodName = "new";
                    f_new2(ret, (cFile) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_READ_TEXT_ASSET:
                    methodName = "readTextAsset";
                    f_readTextAsset(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_READ_TEXT_RESOURCE:
                    methodName = "readTextResource";
                    f_readTextResource(boriview, ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_READ_ALL_TEXT:
                    methodName = "readAllText";
                    f_readAllText(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_WRITE_ALL_TEXT:
                    methodName = "writeAllText";
                    f_writeAllText((cFile) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_EXISTS:
                    methodName = "exists";
                    f_exists(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_DELETE:
                    methodName = "delete";
                    f_delete(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_LIST:
                    methodName = "list";
                    f_list(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_TOSTRING:
                    methodName = "toString";
                    f_toString(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_IS_DIRECTORY:
                    methodName = "isDirectory";
                    f_isDirectory(ret, (cFile) stack.get(ct - 1).var);
                    break;
                case FNC_IS_FILE:
                    methodName = "isFile";
                    f_isFile(ret, (cFile) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> File." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cString path, cString name)
    {
        ret.var = new cFile(new File(path.text, name.text));
    }
    private static void f_new2(_Container ret, cFile path, cString name)
    {
        ret.var = new cFile(new File(path.file_, name.text));
    }
    private static void f_readTextAsset(_BoriView boriview, _Container ret, cString fileName) throws Exception
    {
        InputStream is = boriview.bori.getAssets().open(fileName.text);
        ret.var = new cString(readText(is));
        is.close();
    }
    private static void f_readTextResource(_BoriView boriview, _Container ret, cString resName) throws Exception
    {
        InputStream is = boriview.bori.getResources().openRawResource(_Util.getResID(boriview.bori, resName.text));
        ret.var = new cString(readText(is));
        is.close();
    }
    private static void checkNull(cFile file) throws Exception
    {
        if (file.file_ == null)
            throw new Exception("File path is not specified.");
    }
    private static void f_readAllText(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        FileInputStream fis = new FileInputStream(file.file_);
        ret.var = new cString(readText(fis));
        fis.close();
    }
    private static void f_writeAllText(cFile file, cString text) throws Exception
    {
        checkNull(file);
        FileOutputStream fos = new FileOutputStream(file.file_);
        fos.write(text.text.getBytes());
        fos.close();
    }
    private static void f_exists(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        ret.var = new cBool(file.file_.exists());
    }
    private static void f_delete(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        ret.var = new cBool(file.file_.delete());
    }
    private static void f_list(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        if (!file.file_.isDirectory())
            throw new Exception("The path is not a directory.");
        ret.var = new cStrs(file.file_.list());
    }
    private static void f_toString(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        ret.var = new cString(file.file_.toString());
    }
    private static void f_isDirectory(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        ret.var = new cBool(file.file_.isDirectory());
    }
    private static void f_isFile(_Container ret, cFile file) throws Exception
    {
        checkNull(file);
        ret.var = new cBool(file.file_.isFile());
    }
}
