package com.sangdeuk.fragment1;

import android.content.Context;
import android.content.res.Resources;

class cResources extends cVar
{
    cResources()
    {
        super(cType.TRESOURCES);
    }

    private static String getString(Context context, String resourceName)
    {
        Resources res = context.getResources();
        final int resourceId = res.getIdentifier(resourceName, null, context.getPackageName());
        return res.getString(resourceId);
    }

    //-----------------------------------------------------------
    private static final int FNC_GET_STRING = 0, FNC_GET_DRAWABLE = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_GET_STRING: f_getString(boriview, ret, (cString)stack.get(ct-1).var); break;
            case FNC_GET_DRAWABLE: f_getDrawable(boriview, ret, (cString)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Resources class method:" + nfunc);
        }
    }

    private static void f_getString(_BoriView boriview, _Container ret, cString name)
    {
        ret.var = new cString(getString(boriview.bori, name.text));
    }
    private static void f_getDrawable(_BoriView boriview, _Container ret, cString name)
    {
        ret.var = new cDrawable(_Util.getDrawable(boriview.bori, name.text));
    }
}
