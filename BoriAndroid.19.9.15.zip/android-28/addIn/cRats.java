package bori.sangdeuk.arraytest;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

class cRats extends cVar implements Parcelable
{
    private ArrayList<cRat> list_;

    cRats()
    {
        super(cType.TRATS);
        list_ = new ArrayList<>();
    }
    cRats(cRats is)
    {
        super(cType.TRATS);
        list_ = new ArrayList<>();
        copyFrom(is);
    }
    cRats(ArrayList<cRat> list)
    {
        super(cType.TRATS);
        list_ = new ArrayList<>(list);
    }
    cRats(Parcel parcel)
    {
        super(cType.TRAT);
        readFromParcel(parcel);
    }

    int count () { return list_.size(); }
    void add(cRat value) { list_.add(value); }
    void add(long value) { list_.add(new cRat(value)); }
    cRat get(int index) { return list_.get(index); }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(list_.size());
        for (cRat v : list_)
        {
            dest.writeLong(v.numerator);
            dest.writeLong(v.denominator);
        }
    }

    private void readFromParcel(Parcel in)
    {
        list_ = new ArrayList<>();

        int ct = in.readInt();
        for (int i = 0; i < ct; i++)
        {
            cRat r = new cRat();
            r.numerator = in.readLong();
            r.denominator = in.readLong();
            list_.add(r);
        }
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cRats createFromParcel(Parcel in) { return new cRats(in); }

        public cRats[] newArray(int size) { return new cRats[size]; }
    };

    //------------------------------------------------------------------
    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cRats)
        {
            cRats src = (cRats)var;
            for (cRat val : src.list_) list_.add(val);
        }
    }
    @Override
    public void clear()
    {
        list_.clear();
    }
    @Override
    public String toString()
    {
        int ct = list_.size();
        if (ct < 1)
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append(list_.get(i));
        }
        sb.append(" ]");
        return new String(sb);
    }

    private void shuffleSelf()
    {
        int ct = list_.size();
        Random random = new Random();
        for (int i = ct - 1; i > 0; i--)
        {
            int r = random.nextInt(i+1);
            if (r != i)
            {
                cRat temp = list_.get(i);
                list_.set(i, list_.get(r));
                list_.set(r, temp);
            }
        }
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_GET = 2, FNC_SHUFFLE = 3,
    FNC_REPLACE = 4, FNC_CLEAR = 5, FNC_SWAP = 6, FNC_CONTAINS = 7, FNC_SORT = 8, FNC_SORT_REV = 9,
            FNC_REVERSE = 10, FNC_REMOVE = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add((cRats) stack.get(ct - 2).var, (cRat) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cRats) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_getValue(ret, (cRats) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SHUFFLE:
                    methodName = "shuffle";
                    f_shuffle(ret, (cRats) stack.get(ct - 1).var);
                    break;
                case FNC_REPLACE:
                    methodName = "replace";
                    f_replace((cRats) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cRat) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cRats) stack.get(ct - 1).var);
                    break;
                case FNC_SWAP:
                    methodName = "swap";
                    f_swap((cRats) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS:
                    methodName = "contains";
                    f_contains(ret, (cRats) stack.get(ct - 2).var, (cRat) stack.get(ct - 1).var);
                    break;
                case FNC_SORT:
                    methodName = "sort";
                    f_sort(ret, (cRats) stack.get(ct - 1).var);
                    break;
                case FNC_SORT_REV:
                    methodName = "sortRev";
                    f_sortRev(ret, (cRats) stack.get(ct - 1).var);
                    break;
                case FNC_REVERSE:
                    methodName = "reverse";
                    f_reverse(ret, (cRats) stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE:
                    methodName = "remove";
                    f_remove((cRats) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Rats." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add (cRats strs, cRat val)
    {
        strs.list_.add(val);
    }
    private static void f_count (_Container ret, cRats list)
    {
        ret.var = new cInt(list.list_.size());
    }
    private static void f_getValue (_Container ret, cRats list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index);
        ret.var = new cRat(list.list_.get(index));
    }
    private static void f_shuffle (_Container ret, cRats rs)
    {
        cRats rs2 = new cRats(rs);
        rs2.shuffleSelf();
        ret.var = rs2;
    }
    private static void f_replace (cRats is, cInt n, cRat value) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(is.list_, index);
        is.list_.set(index, value);
    }
    private static void f_clear (cRats list) { list.list_.clear(); }
    private static void f_swap (cRats list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1);
        _Util.checkIndex(list.list_, index2);
        cRat value = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, value);
    }
    private static void f_contains (_Container ret, cRats rs, cRat value)
    {
        boolean found = false;
        for (cRat v : rs.list_)
        {
            if (v.eq(value))
            {
                found = true;
                break;
            }
        }
        ret.var = new cBool(found);
    }
    private static void f_sort (_Container ret, cRats rs)
    {
        ArrayList<cRat> listNew = new ArrayList<>(rs.list_);
        Collections.sort(listNew);
        ret.var = new cRats(listNew);
    }
    private static void f_sortRev (_Container ret, cRats rs)
    {
        ArrayList<cRat> listNew = new ArrayList<>(rs.list_);
        Collections.sort(listNew);
        Collections.reverse(listNew);
        ret.var = new cRats(listNew);
    }
    private static void f_reverse (_Container ret, cRats rs)
    {
        ArrayList<cRat> listNew = new ArrayList<>(rs.list_);
        Collections.reverse(listNew);
        ret.var = new cRats(listNew);
    }
    private static void f_remove (cRats rs, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(rs.list_, index);
        rs.list_.remove(index);
    }
}
