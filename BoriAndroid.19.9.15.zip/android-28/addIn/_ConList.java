package bori.android.listview;

import java.util.ArrayList;

public class _ConList extends ArrayList<_Container>
{
}
