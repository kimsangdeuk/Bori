package bori.sangdeuk.actionbar3;

import java.util.HashMap;
import java.util.Map;

class cVars extends cVar
{
    HashMap<String, _Container> map;

    cVars()
    {
        super(cType.TVARS);
        map = new HashMap<>();
    }
    cVars(cVars vars)
    {
        super(cType.TVARS);
        if (vars == null)
            map = new HashMap<>();
        else
            map = vars.map;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cVars)
            map = ((cVars)var).map;
    }

    @Override
    public void clear()
    {
        map.clear();
    }

    void set(String key, _Container con)
    {
        map.put(key, con);
    }

    private boolean contains(String keyFind)
    {
        for(Map.Entry<String, _Container> entry : map.entrySet())
        {
            if (keyFind.equals(entry.getKey()))
                return true;
        }
        return false;
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_SET = 0, FNC_CONTAINS = 1, FNC_GET_BOOL = 2,
            FNC_GET_STRING = 3, FNC_GET_INT = 4, FNC_GET_RAT = 5, FNC_GET_DOUBLE = 6,
            FNC_GET_STRS = 7, FNC_GET_INTS = 8, FNC_GET = 9;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET:
                    methodName = "set";
                    f_set((cVars) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, stack.get(ct - 1));
                    break;
                case FNC_CONTAINS:
                    methodName = "contains";
                    f_contains(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_BOOL:
                    methodName = "getBool";
                    f_get_bool(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_STRING:
                    methodName = "getString";
                    f_get_string(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_INT:
                    methodName = "getInt";
                    f_get_int(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_RAT:
                    methodName = "getRat";
                    f_get_rat(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_DOUBLE:
                    methodName = "getDouble";
                    f_get_double(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_STRS:
                    methodName = "getStrs";
                    f_get_strs(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_INTS:
                    methodName = "getInts";
                    f_get_ints(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_get(ret, (cVars) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Vars." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_set(cVars vars, cString name, _Container var)
    {
        vars.set(name.text(), var);
    }
    private static void f_contains(_Container ret, cVars vars, cString key)
    {
        ret.var = new cBool(vars.contains(key.text()));
    }
    private static void f_get_bool(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cBool)
            ret.var = new cBool((cBool)con.var);
        else
            ret.var = new cBool();
    }
    private static void f_get_string(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cString)
            ret.var = new cString((cString)con.var);
        else
            ret.var = new cString();
    }
    private static void f_get_int(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cInt)
            ret.var = new cInt((cInt) con.var);
        else
            ret.var = new cInt();
    }
    private static void f_get_rat(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cRat)
            ret.var = new cRat((cRat) con.var);
        else
            ret.var = new cRat();
    }
    private static void f_get_double(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cDouble)
            ret.var = new cDouble((cDouble) con.var);
        else
            ret.var = new cDouble();
    }
    private static void f_get_strs(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cStrs)
            ret.var = new cStrs((cStrs)con.var);
        else
            ret.var = new cStrs();
    }
    private static void f_get_ints(_Container ret, cVars vars, cString key)
    {
        _Container con = vars.map.get(key.text);
        if (con != null && con.var instanceof cInts)
            ret.var = new cInts((cInts)con.var);
        else
            ret.var = new cInts();
    }
    private static void f_get(_Container ret, cVars vars, cString key) throws Exception
    {
        _Container con = vars.map.get(key.text);
        if (con == null)
            throw new Exception("Can not find the key '" + key + "'");
        ret.var = con.var;
    }
}
