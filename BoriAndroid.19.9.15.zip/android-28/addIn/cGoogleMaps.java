package com.sangdeuk.fragment1;

import android.content.Intent;
import android.net.Uri;

public class cGoogleMaps extends cVar
{
    cGoogleMaps()
    {
        super(cType.TGOOGLEMAPS);
    }

    private static final int FNC_LOCATE = 0, FNC_LOCATE2 = 1, FNC_LOCATE3 = 2,
            FNC_NAVIGATE = 3, FNC_STREET_VIEW = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_LOCATE: f_locate(boriview, (cRat)stack.get(ct-2).var, (cRat)stack.get(ct-1).var); break;
            case FNC_LOCATE2: f_locate2(boriview, (cString)stack.get(ct-1).var); break;
            case FNC_LOCATE3: f_locate3(boriview, (cRat)stack.get(ct-3).var, (cRat)stack.get(ct-2).var, (cString)stack.get(ct-1).var); break;
            case FNC_NAVIGATE: f_navigate(boriview, (cString)stack.get(ct-1).var); break;
            case FNC_STREET_VIEW: f_streetView(boriview, (cRat)stack.get(ct-2).var, (cRat)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported GoogleMaps class method:" + nfunc);
        }
    }

    private static void f_locate(_BoriView boriview, cRat latitude, cRat longitude)
    {
        Uri gmmIntentUri = Uri.parse("geo:" + latitude.toString() + "," + longitude.toString());
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        boriview.bori.startActivity(mapIntent);
    }
    private static void f_locate2(_BoriView boriview, cString query)
    {
        Uri gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(query.text));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        boriview.bori.startActivity(mapIntent);
    }
    private static void f_locate3(_BoriView boriview, cRat latitude, cRat longitude, cString query)
    {
        Uri gmmIntentUri = Uri.parse("geo:" + latitude.toString() + "," + longitude.toString() + "?q=" + Uri.encode(query.text));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        boriview.bori.startActivity(mapIntent);
    }
    private static void f_navigate(_BoriView boriview, cString query)
    {
        Uri gmmIntentUri = Uri.parse("google.navigation:q=" + Uri.encode(query.text));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        boriview.bori.startActivity(mapIntent);
    }
    private static void f_streetView(_BoriView boriview, cRat latitude, cRat longitude)
    {
        Uri gmmIntentUri = Uri.parse("google.streetview:cbll=" + latitude.toString() + "," + longitude.toString());
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        boriview.bori.startActivity(mapIntent);
    }
}
