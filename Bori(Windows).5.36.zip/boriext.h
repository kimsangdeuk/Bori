#ifndef DITTOEXT_H
#define DITTOEXT_H

#include <windows.h>

const wchar_t* getFunctionPrototypeW (int n);
HWND createExtensionWindow (HWND hparent, int id);

//WM_NOTIFY 
// wParam : idCtrl
// lParam : pointer of tagEXTNOTIFY

typedef struct tagDTOEXTNOTIFY
{
	HWND hwndFrom; 
	UINT idFrom; 
	int	eventType;
	int value;
	wchar_t bom; // always should be bom = (wchar_t)0xFEFF
	const wchar_t* text;
	int	x;
	int	y;
	int	width;
	int height;
} DTOEXTNOTIFY; 

// eventType
#define DTOEXT_EVENT_OPEN		0x01
#define DTOEXT_EVENT_CLOSE		0x02
#define DTOEXT_EVENT_UPDATE		0x03
#define DTOEXT_EVENT_SELECT	0x04
#define DTOEXT_EVENT_GETFOCUS		0x05
#define DTOEXT_EVENT_COMMAND	0x06

#define DTOEXT_EVENT_MOUSECLICK	0x10
#define DTOEXT_EVENT_MOUSEDOWN	0x11
#define DTOEXT_EVENT_MOUSEUP	0x12

#define DTOEXT_EVENT_USER		0x1000

#endif	// end of DITTOEXT_H
