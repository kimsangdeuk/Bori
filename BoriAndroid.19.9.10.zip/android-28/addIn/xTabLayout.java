package bori.sangdeuk.tablayout_viewpager;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.view.View;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xTabLayout extends TabLayout
{
    private _BoriView boriview_;
    private Integer backColor_ = null;
    private Integer backColorSel_ = null;
    private Integer iconColor_ = null;
    private Integer iconColorSel_ = null;
    private String methodOnSelected = null;
    private xViewPager pagerSynced_ = null;

    public xTabLayout (Context context)
    {
        super(context);
        setTabMode(MODE_SCROLLABLE);
        setTabGravity(GRAVITY_FILL);

    }
    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;

        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));

        addOnTabSelectedListener(new BaseOnTabSelectedListener()
        {
                @Override
                public void onTabSelected(Tab tab)
                {
                    changeTabColor(tab, true);

                    if (pagerSynced_ != null)
                    {
                        int index = getSelectedTabPosition();
                        pagerSynced_.setCurrent(index);
                    }

                    if (methodOnSelected != null)
                    {

                        _ConList params = new _ConList();
                        cInt index = new cInt(tab.getPosition() + _Env.iBase);
                        params.add(new _Container(index));
                        boriview_.call(methodOnSelected, params);
                    }
                }

                @Override
                public void onTabUnselected(Tab tab)
                {
                    changeTabColor(tab, false);
                }

                @Override
                public void onTabReselected(Tab tab)
                {

                }
        });
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
    }
    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            if (name.equals("onTabClick"))
                methodOnSelected = method;
        }
    }

    void addItem(String name, String iconName) throws Exception
    {
        TabLayout.Tab tab = newTab();
        tab.setText(name);
        if (iconName != null)
        {
            Drawable d = _Util.getDrawable(boriview_.bori, iconName);
            if (d != null)
                tab.setIcon(d);
        }
        addTab(tab, false);
        changeTabColor(tab, false);
    }

    void selectTabIndex(String name)
    {
        try
        {
            int index = getItemIndex(name);
            selectTabIndex(index);
        }
        catch(Exception e)
        {
            _Alert.show(boriview_.bori, "Error", e.getMessage());
            return;
        }
    }
    void selectTabIndex(final int index)
    {
        try
        {
            checkIndex(index);
        }
        catch(Exception e)
        {
            _Alert.show(boriview_.bori, "Error", e.getMessage());
            return;
        }
        if (getSelectedTabPosition() == index)
            return;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                setScrollPosition(index, 0, true);
                getTabAt(index).select();
            }
        },100);
    }
    void setTextColors(int normalColor, int selectedColor)
    {
        setTabTextColors(normalColor, selectedColor);
    }
    void setIconColors(int normalColor, int selectedColor)
    {
        iconColor_ = normalColor;
        iconColorSel_ = selectedColor;
        int sel = getSelectedTabPosition();
        for (int i = 0, ct = getTabCount(); i < ct; i++)
        {
            TabLayout.Tab tab = getTabAt(i);
            Drawable icon = tab.getIcon();
            if (icon != null)
                icon.setColorFilter(i == sel ? iconColorSel_ : iconColor_, PorterDuff.Mode.SRC_IN);
        }
    }
    void setBackColors(int normalColor, int selectedColor)
    {
        backColor_ = normalColor;
        backColorSel_ = selectedColor;
        int sel = getSelectedTabPosition();
        for (int i = 0, ct = getTabCount(); i < ct; i++)
        {
            TabLayout.Tab tab = getTabAt(i);
            View view = tab.view;
            view.setBackgroundColor(i == sel ? backColorSel_ : backColor_);
        }
    }
    private void changeTabColor(Tab tab, boolean selected)
    {
        if (iconColorSel_ != null)
        {
            Drawable icon = tab.getIcon();
            if (icon != null)
                icon.setColorFilter(selected ? iconColorSel_ : iconColor_, PorterDuff.Mode.SRC_IN);
        }

        if (backColorSel_ != null)
        {
            View view = tab.view;
            view.setBackgroundColor(selected ? backColorSel_ : backColor_);
            view.invalidate();
        }
    }

    private void checkIndex(int index) throws Exception
    {
        if (index < 0 || index >= getTabCount())
            throw new Exception("Index is out of Bound: " + (index + _Env.iBase));
    }

    String getItemText(int index) throws Exception
    {
        checkIndex(index);
        Tab tab = getTabAt(index);
        return tab.getText().toString();
    }
    int getItemIndex(String name) throws Exception
    {
        for (int i = 0, ct = getTabCount(); i < ct; i++)
        {
            Tab tab = getTabAt(i);
            if (name.equals(tab.getText().toString()))
                return i;
        }
        throw new Exception("Can not find the name '" + name + "'");
    }

    @SuppressWarnings("deprecation")
    void hideIndicator()
    {
        setSelectedTabIndicatorHeight(0);
    }

    void syncWithViewPager(xViewPager pager)
    {
        pagerSynced_ = pager;
        int index = getSelectedTabPosition();
        if (index < 0) // tab is not selected yet
            return;
        pagerSynced_.setCurrent(index);
    }
}



