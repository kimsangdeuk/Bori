package bori.android.listview;

class _Method
{
    String name;
    int type;
    int[] code;
    int[] data;

    _Method(String name_, String type_, String code_, String data_)
    {
        name = name_;
        type = Integer.parseInt(type_);

        if (code_.equals(""))
        {
            code = new int[1];
            code[0] = 0;
        }
        else
        {
            String[] arr = code_.split(",", 0);
            code = new int[arr.length];
            for (int i = 0, ct = arr.length; i < ct; i++)
                code[i] = Integer.parseInt(arr[i]);
        }

        if (data_.equals(""))
            data = null;
        else
        {
            String[] arr = data_.split(",", 0);
            data = new int[arr.length];
            for (int i = 0, ct = arr.length; i < ct; i++)
                data[i] = Integer.parseInt(arr[i], 16);
        }
    }
}
