package bori.sangdeuk.arraytest;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

class cDoubles extends cVar implements Parcelable
{
    private ArrayList<Double> list_;

    cDoubles()
    {
        super(cType.TDOUBS);
        list_ = new ArrayList<>();
    }
    cDoubles(cDoubles ds)
    {
        super(cType.TDOUBS);
        list_ = new ArrayList<>();
        copyFrom(ds);
    }
    cDoubles(ArrayList<Double> list)
    {
        super(cType.TDOUBS);
        list_ = new ArrayList<>(list);
    }
    cDoubles(Double[] arr)
    {
        super(cType.TDOUBS);
        list_ = new ArrayList<>();
        for (Double v : arr) list_.add(v);
    }
    cDoubles(Parcel parcel)
    {
        super(cType.TDOUBS);
        readFromParcel(parcel);
    }

    int count () { return list_.size(); }
    void add(double value) { list_.add(value); }
    double get(int index) { return list_.get(index); }
    double[] getDoubleArray()
    {
        final double[] arr = new double[list_.size()];
        int index = 0;
        for (final Double value : list_)
        {
            arr[index++] = value;
        }
        return arr;
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(list_.size());
        for (double v : list_)
        {
            dest.writeDouble(v);
        }
    }

    private void readFromParcel(Parcel in)
    {
        list_ = new ArrayList<>();

        int ct = in.readInt();
        for (int i = 0; i < ct; i++)
        {
            list_.add(in.readDouble());
        }
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cDoubles createFromParcel(Parcel in) { return new cDoubles(in); }

        public cDoubles[] newArray(int size) { return new cDoubles[size]; }
    };

    //------------------------------------------------------------------
    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cDoubles)
        {
            cDoubles src = (cDoubles)var;
            for (Double val : src.list_) list_.add(val);
        }
    }
    @Override
    public void clear()
    {
        list_.clear();
    }
    @Override
    public String toString()
    {
        int ct = list_.size();
        if (ct < 1)
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append(list_.get(i));
        }
        sb.append(" ]");
        return new String(sb);
    }

    private void shuffleSelf()
    {
        int ct = list_.size();
        Random random = new Random();
        for (int i = ct - 1; i > 0; i--)
        {
            int r = random.nextInt(i+1);
            if (r != i)
            {
                double temp = list_.get(i);
                list_.set(i, list_.get(r));
                list_.set(r, temp);
            }
        }
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_GET = 2, FNC_SHUFFLE = 3,
    FNC_REPLACE = 4, FNC_CLEAR = 5, FNC_SWAP = 6, FNC_CONTAINS = 7, FNC_SORT = 8, FNC_SORT_REV = 9,
    FNC_REVERSE = 10, FNC_REMOVE = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add((cDoubles) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_getValue(ret, (cDoubles) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SHUFFLE:
                    methodName = "shuffle";
                    f_shuffle(ret, (cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_REPLACE:
                    methodName = "replace";
                    f_replace((cDoubles) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_SWAP:
                    methodName = "swap";
                    f_swap((cDoubles) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS:
                    methodName = "contains";
                    f_contains(ret, (cDoubles) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_SORT:
                    methodName = "sort";
                    f_sort(ret, (cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_SORT_REV:
                    methodName = "sortRev";
                    f_sortRev(ret, (cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_REVERSE:
                    methodName = "reverse";
                    f_reverse(ret, (cDoubles) stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE:
                    methodName = "remove";
                    f_remove((cDoubles) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Doubles." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add (cDoubles strs, cDouble val)
    {
        strs.list_.add(val.value);
    }
    private static void f_count (_Container ret, cDoubles list)
    {
        ret.var = new cInt(list.list_.size());
    }
    private static void f_getValue (_Container ret, cDoubles list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index);
        ret.var = new cDouble(list.list_.get(index));
    }
    private static void f_shuffle (_Container ret, cDoubles list)
    {
        cDoubles list2 = new cDoubles(list);
        list2.shuffleSelf();
        ret.var = list2;
    }
    private static void f_replace (cDoubles ds, cInt n, cDouble value) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(ds.list_, index);
        ds.list_.set(index, value.value);
    }
    private static void f_clear (cDoubles list) { list.list_.clear(); }
    private static void f_swap (cDoubles list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1);
        _Util.checkIndex(list.list_, index2);
        double value = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, value);
    }
    private static void f_contains (_Container ret, cDoubles ds, cDouble value)
    {
        ret.var = new cBool(ds.list_.contains(value.value));
    }
    private static void f_sort (_Container ret, cDoubles ds)
    {
        ArrayList<Double> listNew = new ArrayList<>(ds.list_);
        Collections.sort(listNew);
        ret.var = new cDoubles(listNew);
    }
    private static void f_sortRev (_Container ret, cDoubles ds)
    {
        ArrayList<Double> listNew = new ArrayList<>(ds.list_);
        Collections.sort(listNew, Collections.reverseOrder());
        ret.var = new cDoubles(listNew);
    }
    private static void f_reverse (_Container ret, cDoubles ds)
    {
        ArrayList<Double> listNew = new ArrayList<>(ds.list_);
        Collections.reverse(listNew);
        ret.var = new cDoubles(listNew);
    }
    private static void f_remove (cDoubles ds, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(ds.list_, index);
        ds.list_.remove(index);
    }
}
