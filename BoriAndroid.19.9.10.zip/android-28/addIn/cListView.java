package bori.sangdeuk.test;

class cListView extends cControl
{
    cListView()
    {
        super(cType.TC_LISTVIEW);
    }
    cListView(xListView view_)
    {
        super(cType.TC_LISTVIEW);
        view = view_;
    }

    private static final int FNC_ADD_ITEM = 0, FNC_REMOVE_ITEM = 1, FNC_CLEAR = 2, FNC_COUNT = 3, FNC_GET_ITEM = 4,
            FNC_SCROLL_TO = 5;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD_ITEM:
                    methodName = "addItem";
                    f_addItem(ret, (cListView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE_ITEM:
                    methodName = "removeItem";
                    f_removeItem((cListView) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cListView) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cListView) stack.get(ct - 1).var);
                    break;
                case FNC_GET_ITEM:
                    methodName = "getItem";
                    f_getItem(ret, (cListView) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SCROLL_TO:
                    methodName = "scrollTo";
                    f_scrollTo((cListView) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> ListView." + methodName + "\n" + e.getMessage());
        }
    }
    private static void f_addItem(_Container ret, cListView listview, cString viewName) throws Exception
    {
        xLinearLayout layout = ((xListView)listview.view).addItem(viewName.text);
        ret.var = new cControl(layout);
    }
    private static void f_removeItem(cListView listview, cInt index) throws Exception
    {
        ((xListView)listview.view).removeItem((int)index.value - _Env.iBase);
    }
    private static void f_clear(cListView listview)
    {
        ((xListView)listview.view).clear();
    }
    private static void f_count(_Container ret, cListView listview)
    {
        ret.var = new cInt(((xListView)listview.view).count());
    }
    private static void f_getItem(_Container ret, cListView listview, cInt index) throws Exception
    {
        xLinearLayout layout = ((xListView)listview.view).getItem((int)index.value - _Env.iBase);
        ret.var = new cControl(layout);
    }
    private static void f_scrollTo(cListView listview, cInt index, cBool smooth) throws Exception
    {
        ((xListView)listview.view).scrollTo((int)index.value - _Env.iBase, smooth.isTrue());
    }
}
