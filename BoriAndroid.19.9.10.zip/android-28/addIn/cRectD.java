package com.sangdeuk.fragment1;

import android.graphics.RectF;

class cRectD extends cVar
{
    private cDouble left_;
    private cDouble top_;
    private cDouble right_;
    private cDouble bottom_;

    cRectD()
    {
        super(cType.TRECTD);
        left_ = new cDouble(0.0d);
        top_ = new cDouble(0.0d);
        right_ = new cDouble(0.0d);
        bottom_ = new cDouble(0.0d);
    }
    cRectD(double left, double top, double right, double bottom)
    {
        super(cType.TRECTD);
        set(left, top, right, bottom);
    }
    void set(double left, double top, double right, double bottom)
    {
        left_ = new cDouble(left);
        top_ = new cDouble(top);
        right_ = new cDouble(right);
        bottom_ = new cDouble(bottom);
    }

    RectF getRectF()
    {
        return new RectF((float)left_.value, (float)top_.value, (float)right_.value, (float)bottom_.value);
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cRectD)
        {
            cRectD src = (cRectD)var;
            left_.value = src.left_.value;
            top_.value = src.top_.value;
            right_.value = src.right_.value;
            bottom_.value = src.bottom_.value;
        }
    }
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("{ left:");
        sb.append(left_.value);
        sb.append(", top:");
        sb.append(top_.value);
        sb.append(", right:");
        sb.append(right_.value);
        sb.append(", bottom:");
        sb.append(bottom_.value);
        sb.append(" }");
        return new String(sb);
    }

    private boolean contains(double x, double y)
    {
        if (x < left_.value || x > right_.value)
            return false;
        if (y < top_.value || y > bottom_.value)
            return false;
        return true;
    }
    private boolean contains(double left, double top, double right, double bottom)
    {
        return (contains(left, top) && contains(right, bottom));
    }
    private boolean contains(cRectD rect)
    {
        return (contains(rect.left_.value, rect.top_.value) && contains(rect.right_.value, rect.bottom_.value));
    }

    //-----------------------------------------------------------
    private static final int FLD_LEFT = 0, FLD_TOP = 1, FLD_RIGHT = 2, FLD_BOTTOM = 3;
    static void getVar(int n, _Container ret, _Container con)
    {
        cRectD r = (cRectD)con.var;
        switch(n)
        {
            case FLD_LEFT: ret.var = r.left_; break;
            case FLD_TOP: ret.var = r.top_; break;
            case FLD_RIGHT: ret.var = r.right_; break;
            case FLD_BOTTOM: ret.var = r.bottom_; break;
        }
    }

    //-----------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_NEW2 = 1, FNC_SET = 2, FNC_SET2 = 3, FNC_OFFSET = 4,
            FNC_CONTAINS_LTRB = 5, FNC_CONTAINS_RECT = 6, FNC_CONTAINS_XY = 7, FNC_INFLATE = 8;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret,
                            (cDouble) stack.get(ct - 4).var, (cDouble) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_NEW2:
                    methodName = "new";
                    f_new2(ret, (cRectD) stack.get(ct - 1).var);
                    break;
                case FNC_SET:
                    methodName = "set";
                    f_set((cRectD) stack.get(ct - 5).var,
                            (cDouble) stack.get(ct - 4).var, (cDouble) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_SET2:
                    methodName = "set";
                    f_set2((cRectD) stack.get(ct - 2).var, (cRectD) stack.get(ct - 1).var);
                    break;
                case FNC_OFFSET:
                    methodName = "offset";
                    f_offset((cRectD) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS_LTRB:
                    methodName = "contains";
                    f_containsLTRB(ret, (cRectD) stack.get(ct - 5).var,
                            (cDouble) stack.get(ct - 4).var, (cDouble) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS_RECT:
                    methodName = "contains";
                    f_containsRect(ret, (cRectD) stack.get(ct - 2).var, (cRectD) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS_XY:
                    methodName = "contains";
                    f_containsXY(ret, (cRectD) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_INFLATE:
                    methodName = "inflate";
                    f_inflate((cRectD) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> RectD." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cDouble l, cDouble t, cDouble r, cDouble b)
    {
        ret.var = new cRectD(l.value, t.value, r.value, b.value);
    }
    private static void f_new2(_Container ret, cRectD rectFrom)
    {
        ret.var = new cRectD(rectFrom.left_.value, rectFrom.top_.value, rectFrom.right_.value, rectFrom.bottom_.value);
    }
    private static void f_set(cRectD rect, cDouble l, cDouble t, cDouble r, cDouble b)
    {
        rect.set(l.value, t.value, r.value, b.value);
    }
    private static void f_set2(cRectD rect, cRectD rectFrom)
    {
        rect.set(rectFrom.left_.value, rectFrom.top_.value, rectFrom.right_.value, rectFrom.bottom_.value);
    }
    private static void f_offset(cRectD rect, cDouble dx, cDouble dy)
    {
        rect.left_.value += dx.value;
        rect.top_.value += dy.value;
        rect.right_.value += dx.value;
        rect.bottom_.value += dy.value;
    }
    private static void f_containsLTRB(_Container ret, cRectD rect, cDouble l, cDouble t, cDouble r, cDouble b)
    {
        ret.var = new cBool(rect.contains(l.value, t.value, r.value, b.value));
    }
    private static void f_containsRect(_Container ret, cRectD rect, cRectD rectTest)
    {
        ret.var = new cBool(rect.contains(rectTest));
    }
    private static void f_containsXY(_Container ret, cRectD rect, cDouble x, cDouble y)
    {
        ret.var = new cBool(rect.contains(x.value, y.value));
    }
    private static void f_inflate(cRectD rect, cDouble dx, cDouble dy)
    {
        rect.left_.value -= dx.value;
        rect.top_.value -= dy.value;
        rect.right_.value += dx.value;
        rect.bottom_.value += dy.value;
    }
}
