package com.sangdeuk.fragment1;

import android.content.Context;
import android.os.Vibrator;

class cVibrator extends cVar
{
    private Vibrator vib_ = null;

    cVibrator()
    {
        super(cType.TVIBRATOR);
    }

    private void alloc(BoriActivity bori)
    {
        if (vib_ == null)
            vib_ = (Vibrator)bori.getSystemService(Context.VIBRATOR_SERVICE);
    }

    //---------------------------------------------------------------------
    private static final int FNC_VIBRATE = 0, FNC_VIBRATE_PATTERN = 1, FNC_CANCEL = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_VIBRATE:
                    methodName = "vibrate";
                    f_vibrate(boriview, (cVibrator) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_VIBRATE_PATTERN:
                    methodName = "vibrate";
                    f_vibratePattern(boriview, (cVibrator) stack.get(ct - 3).var, (cInts) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_CANCEL:
                    methodName = "cancel";
                    f_cancel((cVibrator) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Vibrator." + methodName + "\n" + e.getMessage());
        }
    }

    @SuppressWarnings("deprecation")
    private static void f_vibrate(_BoriView boriview, cVibrator vib, cInt milliseconds)
    {
        vib.alloc(boriview.bori);
        vib.vib_.vibrate(milliseconds.value);
    }
    @SuppressWarnings("deprecation")
    private static void f_vibratePattern(_BoriView boriview, cVibrator vib, cInts pattern, cBool repeat)
    {
        vib.alloc(boriview.bori);
        long[] lp = new long[pattern.count()];
        for (int i = 0, ct = pattern.count(); i < ct; i++)
            lp[i] = pattern.get(i);

        vib.vib_.vibrate(lp, repeat.isTrue() ? 0 : -1);
    }
    private static void f_cancel(cVibrator vib)
    {
        if (vib.vib_ != null)
            vib.vib_.cancel();
    }
}
