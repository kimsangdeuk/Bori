package com.sangdeuk.fragment1;

public class cDouble extends cVar
{
    double value;

    static final double NULL = Double.NEGATIVE_INFINITY;

    cDouble()
    {
        super(cType.TDOUBLE);
        value = NULL;
    }
    cDouble(cDouble d)
    {
        super(cType.TDOUBLE);
        value = d.value;
    }
    cDouble(double val)
    {
        super(cType.TDOUBLE);
        value = val;
    }

    void setNull()
    {
        value = NULL;
    }
    void set(double val)
    {
        value = val;
    }
    void set(long lval)
    {
        if (lval == cInt.NULL)
            value = NULL;
        else
            value = new Double(lval);
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cDouble)
            value = ((cDouble)var).value;
    }
    @Override
    public void clear()
    {
        value = NULL;
    }
    @Override
    public boolean isNull() { return value == NULL; }
    @Override
    public String toString()
    {
        if (value == NULL)
            return "NA";
        return Double.toString(value);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_PARSE = 1, FNC_TOSTRING = 2, FNC_ABS = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_NEW: f_new(ret, (cDouble)stack.get(ct-1).var); break;
            case FNC_PARSE: f_parse(ret, (cString)stack.get(ct-1).var); break;
            case FNC_TOSTRING: f_toString(ret, (cDouble)stack.get(ct-1).var); break;
            case FNC_ABS: f_abs(ret, (cDouble)stack.get(ct-1).var); break;
            default:
                throw new Exception("Unsupported Int class method:" + nfunc);
        }
    }

    private static void f_new(_Container ret, cDouble val)
    {
        ret.var = new cDouble(val.value);
    }
    private static void f_parse(_Container ret, cString s)
    {
        double val = s.text.equals("") ? NULL :Double.parseDouble(s.text);
        ret.var = new cDouble(val);
    }
    private static void f_toString(_Container ret, cDouble val)
    {
        ret.var = new cString(val.toString());
    }
    private static void f_abs(_Container ret, cDouble val)
    {
        ret.var = new cDouble(val.value < 0 ? -(val.value) : val.value);
    }
}
