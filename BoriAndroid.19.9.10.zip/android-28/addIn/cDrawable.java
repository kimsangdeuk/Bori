package com.sangdeuk.fragment1;

import android.graphics.drawable.Drawable;

public class cDrawable extends cVar
{
    Drawable drawable_;

    cDrawable()
    {
        super(cType.TDRAWABLE);
        drawable_ = null;
    }
    cDrawable(Drawable d)
    {
        super(cType.TDRAWABLE);
        drawable_ = d;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cDrawable)
        {
            cDrawable src = (cDrawable)var;
            drawable_ = src.drawable_;
        }
    }

    //-----------------------------------------------------------
    private static final int FNC_SET_BOUNDS = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_BOUNDS:
                f_setBounds((cDrawable)stack.get(ct-5).var,
                        (cInt)stack.get(ct-4).var, (cInt)stack.get(ct-3).var,
                        (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var);
                break;
            default:
                throw new Exception("Unsupported Drawable class method:" + nfunc);
        }
    }

    private static void f_setBounds(cDrawable drawable, cInt l, cInt t, cInt r, cInt b)
    {
        drawable.drawable_.setBounds((int)l.value, (int)t.value, (int)r.value, (int)b.value);
    }
}
