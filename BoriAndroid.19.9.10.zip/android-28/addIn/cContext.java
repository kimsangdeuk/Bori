package bori.sangdeuk.file_storage;

class cContext extends cVar
{
    cContext()
    {
        super(cType.TCONTEXT);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_FILES_DIR = 0, FNC_GET_EXTERNAL_FILES_DIR = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getFilesDir(boriview, ret);
                    break;
                case FNC_GET_EXTERNAL_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getExternalFilesDir(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Context." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getFilesDir());
    }
    private static void f_getExternalFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getExternalFilesDir(null));
    }
}
