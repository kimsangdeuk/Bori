package bori.sangdeuk.floatingactionbutton;

public class cFloatingActionButton extends cImageView
{
    cFloatingActionButton()
    {
        super(cType.TC_FAB);
    }
    cFloatingActionButton(xFloatingActionButton view_)
    {
        super(cType.TC_FAB);
        view = view_;
    }

    //---------------------------------------------------------------------
    private static final int FNC_SET_BUTTON_COLOR = 0, FNC_SHOW = 1, FNC_HIDE = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET_BUTTON_COLOR:
                methodName = "setButtonColor";
                f_setButtonColor((cFloatingActionButton)stack.get(ct-2).var, (cColor)stack.get(ct-1).var);
                break;
            case FNC_SHOW:
                methodName = "show";
                f_show((cFloatingActionButton)stack.get(ct-1).var);
                break;
            case FNC_HIDE:
                methodName = "hide";
                f_hide((cFloatingActionButton)stack.get(ct-1).var);
                break;
            default:
                throw new Exception("Unsupported class method:" + nfunc);
        }
        }
        catch(Exception e)
        {
            throw new Exception("> FloatingActionButton." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setButtonColor(cFloatingActionButton fab, cColor color)
    {
        ((xFloatingActionButton)fab.view).setButtonColor(color.intValue());
    }
    private static void f_show(cFloatingActionButton fab)
    {
        ((xFloatingActionButton)fab.view).show();
    }
    private static void f_hide(cFloatingActionButton fab)
    {
        ((xFloatingActionButton)fab.view).hide();
    }
}
