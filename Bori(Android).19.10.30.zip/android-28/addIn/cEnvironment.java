package bori.sangdeuk.imagecapture_fileprovider;

import android.os.Environment;

class cEnvironment extends cVar
{

    cEnvironment()
    {
        super(cType.TENVIRONMENT);
    }

    //-----------------------------------------------------------
    private static final int DIRECTORY_ALARMS = 0,
            //DIRECTORY_AUDIOBOOKS = 1, // API level 29
            DIRECTORY_DCIM = 2, DIRECTORY_DOCUMENTS = 3, DIRECTORY_DOWNLOADS = 4,
            DIRECTORY_MOVIES = 5, DIRECTORY_MUSIC = 6, DIRECTORY_NOTIFICATIONS = 7, DIRECTORY_PICTURES = 8, DIRECTORY_PODCASTS = 9,
            DIRECTORY_RINGTONES = 10;
            //DIRECTORY_SCREENSHOTS = 11; // API level 29

    static void getVar(int n, _Container ret, _Container con)
    {
        switch(n)
        {
            case DIRECTORY_ALARMS: ret.var = new cString(Environment.DIRECTORY_ALARMS); break;
            //case DIRECTORY_AUDIOBOOKS: ret.var = new cString(Environment.DIRECTORY_AUDIOBOOKS); break;
            case DIRECTORY_DCIM: ret.var = new cString(Environment.DIRECTORY_DCIM); break;
            case DIRECTORY_DOCUMENTS: ret.var = new cString(Environment.DIRECTORY_DOCUMENTS); break;
            case DIRECTORY_DOWNLOADS: ret.var = new cString(Environment.DIRECTORY_DOWNLOADS); break;
            case DIRECTORY_MOVIES: ret.var = new cString(Environment.DIRECTORY_MOVIES); break;
            case DIRECTORY_MUSIC: ret.var = new cString(Environment.DIRECTORY_MUSIC); break;
            case DIRECTORY_NOTIFICATIONS: ret.var = new cString(Environment.DIRECTORY_NOTIFICATIONS); break;
            case DIRECTORY_PICTURES: ret.var = new cString(Environment.DIRECTORY_PICTURES); break;
            case DIRECTORY_PODCASTS: ret.var = new cString(Environment.DIRECTORY_PODCASTS); break;
            case DIRECTORY_RINGTONES: ret.var = new cString(Environment.DIRECTORY_RINGTONES); break;
            //case DIRECTORY_SCREENSHOTS: ret.var = new cString(Environment.DIRECTORY_SCREENSHOTS); break;
        }
    }

}
