package bori.sangdeuk.db_memo;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

class cInts extends cVar implements Parcelable
{
    private ArrayList<Long> list_;

    cInts()
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
    }
    cInts(cInts is)
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
        copyFrom(is);
    }
    cInts(ArrayList<Long> list)
    {
        super(cType.TINTS);
        list_ = new ArrayList<>(list);
    }
    cInts(Long[] arr)
    {
        super(cType.TINTS);
        list_ = new ArrayList<>();
        for (Long v : arr) list_.add(v);
    }
    cInts(Parcel parcel)
    {
        super(cType.TINTS);
        readFromParcel(parcel);
    }

    private void set(long[] arr)
    {
        list_ = new ArrayList<>();
        for (Long v : arr) list_.add(v);
    }
    int count () { return list_.size(); }
    void add(long value) { list_.add(value); }
    long get(int index) { return list_.get(index); }
    long[] getLongArray()
    {
        final long[] arr = new long[list_.size()];
        int index = 0;
        for (final Long value : list_)
        {
            arr[index++] = value;
        }
        return arr;
    }
    int[] getIntArray()
    {
        final int[] arr = new int[list_.size()];
        int index = 0;
        for (final Long value : list_)
        {
            arr[index++] = value.intValue();
        }
        return arr;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cInts)
        {
            cInts src = (cInts)var;
            for (Long val : src.list_) list_.add(val);
        }
    }
    @Override
    public void clear()
    {
        list_.clear();
    }
    @Override
    public String toString()
    {
        int ct = list_.size();
        if (ct < 1)
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append("[ ");
        for (int i = 0; i < ct; i++)
        {
            if (i > 0)
                sb.append(", ");
            sb.append(list_.get(i));
        }
        sb.append(" ]");
        return new String(sb);
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeLongArray(getLongArray());
    }

    private void readFromParcel(Parcel in) { set(in.createLongArray()); }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cInts createFromParcel(Parcel in) {
            return new cInts(in);
        }

        public cInts[] newArray(int size) {
            return new cInts[size];
        }
    };

    //------------------------------------------------------------------
    private void shuffleSelf()
    {
        int ct = list_.size();
        Random random = new Random();
        for (int i = ct - 1; i > 0; i--)
        {
            int r = random.nextInt(i+1);
            if (r != i)
            {
                long temp = list_.get(i);
                list_.set(i, list_.get(r));
                list_.set(r, temp);
            }
        }
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_COUNT = 1, FNC_GET = 2, FNC_SHUFFLE = 3,
    FNC_REPLACE = 4, FNC_CLEAR = 5, FNC_SWAP = 6, FNC_CONTAINS = 7, FNC_SORT = 8, FNC_SORT_REV = 9,
    FNC_REVERSE = 10, FNC_REMOVE = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add((cInts) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_COUNT:
                    methodName = "count";
                    f_count(ret, (cInts) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_getValue(ret, (cInts) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SHUFFLE:
                    methodName = "shuffle";
                    f_shuffle(ret, (cInts) stack.get(ct - 1).var);
                    break;
                case FNC_REPLACE:
                    methodName = "replace";
                    f_replace((cInts) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    methodName = "clear";
                    f_clear((cInts) stack.get(ct - 1).var);
                    break;
                case FNC_SWAP:
                    methodName = "swap";
                    f_swap((cInts) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_CONTAINS:
                    methodName = "contains";
                    f_contains(ret, (cInts) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_SORT:
                    methodName = "sort";
                    f_sort(ret, (cInts) stack.get(ct - 1).var);
                    break;
                case FNC_SORT_REV:
                    methodName = "sortRev";
                    f_sortRev(ret, (cInts) stack.get(ct - 1).var);
                    break;
                case FNC_REVERSE:
                    methodName = "reverse";
                    f_reverse(ret, (cInts) stack.get(ct - 1).var);
                    break;
                case FNC_REMOVE:
                    methodName = "remove";
                    f_remove((cInts) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Ints." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add (cInts strs, cInt val)
    {
        strs.list_.add(val.value);
    }
    private static void f_count (_Container ret, cInts list)
    {
        ret.var = new cInt(list.list_.size());
    }
    private static void f_getValue (_Container ret, cInts list, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(list.list_, index);
        ret.var = new cInt(list.list_.get(index));
    }
    private static void f_shuffle (_Container ret, cInts is)
    {
        cInts is2 = new cInts(is);
        is2.shuffleSelf();
        ret.var = is2;
    }
    private static void f_replace (cInts is, cInt n, cInt value) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(is.list_, index);
        is.list_.set(index, value.value);
    }
    private static void f_clear (cInts list) { list.list_.clear(); }
    private static void f_swap (cInts list, cInt n1, cInt n2) throws Exception
    {
        int index1 = (int)n1.value - _Env.iBase;
        int index2 = (int)n2.value - _Env.iBase;
        _Util.checkIndex(list.list_, index1);
        _Util.checkIndex(list.list_, index2);
        long value = list.list_.get(index1);
        list.list_.set(index1, list.list_.get(index2));
        list.list_.set(index2, value);
    }
    private static void f_contains (_Container ret, cInts ints, cInt value)
    {
        ret.var = new cBool(ints.list_.contains(value.value));
    }
    private static void f_sort (_Container ret, cInts is)
    {
        ArrayList<Long> listNew = new ArrayList<>(is.list_);
        Collections.sort(listNew);
        ret.var = new cInts(listNew);
    }
    private static void f_sortRev (_Container ret, cInts is)
    {
        ArrayList<Long> listNew = new ArrayList<>(is.list_);
        Collections.sort(listNew, Collections.reverseOrder());
        ret.var = new cInts(listNew);
    }
    private static void f_reverse (_Container ret, cInts is)
    {
        ArrayList<Long> listNew = new ArrayList<>(is.list_);
        Collections.reverse(listNew);
        ret.var = new cInts(listNew);
    }
    private static void f_remove (cInts is, cInt n) throws Exception
    {
        int index = (int)n.value - _Env.iBase;
        _Util.checkIndex(is.list_, index);
        is.list_.remove(index);
    }
}
