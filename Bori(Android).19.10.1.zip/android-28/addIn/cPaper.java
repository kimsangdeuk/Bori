package bori.sangdeuk.spinner;

class cPaper extends cControl
{
    cPaper()
    {
        super(cType.TC_PAPER);
    }
    cPaper(xPaper view_)
    {
        super(cType.TC_PAPER);
        view = view_;
    }

    //----------------------------------------------------------------------------
    private static final int FN_GET_WIDTH = 0, FN_GET_HEIGHT = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FN_GET_WIDTH:
                    methodName = "getWidth";
                    f_getWidth(ret, (cPaper) stack.get(ct - 1).var);
                    break;
                case FN_GET_HEIGHT:
                    methodName = "getHeight";
                    f_getHeight(ret, (cPaper) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Paper." + methodName + "\n" + e.getMessage());
        }
    }
    private static void f_getWidth(_Container ret, cPaper paper)
    {
        ret.var = new cInt(paper.view.getWidth());
    }
    private static void f_getHeight(_Container ret, cPaper paper)
    {
        ret.var = new cInt(paper.view.getHeight());
    }
}
