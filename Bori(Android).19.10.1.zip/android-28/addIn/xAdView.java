package com.sangdeuk.toctoc;

import android.content.Context;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

class xAdView
{
    private Context context_;

    AdView adView_;

    xAdView(Context context)
    {
        context_ = context;
        adView_ = new AdView(context);
        adView_.setAdSize(AdSize.BANNER);
    }

    void setIDs(String appID, String unitID)
    {
        if (appID == null || appID.isEmpty())
            MobileAds.initialize(context_, "ca-app-pub-3940256099942544~3347511713");
        else
            MobileAds.initialize(context_, appID);

        if (unitID == null || unitID.isEmpty())
            adView_.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        else
            adView_.setAdUnitId(unitID);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView_.loadAd(adRequest);
    }
}
