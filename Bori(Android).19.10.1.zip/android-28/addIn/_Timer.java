package bori.android.timer_clock;

class _Timer
{
    private String name_;
    private _TimerHandler handler_;

    _Timer(_BoriView view, String name, long interval, int repeat)
    {
        name_ = name;
        handler_ =new _TimerHandler(view, this, name, interval, repeat);
    }

    String getName() { return name_; }
    void cancel()
    {
        handler_.cancel();
    }
    void start()
    {
        handler_.start();
    }
}
