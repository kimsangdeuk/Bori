package bori.android.actbranches;

import android.os.Parcel;
import android.os.Parcelable;

class cChar extends cVar implements Parcelable
{
    char ch_;

    cChar()
    {
        super(cType.TCH);
        ch_ = 0;
    }
    cChar(cChar ch)
    {
        super(cType.TCH);
        ch_ = ch.ch_;
    }
    cChar(int val)
    {
        super(cType.TCH);
        ch_ = (char)val;
    }
    cChar(Parcel parcel)
    {
        super(cType.TCH);
        readFromParcel(parcel);
    }
    void set(int val)
    {
        ch_ = (char)val;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cChar)
            ch_ = ((cChar)var).ch_;
    }
    @Override
    public void clear()
    {
        ch_ = 0;
    }
    @Override
    public String toString()
    {
        String s = "";
        s += ch_;
        return s;
    }

    //------------------------------------------------------------------
    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeInt(ch_);
    }

    private void readFromParcel(Parcel in) { ch_ = (char)in.readInt(); }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public cChar createFromParcel(Parcel in) {
            return new cChar(in);
        }

        public cChar[] newArray(int size) {
            return new cChar[size];
        }
    };
}
