package bori.sangdeuk.network;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;

class cNetwork extends cVar
{
    cNetwork()
    {
        super(cType.TNETWORK);
    }

    //-------------------------------------------------------------
    private static final int FNC_HAS_INTERNET_CONNECTION = 0, FNC_IS_WIFI = 1;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_HAS_INTERNET_CONNECTION:
                    methodName = "hasInternetConnection";
                    f_hasInternetConnection(boriview, ret);
                    break;
                case FNC_IS_WIFI:
                    methodName = "isWiFi";
                    f_isWiFi(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Network." + methodName + "\n" + e.getMessage());
        }
    }

    @SuppressWarnings("deprecation")
    private static void f_hasInternetConnection(_BoriView boriview, _Container ret)
    {
        boolean hasConnection;
        ConnectivityManager connectivityManager = (ConnectivityManager)boriview.bori.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) // Marshmallow or higher
        {
            Network network = connectivityManager.getActiveNetwork();
            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
            hasConnection =
                    capabilities != null
                            && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                            && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }
        else
        {
            NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
            hasConnection = activeNetwork != null &&
                    activeNetwork.isConnectedOrConnecting();
        }
        ret.var = new cBool(hasConnection);
    }
    @SuppressWarnings("deprecation")
    private static void f_isWiFi(_BoriView boriview, _Container ret)
    {
        boolean isWiFi = false;
        ConnectivityManager connectivityManager = (ConnectivityManager)boriview.bori.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) // Marshmallow or higher
        {
            Network network = connectivityManager.getActiveNetwork();
            NetworkCapabilities capabilities = connectivityManager.getNetworkCapabilities(network);
            if (capabilities != null
                            && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                            && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
                isWiFi = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        }
        else
        {
            NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
            if (activeNetwork != null &&
                    activeNetwork.isConnectedOrConnecting())
                isWiFi = activeNetwork.getType() == ConnectivityManager.TYPE_WIFI;
        }
        ret.var = new cBool(isWiFi);
    }
}
