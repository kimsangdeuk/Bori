package bori.sangdeuk.db_memo;

import android.os.AsyncTask;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

class cHttpRequest extends cVar
{
    private String url_;
    private HashMap<String, String> queries_;
    private static final int GET = 0, POST = 1;
    private String methodOnResponse_ = null;

    cHttpRequest()
    {
        super(cType.THTTPREQUEST);
        queries_ = new HashMap<>();
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cHttpRequest)
        {
            cHttpRequest src = (cHttpRequest)var;
            url_ = src.url_;
            queries_ = src.queries_;
        }
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_URL = 0, FNC_ADD_QUERY = 1, FNC_ADD_QUERY_N = 2, FNC_GET = 3, FNC_POST = 4,
            FNC_SET_ON_RESPONSE = 5;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_URL:
                    methodName = "setUrl";
                    f_setUrl((cHttpRequest) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_QUERY:
                    methodName = "addQuery";
                    f_addQuery((cHttpRequest) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ADD_QUERY_N:
                    methodName = "addQueryN";
                    f_addQueryN((cHttpRequest) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_get(boriview, (cHttpRequest) stack.get(ct - 1).var);
                    break;
                case FNC_POST:
                    methodName = "post";
                    f_post(boriview, (cHttpRequest) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ON_RESPONSE:
                    methodName = "setOnResponse";
                    f_setOnResponse((cHttpRequest) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> HttpRequest." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setUrl (cHttpRequest request, cString url)
    {
        request.url_ = url.text;
    }

    private static void f_addQuery (cHttpRequest request, cString name, cString value)
    {
        request.queries_.put(name.text, value.text);
    }
    private static void f_addQueryN (cHttpRequest request, cString name, cString value) throws Exception
    {
        String afterDecode = URLDecoder.decode(value.text, "UTF-8");
        request.queries_.put(name.text, afterDecode);
    }
    private static void f_setOnResponse (cHttpRequest request, cString method)
    {
        request.methodOnResponse_ = method.text;
    }
    private static void f_get (_BoriView boriview, cHttpRequest request)
    {
        HttpAsyncTask task = new HttpAsyncTask(boriview, request, GET);
        task.execute();
    }
    private static void f_post (_BoriView boriview, cHttpRequest request)
    {
        HttpAsyncTask task = new HttpAsyncTask(boriview, request, POST);
        task.execute();
    }

    private static class HttpAsyncTask extends AsyncTask<Void,Void,Response>
    {
        private _BoriView boriview_;
        private cHttpRequest request_;
        private int method_;
        private Exception e_;
        private String content_;

        HttpAsyncTask(_BoriView view, cHttpRequest request, int method)
        {
            boriview_ = view;
            request_ = request;
            method_ = method;
        }

        @Override
        protected Response doInBackground(Void... voids)
        {
            Response resp;
            try
            {
                Request request;
                if (method_ == GET)
                {
                    HttpUrl.Builder urlBuilder = HttpUrl.parse(request_.url_).newBuilder();
                    if (request_.queries_.size() > 0)
                    {
                        for (Map.Entry<String, String> entry : request_.queries_.entrySet())
                        {
                            String key = entry.getKey();
                            String value = entry.getValue();
                            urlBuilder.addQueryParameter(key, value);
                        }
                    }
                    String url = urlBuilder.build().toString();
                    request = new Request.Builder().url(url).build();
                }
                else // POST
                {
                    FormBody.Builder fb_builder = new FormBody.Builder();
                    if (request_.queries_.size() > 0)
                    {
                        for (Map.Entry<String, String> entry : request_.queries_.entrySet())
                        {
                            String key = entry.getKey();
                            String value = entry.getValue();
                            fb_builder.add(key, value);
                        }
                    }

                    RequestBody formBody = fb_builder.build();
                    request = new Request.Builder().url(request_.url_).post(formBody).build();
                }
                OkHttpClient client = new OkHttpClient();
                resp = client.newCall(request).execute();
                content_ = resp.body().string();
            }
            catch(Exception e)
            {
                e_ = e;
                resp = null;
            }
            return resp;
        }

        @Override
        protected void onPostExecute(Response response)
        {
            super.onPostExecute(response);

            if (response == null)
            {
                String msg;
                if (method_ == POST)
                    msg = "> HttpRequest.post()\n";
                else
                    msg = "> HttpRequest.get()\n";
                msg += (e_ != null) ? e_.getMessage() : "Unknown error";

                _Alert.showException(boriview_.bori, msg);
                return;
            }

            if (request_.methodOnResponse_ != null)
            {
                String method = request_.methodOnResponse_ + "(HttpResponse)";
                _ConList params = new _ConList();
                cHttpResponse httpresp = new cHttpResponse(response);
                httpresp.stringContent_ = content_;
                params.add(new _Container(httpresp));
                boriview_.call(method, params);
            }
        }
    }
}
