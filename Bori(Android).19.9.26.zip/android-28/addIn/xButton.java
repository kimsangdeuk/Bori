package com.sangdeuk.fragment;

import android.content.Context;
import android.support.v7.widget.AppCompatButton;
import android.util.AttributeSet;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xButton extends AppCompatButton
{
    private _BoriView boriview_;

    public xButton (Context context) { super(context); }
    public xButton (Context context, AttributeSet attrs) { super(context, attrs); }
    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setTextStyle(this, node);
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onClick"))
            {
                String methodOnClick = _Xml.getAttributeValue(node, "method");
                _Tag tag = _Tag.get(this);
                tag.setOnClick(methodOnClick);
            }
        }
    }
}

