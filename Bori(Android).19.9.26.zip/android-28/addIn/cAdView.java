package com.sangdeuk.toctoc;

import com.google.android.gms.ads.AdView;

class cAdView extends cControl
{
    cAdView()
    {
        super(cType.TC_ADVIEW);
    }
    cAdView(AdView adview)
    {
        super(cType.TC_ADVIEW);
        view = adview;
    }

}
