package bori.sangdeuk.db_memo;

import android.os.Bundle;

class cBundle extends cVar
{
    private Bundle bundle_;

    cBundle()
    {
        super(cType.TBUNDLE);
        bundle_ = new Bundle();
    }
    cBundle(Bundle bundle)
    {
        super(cType.TBUNDLE);
        bundle_ = bundle;
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cBundle)
        {
            cBundle bundle = (cBundle)var;
            bundle_ = bundle.bundle_;
        }
    }

    //-------------------------------------------------------------
    private static final int FNC_IS_NULL = 0,
            FNC_GET = 1, FNC_GET_BOOL = 2, FNC_GET_STR = 3, FNC_GET_INT = 4, FNC_GET_DOUBLE = 5,
            FNC_PUT = 6, FNC_PUT_BOOL = 7, FNC_PUT_STR = 8, FNC_PUT_INT = 9, FNC_PUT_DOUBLE = 10;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_IS_NULL:
                    methodName = "isNull";
                    f_isNull(ret, (cBundle)stack.get(ct - 1).var);
                    break;
                case FNC_GET:
                    methodName = "get";
                    f_get(ret, (cBundle)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_GET_BOOL:
                    methodName = "getBool";
                    f_getBool(ret, (cBundle)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_GET_STR:
                    methodName = "getString";
                    f_getString(ret, (cBundle)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_GET_INT:
                    methodName = "getInt";
                    f_getInt(ret, (cBundle)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_GET_DOUBLE:
                    methodName = "getDouble";
                    f_getDouble(ret, (cBundle)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_PUT:
                    methodName = "put";
                    f_put((cBundle)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, stack.get(ct - 1).var);
                    break;
                case FNC_PUT_BOOL:
                    methodName = "putBool";
                    f_putBool((cBundle)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cBool)stack.get(ct - 1).var);
                    break;
                case FNC_PUT_STR:
                    methodName = "putString";
                    f_putString((cBundle)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cString)stack.get(ct - 1).var);
                    break;
                case FNC_PUT_INT:
                    methodName = "putInt";
                    f_putInt((cBundle)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cInt)stack.get(ct - 1).var);
                    break;
                case FNC_PUT_DOUBLE:
                    methodName = "putDouble";
                    f_putDouble((cBundle)stack.get(ct - 3).var, (cString)stack.get(ct - 2).var, (cDouble)stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Bundle." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_isNull(_Container ret, cBundle bundle)
    {
        ret.var = new cBool(bundle.bundle_ == null);
    }
    private static void f_get(_Container ret, cBundle bundle, cString key) throws Exception
    {
        ret.var = _Bundle.getVarFromParcelable(bundle.bundle_.getParcelable(key.text));
    }
    private static void f_getBool(_Container ret, cBundle bundle, cString key)
    {
        ret.var = new cBool(bundle.bundle_.getBoolean(key.text));
    }
    private static void f_getString(_Container ret, cBundle bundle, cString key)
    {
        ret.var = new cString(bundle.bundle_.getString(key.text));
    }
    private static void f_getInt(_Container ret, cBundle bundle, cString key)
    {
        ret.var = new cInt(bundle.bundle_.getLong(key.text));
    }
    private static void f_getDouble(_Container ret, cBundle bundle, cString key)
    {
        ret.var = new cDouble(bundle.bundle_.getDouble(key.text));
    }
    private static void f_put(cBundle bundle, cString key, cVar var) throws Exception
    {
        bundle.bundle_.putParcelable(key.text, _Bundle.getParcelableFromVar(var));
    }
    private static void f_putBool(cBundle bundle, cString key, cBool value)
    {
        bundle.bundle_.putBoolean(key.text, value.isTrue());
    }
    private static void f_putString(cBundle bundle, cString key, cString value)
    {
        bundle.bundle_.putString(key.text, value.text);
    }
    private static void f_putInt(cBundle bundle, cString key, cInt value)
    {
        bundle.bundle_.putLong(key.text, value.value);
    }
    private static void f_putDouble(cBundle bundle, cString key, cDouble value)
    {
        bundle.bundle_.putDouble(key.text, value.value);
    }
}
