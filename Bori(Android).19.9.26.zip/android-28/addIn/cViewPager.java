package bori.sangdeuk.tablayout_viewpager;

class cViewPager extends cControl
{
    cViewPager()
    {
        super(cType.TC_VIEWPAGER);
    }
    cViewPager(xViewPager view0)
    {
        super(cType.TC_VIEWPAGER);
        view = view0;
    }

    xViewPager getViewPager()
    {
        return (xViewPager)view;
    }
    //-------------------------------------------------------------
    private static final int FNC_ADD = 0, FNC_SET_CUR_ITEM = 1, FNC_SET_CUR_ITEM2 = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_ADD:
                    methodName = "add";
                    f_add((cViewPager) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CUR_ITEM:
                    methodName = "setCurItem";
                    f_setCurItem((cViewPager) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CUR_ITEM2:
                    methodName = "setCurItem";
                    f_setCurItem2((cViewPager) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> ViewPager." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_add(cViewPager pager, cString viewName)
    {
        ((xViewPager)pager.view).addView(viewName.text);
    }
    private static void f_setCurItem(cViewPager pager, cString viewName)
    {
        ((xViewPager)pager.view).setCurrent(viewName.text);
    }
    private static void f_setCurItem2(cViewPager pager, cInt index)
    {
        ((xViewPager)pager.view).setCurrent((int)index.value - _Env.iBase);
    }
}
