package com.sangdeuk.fragment1;

import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.RectF;

class cCanvas extends cVar
{
    private Canvas canvas_;

    cCanvas()
    {
        super(cType.TCANVAS);
        canvas_ = null;
    }
    cCanvas(Canvas canvas)
    {
        super(cType.TCANVAS);
        canvas_ = canvas;
    }
    void set(Canvas canvas)
    {
        canvas_ = canvas;
    }

    private static final int FNC_DRAW_COLOR = 0, FNC_DRAW_ROUNDRECT = 1, FNC_DRAW_ROUNDRECT2 = 2, FNC_DRAW_TEXT = 3, FNC_DRAW_TEXT2 = 4,
            FNC_DRAW_LINE = 5,
            FNC_DRAW_BITMAP = 6, FNC_DRAW_BITMAP_P = 7, FNC_DRAW_BITMAP_SIZE = 8, FNC_DRAW_BITMAP_SIZE_P = 9,
            FNC_DRAW_RECT = 10, FNC_DRAW_OVAL = 11, FNC_DRAW_OVAL2 = 12;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_DRAW_COLOR:
                    methodName = "drawColor";
                    f_drawColor((cCanvas) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_ROUNDRECT:
                    methodName = "drawRoundRect";
                    f_drawRoundRect((cCanvas) stack.get(ct - 8).var,
                            (cDouble) stack.get(ct - 7).var, (cDouble) stack.get(ct - 6).var,
                            (cDouble) stack.get(ct - 5).var, (cDouble) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_ROUNDRECT2:
                    methodName = "drawRoundRect";
                    f_drawRoundRect2((cCanvas) stack.get(ct - 5).var,
                            (cRectD) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_TEXT:
                    methodName = "drawText";
                    f_drawText((cCanvas) stack.get(ct - 5).var,
                            (cString) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_TEXT2:
                    methodName = "drawText";
                    f_drawText2((cCanvas) stack.get(ct - 4).var,
                            (cString) stack.get(ct - 3).var, (cPointD) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_LINE:
                    methodName = "drawLine";
                    f_drawLine((cCanvas) stack.get(ct - 6).var,
                            (cDouble) stack.get(ct - 5).var, (cDouble) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_BITMAP:
                    methodName = "drawBitmap";
                    f_drawBitmap((cCanvas) stack.get(ct - 4).var,
                            (cBitmap) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_BITMAP_P:
                    methodName = "drawBitmap";
                    f_drawBitmapP((cCanvas) stack.get(ct - 5).var,
                            (cBitmap) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_BITMAP_SIZE:
                    methodName = "drawBitmap";
                    f_drawBitmapSize((cCanvas) stack.get(ct - 6).var,
                            (cBitmap) stack.get(ct - 5).var,
                            (cDouble) stack.get(ct - 4).var, (cDouble) stack.get(ct - 3).var,
                            (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_BITMAP_SIZE_P:
                    methodName = "drawBitmap";
                    f_drawBitmapSizeP((cCanvas) stack.get(ct - 7).var,
                            (cBitmap) stack.get(ct - 6).var,
                            (cDouble) stack.get(ct - 5).var, (cDouble) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_RECT:
                    methodName = "drawRect";
                    f_drawRect((cCanvas) stack.get(ct - 6).var,
                            (cDouble) stack.get(ct - 5).var, (cDouble) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_OVAL:
                    methodName = "drawOval";
                    f_drawOval((cCanvas) stack.get(ct - 6).var,
                            (cDouble) stack.get(ct - 5).var, (cDouble) stack.get(ct - 4).var,
                            (cDouble) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                case FNC_DRAW_OVAL2:
                    methodName = "drawOval";
                    f_drawOval2((cCanvas) stack.get(ct - 3).var,
                            (cRectD) stack.get(ct - 2).var,
                            (cPaint) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Canvas." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_drawColor(cCanvas canvas, cColor color)
    {
        canvas.canvas_.drawColor(color.intValue());
    }
    private static void f_drawRoundRect(cCanvas canvas,
                                        cDouble left, cDouble top, cDouble right, cDouble bottom,
                                        cDouble rx, cDouble ry, cPaint paint)
    {
        canvas.canvas_.drawRoundRect(
                new RectF((float)left.value, (float)top.value, (float)right.value, (float)bottom.value),
                (float)rx.value, (float)ry.value,
                paint.paint_);
    }
    private static void f_drawRoundRect2(cCanvas canvas, cRectD rect, cDouble rx, cDouble ry, cPaint paint)
    {
        canvas.canvas_.drawRoundRect(rect.getRectF(), (float)rx.value, (float)ry.value, paint.paint_);
    }
    private static void f_drawText(cCanvas canvas, cString text, cDouble x, cDouble y, cPaint paint)
    {
        canvas.canvas_.drawText(text.text, (float)x.value, (float)y.value, paint.paint_);
    }
    private static void f_drawText2(cCanvas canvas, cString text, cPointD point, cPaint paint)
    {
        PointF pt = point.getPointF();
        canvas.canvas_.drawText(text.text, pt.x, pt.y, paint.paint_);
    }
    private static void f_drawLine(cCanvas canvas,
                                        cDouble x1, cDouble y1, cDouble x2, cDouble y2,
                                        cPaint paint)
    {
        canvas.canvas_.drawLine((float)x1.value, (float)y1.value, (float)x2.value, (float)y2.value,
                paint.paint_);
    }
    private static void f_drawBitmap(cCanvas canvas, cBitmap b, cDouble x, cDouble y)
    {
        if (! b.isEmpty())
            canvas.canvas_.drawBitmap(b.bmp_, (float)x.value, (float)y.value, null);
    }
    private static void f_drawBitmapP(cCanvas canvas, cBitmap b, cDouble x, cDouble y, cPaint p)
    {
        if (! b.isEmpty())
            canvas.canvas_.drawBitmap(b.bmp_, (float)x.value, (float)y.value, p.paint_);
    }
    private static void f_drawBitmapSize(cCanvas canvas, cBitmap b, cDouble x, cDouble y, cDouble cx, cDouble cy)
    {
        if (! b.isEmpty())
        {
            RectF rc = new RectF((float)x.value, (float)y.value, (float)(x.value + cx. value), (float)(y.value + cy.value));
            canvas.canvas_.drawBitmap(b.bmp_, null, rc, null);
        }
    }
    private static void f_drawBitmapSizeP(cCanvas canvas, cBitmap b, cDouble x, cDouble y, cDouble cx, cDouble cy, cPaint p)
    {
        if (! b.isEmpty())
        {
            RectF rc = new RectF((float)x.value, (float)y.value, (float)(x.value + cx. value), (float)(y.value + cy.value));
            canvas.canvas_.drawBitmap(b.bmp_, null, rc, p.paint_);
        }
    }
    private static void f_drawRect(cCanvas canvas,
                                        cDouble left, cDouble top, cDouble right, cDouble bottom,
                                        cPaint paint)
    {
        canvas.canvas_.drawRect(
                new RectF((float)left.value, (float)top.value, (float)right.value, (float)bottom.value),
                paint.paint_);
    }
    private static void f_drawOval(cCanvas canvas,
                                        cDouble left, cDouble top, cDouble right, cDouble bottom,
                                        cPaint paint)
    {
        canvas.canvas_.drawOval(
                new RectF((float)left.value, (float)top.value, (float)right.value, (float)bottom.value),
                paint.paint_);
    }
    private static void f_drawOval2(cCanvas canvas, cRectD rect, cPaint paint)
    {
        canvas.canvas_.drawOval(rect.getRectF(), paint.paint_);
    }
}
