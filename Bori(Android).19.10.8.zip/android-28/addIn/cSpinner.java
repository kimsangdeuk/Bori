package bori.sangdeuk.spinner;

class cSpinner extends cControl
{
    cSpinner()
    {
        super(cType.TC_SPINNER);
    }
    cSpinner(xSpinner view_)
    {
        super(cType.TC_SPINNER);
        view = view_;
    }

    //----------------------------------------------------------------------------
    private static final int FNC_SET = 0, FNC_GET_TEXT = 1, FNC_SET_SELECTION = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
        int ct = stack.size();
        switch(nfunc)
        {
            case FNC_SET:
                methodName = "set";
                f_set((cSpinner)stack.get(ct-2).var, (cStrs)stack.get(ct-1).var);
                break;
            case FNC_GET_TEXT:
                methodName = "getText";
                f_getText(ret, (cSpinner)stack.get(ct-1).var);
                break;
            case FNC_SET_SELECTION:
                methodName = "setSelection";
                f_setSelection((cSpinner)stack.get(ct-2).var, (cInt)stack.get(ct-1).var);
                break;
            default:
                throw new Exception("Unsupported class method:" + nfunc);
        }
        }
        catch(Exception e)
        {
            throw new Exception("> Spinner." + methodName + "\n" + e.getMessage());
        }
    }
    private static void f_set(cSpinner spinner, cStrs items)
    {
        ((xSpinner)spinner.view).setItems(items.getStringArray());
    }
    private static void f_getText(_Container ret, cSpinner spinner)
    {
        String text = ((xSpinner)spinner.view).getText();
        ret.var = new cString(text);
    }
    private static void f_setSelection(cSpinner spinner, cInt index)
    {
        ((xSpinner)spinner.view).setSelection((int)index.value - _Env.iBase);
    }
}
