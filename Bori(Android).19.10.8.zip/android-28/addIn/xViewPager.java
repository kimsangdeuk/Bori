package bori.sangdeuk.db_memo;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xViewPager extends ViewPager
{
    private _BoriView boriview_;
    private MyPagerAdapter adapter_;
    private ArrayList<_Fragment> list_;
    private String methodOnPageSelected = null;
    private xTabLayout tabsSynced_ = null;

    xViewPager (Context context) { super(context); }
    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        list_ = new ArrayList<>();
        adapter_ = new MyPagerAdapter(boriview.bori.getSupportFragmentManager());
        setAdapter(adapter_);

        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));

        addOnPageChangeListener(new OnPageChangeListener()
        {
            @Override
            public void onPageScrolled(int i, float v, int i1)
            {

            }

            @Override
            public void onPageSelected(int i)
            {
                if (tabsSynced_ != null)
                {
                    tabsSynced_.selectTabIndex(i);
                }
                if (methodOnPageSelected != null)
                {
                    _ConList params = new _ConList();
                    params.add(new _Container(new cInt(i + _Env.iBase)));
                    boriview_.call(methodOnPageSelected, params);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i)
            {

            }
        });
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            if (name.equals("onPageSelected"))
                methodOnPageSelected = method;
        }
    }

    void addView(String viewName)
    {
        _Fragment fragment = _Fragment.newInstance(viewName, boriview_);
        list_.add(fragment);
        adapter_.notifyDataSetChanged();
    }

    private int getIndex(String viewName)
    {
        for (int i = 0, ct = list_.size(); i < ct; i++)
        {
            _Fragment f = list_.get(i);
            if (f.viewName_.equals(viewName))
                return i;
        }
        return -1;
    }
    void setCurrent(String viewName)
    {
        int index = getIndex(viewName);
        if (index < 0)
        {
            _Alert.showException(boriview_.bori, "Can not find '" + viewName + "'");
            return;
        }
        if (getCurrentItem() != index)
            setCurrentItem(index);
    }
    void setCurrent(int index)
    {
        if (index < 0 || index >= list_.size())
        {
            _Alert.showException(boriview_.bori,
                    "The index is out of bounds.\nCount: " + list_.size()
                            + ", Index: " + (index + _Env.iBase));
            return;
        }
        if (getCurrentItem() != index)
            setCurrentItem(index);
    }

    void syncWithTabs (xTabLayout tabs)
    {
        tabsSynced_ = tabs;
    }

    class MyPagerAdapter extends FragmentPagerAdapter
    {
        MyPagerAdapter(FragmentManager fm)
        {
            super(fm);
        }

        @Override
        public Fragment getItem(int i)
        {
            return list_.get(i);
        }

        @Override
        public int getCount()
        {
            return list_.size();
        }
    }
}

