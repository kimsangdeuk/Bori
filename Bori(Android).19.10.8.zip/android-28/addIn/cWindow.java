package bori.sangdeuk.db_memo;

import android.content.Context;
import android.view.Display;
import android.view.Surface;
import android.view.Window;
import android.view.WindowManager;

class cWindow extends cVar
{
    cWindow()
    {
        super(cType.TWINDOW);
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_STATUSBAR_COLOR = 0, FNC_IS_LANDSCAPE = 1, FNC_IS_PORTRAIT = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_STATUSBAR_COLOR:
                    methodName = "setStatusBarColor";
                    f_setStatusBarColor(boriview, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_IS_LANDSCAPE:
                    methodName = "isLandscape";
                    f_isLandscape(boriview, ret);
                    break;
                case FNC_IS_PORTRAIT:
                    methodName = "isPortrait";
                    f_isPortrait(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Window." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setStatusBarColor(_BoriView boriview, cColor color)
    {
        boriview.bori.setStatusBarColor(color.intValue());
    }
    private static boolean isLandscape(_BoriView boriview)
    {
        Display display = ((WindowManager) boriview.bori.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        int rotation = display.getRotation();
        return (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270);
    }
    private static void f_isLandscape(_BoriView boriview, _Container ret)
    {
        ret.var = new cBool(isLandscape(boriview));
    }
    private static void f_isPortrait(_BoriView boriview, _Container ret)
    {
        ret.var = new cBool(!isLandscape(boriview));
    }
}
