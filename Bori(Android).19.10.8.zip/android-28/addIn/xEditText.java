package bori.sangdeuk.file_memo;

import android.content.Context;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.ScrollingMovementMethod;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;

import org.w3c.dom.Node;

import java.util.ArrayList;

public class xEditText extends AppCompatEditText
{
    private _BoriView boriview_;
    private String methodAction_ = null;
    private String methodTextChanged_ = null;
    private int lineLimit_ = 0;
    private int lastCursorPosition_ = 0;
    private String lastText_ = "";

    public xEditText (Context context)
    {
        super(context);
    }
    public xEditText (Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }
    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));

        setOnEditorActionListener(new TextView.OnEditorActionListener()
        {
            @Override
            public boolean onEditorAction(TextView v, int i, KeyEvent keyEvent)
            {
                return callEditorAction(v, i);
            }
        });
        addTextChangedListener(new TextWatcher()
        {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
                lastCursorPosition_ = getSelectionStart();
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable s)
            {
                if (lineLimit_ > 0)
                {
                    removeTextChangedListener(this);

                    if (getLineCount() > lineLimit_)
                    {
                        setText(lastText_);
                        setSelection(lastCursorPosition_);
                    }
                    else
                        lastText_ = getText().toString();

                    addTextChangedListener(this);
                }
                callTextChanged(s.toString());
            }
        } );
    }

    private boolean callEditorAction(TextView v, int i)
    {
        if (methodAction_ == null)
            return false;

        if (i == EditorInfo.IME_ACTION_DONE
                || i == EditorInfo.IME_ACTION_SEARCH)
        {
            InputMethodManager imm = (InputMethodManager) v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        }

        _ConList params = new _ConList();
        params.add(new _Container(new cEditText((xEditText) v)));
        params.add(new _Container(new cString(getImeString(i))));
        boriview_.call(methodAction_, params);
        return true;
    }

    private void callTextChanged(String text)
    {
        if (methodTextChanged_ == null)
            return;

        _ConList params = new _ConList();
        params.add(new _Container(new cEditText(this)));
        params.add(new _Container(new cString(text)));
        boriview_.call(methodTextChanged_, params);
    }

    void limitLines(int lines)
    {
        lineLimit_ = lines;
        setTextLimit(getText().toString());
    }

    void setTextLimit (String text)
    {
        String[] strParts = _Util.splitLines(text);
        if (lineLimit_ > 0 && strParts.length > lineLimit_)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < lineLimit_; i++)
            {
                if (i > 0)
                    sb.append("\n");
                sb.append(strParts[i]);
            }
            text = sb.toString();
        }
        setText(text);
    }

    private final String[] simeoptions = { "actionDone", "actionGo", "actionNext",
            "actionPrevious", "actionSearch",
            "actionSend" };
    private final int[] nimeoptions = { EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_GO,
            EditorInfo.IME_ACTION_NEXT, EditorInfo.IME_ACTION_PREVIOUS,
            EditorInfo.IME_ACTION_SEARCH, EditorInfo.IME_ACTION_SEND
    };

    private String getImeString(int option)
    {
        for (int i = 0, ct = nimeoptions.length; i < ct; i++)
        {
            if (nimeoptions[i] == option)
                return simeoptions[i];
        }
        return "";
    }
    private static final String[] sinput = { "date","datetime","number","numberDecimal","numberPassword",
            "numberSigned","numberSignedDecimal", "phone","text","textAutoComplete","textAutoCorrect","textCapCharacters",
            "textCapSentences","textCapWords","textEmailAddress","textEmailSubject","textFilter",
            "textImeMultiLine","textLongMessage","textMultiLine","textNoSuggestions","textPassword",
            "textPersonName","textPhonetic","textPostalAddress","textShortMessage","textUri",
            "textVisiblePassword","textWebEditText","textWebEmailAddress","textWebPassword","time"
            };
    private static final int[] ninput = {
            InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_DATE,
            InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_NORMAL,
            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_NORMAL,
            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL,
            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD,
            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED,
            InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED,
            InputType.TYPE_CLASS_PHONE,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL,
            InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE,
            InputType.TYPE_TEXT_FLAG_AUTO_CORRECT,
            InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS,
            InputType.TYPE_TEXT_FLAG_CAP_SENTENCES,
            InputType.TYPE_TEXT_FLAG_CAP_WORDS,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_FILTER,
            InputType.TYPE_TEXT_FLAG_IME_MULTI_LINE,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_LONG_MESSAGE,
            InputType.TYPE_TEXT_FLAG_MULTI_LINE,
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PERSON_NAME,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PHONETIC,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_CLASS_DATETIME | InputType.TYPE_DATETIME_VARIATION_TIME
    };

    private void setStyle(Node node)
    {
        if (null == node)
            return;

        _Xml.setTextStyle(this, node);
        _Xml.setViewStyle(this, node);

        String singleLine = _Xml.getAttributeValue(node, "singleLine");
        boolean multiline = ! singleLine.equals("true");
        if (multiline)
        {
            setVerticalScrollBarEnabled(true);
            setMovementMethod(ScrollingMovementMethod.getInstance());
            setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
        }

        // imeOptions
        String sImeOptions = _Xml.getAttributeValue(node, "imeOptions");
        int imeOption = 0;
        for (int i = 0, ct = simeoptions.length; i < ct; i++)
        {
            if (simeoptions[i].equals(sImeOptions))
            {
                imeOption = nimeoptions[i];
                break;
            }
        }
        if (multiline)
            imeOption |= EditorInfo.IME_FLAG_NO_ENTER_ACTION;
        if (imeOption != 0)
            setImeOptions(imeOption);

        // input type
        String sInputType = _Xml.getAttributeValue(node, "inputType");
        int inputType = InputType.TYPE_CLASS_TEXT;
        for (int i = 0, ct = sinput.length; i < ct; i++)
        {
            if (sinput[i].equals(sInputType))
            {
                inputType = ninput[i];
                break;
            }
        }
        if (multiline)
            inputType |= InputType.TYPE_TEXT_FLAG_MULTI_LINE;
//        setRawInputType(inputType);
        setInputType(inputType);

        // hint
        String hint = _Xml.getAttributeValue(node, "hint");
        setHint(hint);
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onEditorAction"))
                methodAction_ = _Xml.getAttributeValue(node, "method");
            if (name.equals("onTextChanged"))
                methodTextChanged_ = _Xml.getAttributeValue(node, "method");
        }
    }
}

