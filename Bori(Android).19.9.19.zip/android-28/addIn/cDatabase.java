package bori.sangdeuk.db;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

class cDatabase extends cVar
{
    private SQLiteDatabase db_;

    cDatabase()
    {
        super(cType.TDATABASE);
        db_ = null;
    }
    cDatabase(SQLiteDatabase db)
    {
        super(cType.TDATABASE);
        db_ = db;
    }

    @Override
    public void copyFrom(cVar var)
    {
        db_ = null;
        if (var instanceof cDatabase)
            db_ = ((cDatabase)var).db_;
    }

    private void checkNull() throws Exception
    {
        if (db_ == null)
            throw new Exception("Database for this instance is not initilized.");
    }
    private static cRset readResult(Cursor cursor) throws Exception
    {
        if (cursor == null)
            throw new Exception("Null result.");
        if (!cursor.moveToFirst())
            return new cRset();

        int ctCol = cursor.getColumnCount();
        String[] names = cursor.getColumnNames();
        int[] types = new int[ctCol];
        for (int i = 0; i < ctCol; i++)
        {
            int type = cursor.getType(i);
            switch (type)
            {
                case Cursor.FIELD_TYPE_STRING:
                    types[i] = cType.TSTRING;
                    break;
                case Cursor.FIELD_TYPE_INTEGER:
                    types[i] = cType.TBIGINT;
                    break;
                case Cursor.FIELD_TYPE_FLOAT:
                    types[i] = cType.TDOUBLE;
                    break;
                default:
                    throw new Exception("Unsupported type found");
            }
        }

        cRset rset = new cRset(ctCol, names, types);
        do
        {
            int row = rset.appendRow();
            for (int i = 0; i < ctCol; i++)
            {
                boolean NA = (Cursor.FIELD_TYPE_NULL == cursor.getType(i));
                int type = types[i];
                switch (type)
                {
                    case cType.TSTRING:
                        rset.updateString(row, names[i], NA ? "" : cursor.getString(i));
                        break;
                    case cType.TBIGINT:
                        rset.updateInt(row, names[i], NA ? cInt.NULL : cursor.getInt(i));
                        break;
                    case cType.TDOUBLE:
                        rset.updateDouble(row, names[i], NA ? cDouble.NULL : cursor.getDouble(i));
                        break;
                    default:
                        throw new Exception("Unsupported type");
                }
            }
        } while (cursor.moveToNext());
        return rset;
    }

    //---------------------------------------------------------------------
    private static final int FNC_EXEC_SQL = 0, FNC_QUERY = 1, FNC_GET_VERSION = 2, FNC_SET_VERSION = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_EXEC_SQL:
                    methodName = "execSQL";
                    f_execSQL((cDatabase) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_QUERY:
                    methodName = "query";
                    f_query(ret, (cDatabase) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_VERSION:
                    methodName = "getVersion";
                    f_getVersion(ret, (cDatabase) stack.get(ct - 1).var);
                    break;
                case FNC_SET_VERSION:
                    methodName = "setVersion";
                    f_setVersion((cDatabase) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> SQLite." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_execSQL(cDatabase db, cString sql) throws Exception
    {
        db.checkNull();
        db.db_.execSQL(sql.text);
    }
    private static void f_query(_Container ret, cDatabase db, cString sql) throws Exception
    {
        db.checkNull();
        Cursor cursor = db.db_.rawQuery(sql.text, null);
        ret.var = readResult(cursor);
        cursor.close();
    }
    private static void f_getVersion(_Container ret, cDatabase db) throws Exception
    {
        db.checkNull();
        ret.var = new cInt(db.db_.getVersion());
    }
    private static void f_setVersion(cDatabase db, cInt version) throws Exception
    {
        db.checkNull();
        db.db_.setVersion((int)version.value);
    }
}
