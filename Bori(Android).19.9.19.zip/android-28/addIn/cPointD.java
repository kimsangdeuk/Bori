package com.sangdeuk.fragment1;

import android.graphics.PointF;

class cPointD extends cVar
{
    private cDouble x_;
    private cDouble y_;

    cPointD()
    {
        super(cType.TPOINTD);
        x_ = new cDouble(0.0d);
        y_ = new cDouble(0.0d);
    }
    cPointD(double x, double y)
    {
        super(cType.TPOINTD);
        set(x, y);
    }
    void set(double x, double y)
    {
        x_ = new cDouble(x);
        y_ = new cDouble(y);
    }

    PointF getPointF()
    {
        return new PointF((float)x_.value, (float)y_.value);
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cPointD)
        {
            cPointD src = (cPointD)var;
            x_.value = src.x_.value;
            y_.value = src.y_.value;
        }
    }
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        sb.append("{ x:");
        sb.append(x_.value);
        sb.append(", y:");
        sb.append(y_.value);
        sb.append(" }");
        return new String(sb);
    }

    //-----------------------------------------------------------
    private static final int FLD_X = 0, FLD_Y = 1;
    static void getVar(int n, _Container ret, _Container con)
    {
        cPointD p = (cPointD)con.var;
        switch(n)
        {
            case FLD_X: ret.var = p.x_; break;
            case FLD_Y: ret.var = p.y_; break;
        }
    }

    //-----------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_NEW2 = 1, FNC_SET = 2, FNC_SET2 = 3, FNC_OFFSET = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_NEW2:
                    methodName = "new";
                    f_new2(ret, (cPointD) stack.get(ct - 1).var);
                    break;
                case FNC_SET:
                    methodName = "set";
                    f_set((cPointD) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_SET2:
                    methodName = "set";
                    f_set2((cPointD) stack.get(ct - 2).var, (cPointD) stack.get(ct - 1).var);
                    break;
                case FNC_OFFSET:
                    methodName = "offset";
                    f_offset((cPointD) stack.get(ct - 3).var, (cDouble) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> PointD." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cDouble x, cDouble y)
    {
        ret.var = new cPointD(x.value, y.value);
    }
    private static void f_new2(_Container ret, cPointD pointFrom)
    {
        ret.var = new cPointD(pointFrom.x_.value, pointFrom.y_.value);
    }
    private static void f_set(cPointD point, cDouble x, cDouble y)
    {
        point.set(x.value, y.value);
    }
    private static void f_set2(cPointD point, cPointD pointFrom)
    {
        point.set(pointFrom.x_.value, pointFrom.y_.value);
    }
    private static void f_offset(cPointD point, cDouble dx, cDouble dy)
    {
        point.x_.value += dx.value;
        point.y_.value += dy.value;
    }
}
