package bori.sangdeuk.test;

import android.content.Context;
import android.support.v7.widget.AppCompatTextView;
import android.text.method.ScrollingMovementMethod;
import android.util.AttributeSet;

import org.w3c.dom.Node;

import java.util.ArrayList;

class xTextView extends AppCompatTextView
{
    private _BoriView boriview_;

    public xTextView (Context context) { super(context); }
    public xTextView (Context context, AttributeSet attrs) { super(context, attrs); }

    void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        _Xml.setViewStyle(this, node);
        _Xml.setTextStyle(this, node);

        String singleLine = _Xml.getAttributeValue(node, "singleLine");
        if (! singleLine.equals("true"))
        {
            setVerticalScrollBarEnabled(true);
            setHorizontallyScrolling(false);
            setMovementMethod(new ScrollingMovementMethod());
        }
    }
    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            switch(name)
            {
                case "onClick": _Tag.get(this).setOnClick(method); break;
                case "onLongClick": _Tag.get(this).setOnLongClick(method); break;
            }
        }
    }
}
