package bori.android.test;

public class _Container
{
    cVar var;

    _Container()
    {
        var = new cVar();
    }
    _Container(cVar var0)
    {
        var = var0;
    }
    _Container(int type) { var = new cVar(type); }
}
