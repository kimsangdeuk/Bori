package bori.sangdeuk.db_memo;

import android.content.Context;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.util.AttributeSet;
import android.view.View;

import org.w3c.dom.Node;

import java.util.ArrayList;

public class xFloatingActionButton extends FloatingActionButton
{
    private _BoriView boriview_;

    public xFloatingActionButton (Context context) { super(context); }
    public xFloatingActionButton (Context context, AttributeSet attrs) { super(context, attrs); }
    public xFloatingActionButton (Context context, AttributeSet attrs, int defStyleAttr) { super(context, attrs, defStyleAttr); }

    public void init(_BoriView boriview, Node node, boolean asMain)
    {
        boriview_ = boriview;
        setStyle(_Xml.getChildElement(node, "style"));
        if (asMain)
            setEvent(_Xml.getChildList(node, "event"));
    }

    private void setStyle(Node node)
    {
        if (null == node)
            return;
        String text;
        text = _Xml.getAttributeValue(node, "backColor");
        if (! text.isEmpty())
            setButtonColor(Color.parseColor(text));

        text = _Xml.getAttributeValue(node, "hidden");
        if (text.equals("true"))
            hide();

        text = _Xml.getAttributeValue(node, "image");
        if (!text.isEmpty())
            setImageDrawable(_Util.getDrawable(boriview_.bori, text));
    }

    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            if (name.equals("onClick"))
            {
                String methodOnClick = _Xml.getAttributeValue(node, "method");
                _Tag.get(this).setOnClick(methodOnClick);
            }
        }
    }

    void setButtonColor(int color)
    {
        setBackgroundTintList(_Util.getColorStateList(color, color));
    }
}
