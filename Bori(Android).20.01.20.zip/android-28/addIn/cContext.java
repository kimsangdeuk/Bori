package bori.example.whereru;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PermissionInfo;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

class cContext extends cVar
{
    cContext()
    {
        super(cType.TCONTEXT);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_FILES_DIR = 0, FNC_GET_EXTERNAL_FILES_DIR = 1, FNC_GET_EXTERNAL_FILES_DIR_TYPE = 2,
            FNC_OPEN_DATABASE = 3, FNC_GET_PACKAGE_NAME = 4, FNC_GET_CONTENT_RESOLVER = 5,
            FNC_REQUEST_PERMISSIOM = 6, FNC_REQUEST_ALL_PERMISSIONS = 7;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getFilesDir(boriview, ret);
                    break;
                case FNC_GET_EXTERNAL_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getExternalFilesDir(boriview, ret);
                    break;
                case FNC_GET_EXTERNAL_FILES_DIR_TYPE:
                    methodName = "getFilesDir";
                    f_getExternalFilesDirWithType(boriview, ret, (cString)stack.get(ct-1).var);
                    break;
                case FNC_OPEN_DATABASE:
                    methodName = "openDatabase";
                    f_openDatabase(boriview, ret);
                    break;
                case FNC_GET_PACKAGE_NAME:
                    methodName = "getPackageName";
                    f_getPackageName(boriview, ret);
                    break;
                case FNC_GET_CONTENT_RESOLVER:
                    methodName = "getContentResolver";
                    f_getContentResolver(boriview, ret);
                    break;
                case FNC_REQUEST_PERMISSIOM:
                    methodName = "requestPermission";
                    f_requestPermission(boriview, (cString)stack.get(ct-2).var, (cString)stack.get(ct-1).var);
                    break;
                case FNC_REQUEST_ALL_PERMISSIONS:
                    methodName = "requestAllPermissions";
                    f_requestAllPermissions(boriview);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Context." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getFilesDir());
    }
    private static void f_getExternalFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getExternalFilesDir(null));
    }
    private static void f_getExternalFilesDirWithType (_BoriView boriview, _Container ret, cString type)
    {
        ret.var = new cFile(boriview.bori.getExternalFilesDir(type.text.isEmpty() ? null : type.text));
    }
    private static void f_openDatabase (_BoriView boriview, _Container ret)
    {
        SQLiteDatabase db = boriview.bori.openOrCreateDatabase(boriview.bori.getPackageName(), MODE_PRIVATE, null);
        ret.var = new cSQLite(db);
    }
    private static void f_getPackageName (_BoriView boriview, _Container ret)
    {
        ret.var = new cString(boriview.bori.getPackageName());
    }
    private static void f_getContentResolver (_BoriView boriview, _Container ret)
    {
        ret.var = new cContentResolver(boriview.bori.getContentResolver());
    }

    @SuppressWarnings("deprecation") // guess a mistake of Android Studio - protectionLevel in PermissionInfo has been deprecated
    private static boolean needDangerousPermission(Context context, String permission) throws Exception
    {
        PermissionInfo pi = context.getPackageManager().getPermissionInfo(permission, PackageManager.GET_META_DATA);
        if(pi.protectionLevel == PermissionInfo.PROTECTION_DANGEROUS)
        {
            int check = ContextCompat.checkSelfPermission(context, permission);
            if (check != PackageManager.PERMISSION_GRANTED)
                return true;
        }
        return false;

    }
    private static void f_requestPermission (_BoriView boriview, cString permission, cString funcName) throws Exception
    {
        String per;
        if (permission.text.startsWith("android.permission."))
            per = permission.text;
        else
            per = "android.permission." + permission.text;

        PackageInfo info = boriview.bori.getPackageManager().getPackageInfo(boriview.bori.getPackageName(), PackageManager.GET_PERMISSIONS);
        String[] permissions = info.requestedPermissions;
        boolean found = false;
        for (String s : permissions)
        {
            if (s.equals(per))
            {
                found = true;
                break;
            }
        }
        if (! found)
            throw new Exception("Undeclared permission name in manifest.xml");

        if (! needDangerousPermission(boriview.bori, per))
        {
            boriview.call(funcName.text + "()");
            return;
        }

        boriview.requestPermission(per, funcName.text);
    }

    private static void f_requestAllPermissions (@NonNull _BoriView boriview) throws Exception
    {
        PackageManager pm = boriview.bori.getPackageManager();
        PackageInfo info = pm.getPackageInfo(boriview.bori.getPackageName(), PackageManager.GET_PERMISSIONS);
        String[] permissions = info.requestedPermissions;
        if (permissions == null)
            return;
        ArrayList<String> targetList = new ArrayList<>();
        for (String s : permissions)
        {
            if (needDangerousPermission(boriview.bori, s))
                targetList.add(s);
        }

        if (targetList.size() > 0)
        {
            String[] targets = new String[targetList.size()];
            targetList.toArray(targets);
            ActivityCompat.requestPermissions(boriview.bori, targets, 100);
        }
    }
}
