package bori.sangdeuk.db_memo;

import android.net.Uri;

import com.bumptech.glide.Glide;

class cImageView extends cControl
{
    cImageView()
    {
        super(cType.TC_IMAGE);
    }
    cImageView(int type0)
    {
        super(type0);
    }
    cImageView(xImageView view_)
    {
        super(cType.TC_IMAGE);
        view = view_;
    }

    //---------------------------------------------------------------------
    private static final int FNC_LOAD_ASSET = 0, FNC_LOAD_DRAWABLE = 1, FNC_CLEAR = 2,
            FNC_SET_IMAGE_URI = 3, FNC_SET_IMAGE_BITMAP = 4, FNC_SET_IMAGE_DRAWABLE = 5,
            FNC_SET_SCALE_TYPE = 6;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_LOAD_ASSET:
                    f_loadAsset(boriview, (cImageView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_LOAD_DRAWABLE:
                    f_loadDrawable(boriview, (cImageView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_CLEAR:
                    f_clear((cImageView) stack.get(ct - 1).var);
                    break;
                case FNC_SET_IMAGE_URI:
                    f_setImageURI(boriview, (cImageView) stack.get(ct - 2).var, (cUri) stack.get(ct - 1).var);
                    break;
                case FNC_SET_IMAGE_BITMAP:
                    f_setImageBitmap((cImageView) stack.get(ct - 2).var, (cBitmap) stack.get(ct - 1).var);
                    break;
                case FNC_SET_IMAGE_DRAWABLE:
                    methodName = "setImageDrawable";
                    f_setImageDrawable((cImageView)stack.get(ct-2).var, (cDrawable)stack.get(ct-1).var);
                    break;
                case FNC_SET_SCALE_TYPE:
                    f_setScaleType((cImageView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> ImageView." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_loadAsset(_BoriView boriview, cImageView imageView, cString fileName)
    {
        Uri uri = Uri.parse("file:///android_asset/" + fileName);
        Glide.with(boriview.bori).load(uri).into((xImageView)imageView.view);
    }

    private static void f_loadDrawable(_BoriView boriview, cImageView imageView, cString name)
    {
        ((xImageView)imageView.view).setImageDrawable(_Util.getDrawable(boriview.bori, name.text));
    }

    private static void f_clear(cImageView imageView)
    {
        ((xImageView)imageView.view).setImageDrawable(null);
    }
    private static void f_setImageURI(_BoriView boriview, cImageView imageView, cUri uri)
    {
        Glide.with(boriview.bori).load(uri.uri_).into((xImageView)imageView.view);
    }
    private static void f_setImageBitmap(cImageView imageView, cBitmap bmp)
    {
        ((xImageView)imageView.view).setImageBitmap(bmp.bmp_);
    }
    private static void f_setImageDrawable(cImageView imageView, cDrawable drawable)
    {
        ((xImageView)imageView.view).setImageDrawable(drawable.drawable_);
    }
    private static void f_setScaleType(cImageView imageView, cString scaleType) throws Exception
    {
        ((xImageView)imageView.view).setScaleType(scaleType.text);
    }
}
