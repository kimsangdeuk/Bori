package bori.example.actiongetimage;

import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.MediaStore;

import java.io.File;

class cContentResolver extends cVar
{
    private ContentResolver resolver_;

    cContentResolver()
    {
        super(cType.TCONTENTRESOLVER);
    }
    cContentResolver(ContentResolver resolver)
    {
        super(cType.TCONTENTRESOLVER);
        resolver_ = resolver;
    }
    @Override
    public void copyFrom(cVar var)
    {
        resolver_ = null;
        if (var instanceof cContentResolver)
            resolver_ = ((cContentResolver)var).resolver_;
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_LOAD_BITMAP = 0;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_LOAD_BITMAP:
                    methodName = "loadBitmap";
                    f_loadBitmap(ret, (cContentResolver)stack.get(ct-4).var, (cUri)stack.get(ct-3).var,
                            (cInt)stack.get(ct-2).var, (cInt)stack.get(ct-1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> ContentResolver." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_loadBitmap(_Container ret, cContentResolver cr, cUri uri, cInt w, cInt h) throws Exception
    {
        ret.var = new cBitmap(_Util.decodeSampledBitmapFromContent(cr.resolver_, uri.uri_,
                (int)w.value, (int)h.value));
    }
}
