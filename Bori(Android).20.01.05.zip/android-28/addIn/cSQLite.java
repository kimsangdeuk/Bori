package bori.sangdeuk.db_memo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

class cSQLite extends cVar
{
    private SQLiteDatabase db_;

    cSQLite()
    {
        super(cType.TSQLITE);
        db_ = null;
    }
    cSQLite(SQLiteDatabase db)
    {
        super(cType.TSQLITE);
        db_ = db;
    }

    @Override
    public void copyFrom(cVar var)
    {
        db_ = null;
        if (var instanceof cSQLite)
            db_ = ((cSQLite)var).db_;
    }

    private void checkNull() throws Exception
    {
        if (db_ == null)
            throw new Exception("SQLite for this instance is not initilized.");
    }

    //---------------------------------------------------------------------
    private static final int FNC_EXEC = 0, FNC_QUERY = 1, FNC_GET_VERSION = 2, FNC_SET_VERSION = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_EXEC:
                    methodName = "exec";
                    f_exec((cSQLite) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_QUERY:
                    methodName = "query";
                    f_query(ret, (cSQLite) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_VERSION:
                    methodName = "getVersion";
                    f_getVersion(ret, (cSQLite) stack.get(ct - 1).var);
                    break;
                case FNC_SET_VERSION:
                    methodName = "setVersion";
                    f_setVersion((cSQLite) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> SQLite." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_exec(cSQLite db, cString sql) throws Exception
    {
        db.checkNull();
        db.db_.execSQL(sql.text);
    }
    private static void f_query(_Container ret, cSQLite db, cString sql) throws Exception
    {
        db.checkNull();
        Cursor cursor = db.db_.rawQuery(sql.text, null);
        ret.var = cRset.fromCursor(cursor);
        cursor.close();
    }
    private static void f_getVersion(_Container ret, cSQLite db) throws Exception
    {
        db.checkNull();
        ret.var = new cInt(db.db_.getVersion());
    }
    private static void f_setVersion(cSQLite db, cInt version) throws Exception
    {
        db.checkNull();
        db.db_.setVersion((int)version.value);
    }
}
