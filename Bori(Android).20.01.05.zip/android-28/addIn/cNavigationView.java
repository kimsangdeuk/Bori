package bori.example.actiongetimage;

import android.content.Context;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;

class cNavigationView extends cControl
{
    private NavigationView nv_;
    private _Fragment curFragment_ = null;

    cNavigationView(Context context)
    {
        super(cType.TC_NAVIGATIONVIEW);

        nv_ = new NavigationView(context);
        nv_.setId(_Env.nextID());

        // NavigationView.LayoutParams(NavigationView.LayoutParams.WRAP_CONTENT, NavigationView.LayoutParams.MATCH_PARENT));
        DrawerLayout.LayoutParams lp = new DrawerLayout.LayoutParams(DrawerLayout.LayoutParams.WRAP_CONTENT, DrawerLayout.LayoutParams.MATCH_PARENT);
        lp.gravity = 3; // importatnt
        nv_.setLayoutParams(lp);

        view = nv_;
    }

    //-----------------------------------------------------------
    private static final int FNC_SET_VIEW = 0, FNC_ATTACH_TO_VIEW = 1, FNC_OPEN = 2, FNC_CLOSE = 3;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_VIEW:
                    methodName = "setView";
                    f_setView(boriview, (cNavigationView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ATTACH_TO_VIEW:
                    methodName = "attachToView";
                    f_attachToView(boriview, (cNavigationView) stack.get(ct - 1).var);
                    break;
                case FNC_OPEN:
                    methodName = "open";
                    f_open(boriview, (cNavigationView) stack.get(ct - 1).var);
                    break;
                case FNC_CLOSE:
                    methodName = "close";
                    f_close(boriview, (cNavigationView) stack.get(ct - 1).var);
                    break;
                /*case FNC_GET_MENU:
                    methodName = "getMenu";
                    f_getMenu(boriview, ret, (cNavigationView) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ON_MENUITEM_CLICK:
                    methodName = "setOnMenuItemClick";
                    f_setOnMenuItemClick(boriview, (cNavigationView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ITEM_TEXT_COLOR:
                    methodName = "setItemTextColor";
                    f_setItemTextColor(boriview, (cNavigationView) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                case FNC_SET_ITEM_ICON_TINT_LIST:
                    methodName = "setItemIconTintList";
                    f_setItemIconTintList(boriview, (cNavigationView) stack.get(ct - 2).var, (cColor) stack.get(ct - 1).var);
                    break;
                    */
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> NavigationView." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setView(_BoriView boriview, cNavigationView navi, cString viewName)
    {
        _Fragment fragment = _Fragment.newInstance(viewName.text, boriview);
        FragmentTransaction t = boriview.bori.getSupportFragmentManager().beginTransaction();
        if (navi.curFragment_ != null)
            t.remove(navi.curFragment_);
        t.add(navi.nv_.getId(), fragment);
        t.commit();

        // don't need addHeaderView()
        // because FragmentTransaction aleady add child to the parent
        // navi.nv_.addHeaderView(navi.curFragment_.getLayout());
        // also, can not add header here, because fragment will connect the specified view later

        navi.curFragment_ = fragment;
    }
    private static void f_attachToView(_BoriView boriview, cNavigationView navi)
    {
        boriview.bori.attachNavigationView(navi.nv_);
    }
    private static void f_open(_BoriView boriview, cNavigationView navi)
    {
        boriview.bori.openDrawer(navi.nv_);
    }
    private static void f_close(_BoriView boriview, cNavigationView navi)
    {
        boriview.bori.closeDrawers();
    }
    /*private static void f_getMenu(_BoriView boriview, _Container ret, cNavigationView navi)
    {
        navi.alloc(boriview.bori);
        ret.var = new cMenu(navi.nv_.getMenu());
    }
    private static void f_setOnMenuItemClick(final _BoriView boriview, cNavigationView navi, final cString method)
    {
        navi.alloc(boriview.bori);
        navi.nv_.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
            {
                boriview.bori.closeDrawers();

                _ConList params = new _ConList();
                params.add(new _Container(new cMenuItem(menuItem)));
                boriview.call(method.text + "(MenuItem)", params);
                return false;
            }
        });
    }
    private static void f_setItemTextColor(_BoriView boriview, cNavigationView navi, cColor color)
    {
        navi.alloc(boriview.bori);
        navi.nv_.setItemTextColor(ColorStateList.valueOf(color.intValue()));
    }
    private static void f_setItemIconTintList(_BoriView boriview, cNavigationView navi, cColor color)
    {
        navi.alloc(boriview.bori);
        navi.nv_.setItemIconTintList(ColorStateList.valueOf(color.intValue()));
    }
    */
}
