package bori.sangdeuk.dialog;

import android.app.Dialog;
import android.view.Window;
import android.view.WindowManager;

class cDialog extends cVar
{
    private _DialogFragment fdlg_ = null;
    private boolean cancelable_ = true;

    cDialog()
    {
        super(cType.TDIALOG);
    }

    //-------------------------------------------------------------
    private static final int FNC_SET_VIEW = 0, FNC_SET_CANCELABLE = 1, FNC_SHOW = 2;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_SET_VIEW:
                    methodName = "setView";
                    f_setView(boriview, (cDialog) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_SET_CANCELABLE:
                    methodName = "setCancelable";
                    f_setCancelable((cDialog) stack.get(ct - 2).var, (cBool) stack.get(ct - 1).var);
                    break;
                case FNC_SHOW:
                    methodName = "show";
                    f_show(boriview, (cDialog) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Dialog." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_setView(_BoriView boriview, cDialog dlg, cString viewName) throws Exception
    {
        if (dlg.fdlg_ != null)
            throw new Exception("Content view already exists.");

        dlg.fdlg_ = _DialogFragment.newInstance(viewName.text, boriview);
    }
    private static void f_setCancelable(cDialog dlg, cBool cancelable)
    {
        dlg.cancelable_ = cancelable.isTrue();
    }
    private static void f_show(final _BoriView boriview, final cDialog dlg) throws Exception
    {
        if (dlg.fdlg_ == null)
            throw new Exception("Content View is not specified.");
        dlg.fdlg_.setCancelable(dlg.cancelable_);
        dlg.fdlg_.show(boriview.bori.getSupportFragmentManager(), "dialog_tag");
    }
}
