package bori.example.contacts;

import android.database.Cursor;

import java.util.ArrayList;

class cRset extends cVar
{
    private int ctFld_ = 0;
    private String[] names_;
    private int[] types_;
    private ArrayList<Object[]> records_;

    cRset()
    {
        super(cType.TRSET);
    }
    cRset(int ctFld, String[] names, int[] types)
    {
        super(cType.TRSET);
        ctFld_ = ctFld;
        names_ = names;
        types_ = types;
        records_ = new ArrayList<>();
    }

    @Override
    public void copyFrom(cVar var)
    {
        clear();
        if (var instanceof cRset)
        {
            cRset src = (cRset)var;
            ctFld_ = src.ctFld_;
            names_ = src.names_;
            types_ = src.types_;
            records_ = src.records_;
        }
    }

    private void checkInit() throws Exception
    {
        if (ctFld_ < 1)
            throw new Exception("Uninitialized rset.");
    }
    private static int typeFromText(String text) throws Exception
    {
        switch(text)
        {
            case "str": return cType.TSTRING;
            case "int": return cType.TBIGINT;
            case "double": return cType.TDOUBLE;
            default:
                throw new Exception("Invalid type name: " + text);
        }
    }
    private Object[] getRecord(int row) throws Exception
    {
        if (row < 0 || row >= records_.size())
            throw new Exception("Invalid record number: " + row + _Env.iBase);
        return records_.get(row);
    }
    private int findCol(String fldName) throws Exception
    {
        for (int i = 0; i < ctFld_; i++)
        {
            if (fldName.equals(names_[i]))
                return i;
        }
        throw new Exception("Invalid column name: " + fldName);
    }
    private int rowCount()
    {
        if (records_ == null)
            return 0;
        return records_.size();
    }
    int appendRow() throws Exception
    {
        checkInit();
        Object[] rec = new Object[ctFld_];
        records_.add(rec);
        return records_.size() - 1;

    }
    void updateString(int row, String columnName, String data) throws Exception
    {
        checkInit();
        Object[] rec = records_.get(row);
        int nfld = findCol(columnName);
        rec[nfld] = data;
    }
    void updateInt(int row, String columnName, long data) throws Exception
    {
        checkInit();
        Object[] rec = records_.get(row);
        int nfld = findCol(columnName);
        rec[nfld] = data;

    }
    void updateDouble(int row, String columnName, double data) throws Exception
    {
        checkInit();
        Object[] rec = records_.get(row);
        int nfld = findCol(columnName);
        rec[nfld] = data;

    }
    private String getString(int row, String columnName) throws Exception
    {
        checkInit();
        Object[] rec = getRecord(row);
        int nfld = findCol(columnName);
        return (String)rec[nfld];
    }
    private long getLong(int row, String columnName) throws Exception
    {
        checkInit();
        Object[] rec = getRecord(row);
        int nfld = findCol(columnName);
        return (long)rec[nfld];
    }
    private double getDouble(int row, String columnName) throws Exception
    {
        checkInit();
        Object[] rec = getRecord(row);
        int nfld = findCol(columnName);
        return (double)rec[nfld];
    }
    private String toText(String sep) throws Exception
    {
        if (ctFld_ < 1)
            return "";
        if (sep.isEmpty())
            throw new Exception("Separator is not specified.");

        StringBuilder sb = new StringBuilder();
        // names
        for (int i = 0; i < ctFld_; i++)
        {
            if (i > 0)
                sb.append(sep);
            sb.append(names_[i]);
        }
        sb.append("\n");
        // types
        for (int i = 0; i < ctFld_; i++)
        {
            if (i > 0)
                sb.append(sep);
            switch(types_[i])
            {
                case cType.TSTRING: sb.append("str"); break;
                case cType.TBIGINT: sb.append("int"); break;
                case cType.TDOUBLE: sb.append("double"); break;
                default:
                    throw new Exception("Unsupported value type.");
            }
        }
        sb.append("\n");
        // data
        for (int row = 0, ct = rowCount(); row < ct; row++)
        {
            Object[] record = records_.get(row);
            for (int fld= 0; fld < ctFld_; fld++)
            {
                if (fld > 0)
                    sb.append(sep);
                switch(types_[fld])
                {
                    case cType.TSTRING:
                        sb.append("\"");
                        sb.append((String)record[fld]);
                        sb.append("\"");
                        break;
                    case cType.TBIGINT:
                    {
                        long val = (long)record[fld];
                        if (val == cInt.NULL)
                            sb.append("NA");
                        else
                            sb.append(val);
                        break;
                    }
                    case cType.TDOUBLE:
                    {
                        double val = (double)record[fld];
                        if (val == cDouble.NULL)
                            sb.append("NA");
                        else
                            sb.append(val);
                    }
                        break;
                }
            }
            sb.append("\n");
        }

        return new String(sb);
    }

    static cRset fromCursor(Cursor cursor) throws Exception
    {
        if (cursor == null)
            throw new Exception("Null cursor.");
        if (!cursor.moveToFirst())
            return new cRset();

        int ctCol = cursor.getColumnCount();
        String[] names = cursor.getColumnNames();
        int[] types = new int[ctCol];
        for (int i = 0; i < ctCol; i++)
        {
            int type = cursor.getType(i);
            switch (type)
            {
                case Cursor.FIELD_TYPE_STRING:
                    types[i] = cType.TSTRING;
                    break;
                case Cursor.FIELD_TYPE_INTEGER:
                case Cursor.FIELD_TYPE_NULL:
                    types[i] = cType.TBIGINT;
                    break;
                case Cursor.FIELD_TYPE_FLOAT:
                    types[i] = cType.TDOUBLE;
                    break;
                default:
                    throw new Exception("Unsupported type found");
            }
        }

        cRset rset = new cRset(ctCol, names, types);
        do
        {
            int row = rset.appendRow();
            for (int i = 0; i < ctCol; i++)
            {
                boolean NA = (Cursor.FIELD_TYPE_NULL == cursor.getType(i));
                int type = types[i];
                switch (type)
                {
                    case cType.TSTRING:
                        rset.updateString(row, names[i], NA ? "" : cursor.getString(i));
                        break;
                    case cType.TBIGINT:
                        rset.updateInt(row, names[i], NA ? cInt.NULL : cursor.getInt(i));
                        break;
                    case cType.TDOUBLE:
                        rset.updateDouble(row, names[i], NA ? cDouble.NULL : cursor.getDouble(i));
                        break;
                    default:
                        throw new Exception("Unsupported type");
                }
            }
        } while (cursor.moveToNext());
        return rset;
    }

    //---------------------------------------------------------------------
    private static final int FNC_NEW = 0, FNC_APPEND_ROW = 1,
            FNC_UPDATE_STRING = 2, FNC_UPDATE_INT = 3, FNC_UPDATE_DOUBLE = 4,
            FNC_GET_STRING = 5, FNC_GET_INT = 6, FNC_GET_DOUBLE = 7,
            FNC_ROW_COUNT = 8, FNC_FROM_TEXT = 9, FNC_TO_TEXT = 10,
            FNC_GET_COLUMNNAMES = 11;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_NEW:
                    methodName = "new";
                    f_new(ret, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_APPEND_ROW:
                    methodName = "appendRow";
                    f_appendRow(ret, (cRset) stack.get(ct - 1).var);
                    break;
                case FNC_UPDATE_STRING:
                    methodName = "updateString";
                    f_updateString((cRset) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_UPDATE_INT:
                    methodName = "updateInt";
                    f_updateInt((cRset) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cInt) stack.get(ct - 1).var);
                    break;
                case FNC_UPDATE_DOUBLE:
                    methodName = "updateDouble";
                    f_updateDouble((cRset) stack.get(ct - 4).var, (cInt) stack.get(ct - 3).var, (cString) stack.get(ct - 2).var, (cDouble) stack.get(ct - 1).var);
                    break;
                case FNC_GET_STRING:
                    methodName = "getString";
                    f_getString(ret, (cRset) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_INT:
                    methodName = "getInt";
                    f_getInt(ret, (cRset) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_DOUBLE:
                    methodName = "getDouble";
                    f_getDouble(ret, (cRset) stack.get(ct - 3).var, (cInt) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_ROW_COUNT:
                    methodName = "rowCount";
                    f_rowCount(ret, (cRset) stack.get(ct - 1).var);
                    break;
                case FNC_FROM_TEXT:
                    methodName = "fromText";
                    f_fromText(ret, (cString) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_TO_TEXT:
                    methodName = "toText";
                    f_toText(ret, (cRset) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_GET_COLUMNNAMES:
                    methodName = "getColumnNames";
                    f_getColumnNames(ret, (cRset) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> Rset." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_new(_Container ret, cString structure) throws Exception
    {
        String[] ss = structure.text.split(",");
        int ctFld = ss.length;
        String[] names = new String[ctFld];
        int[] types = new int[ctFld];
        for (int i = 0; i < ctFld; i++)
        {
            String fld = ss[i].trim();
            if (! fld.endsWith(")"))
                throw new Exception("Invalid structure:" + fld);
            String sub = fld.substring(0, fld.length() - 1);
            String[] name_type = sub.split("\\(", 0);
            if (name_type.length != 2)
                throw new Exception("Invalid structure: " + sub);
            names[i] = name_type[0];
            types[i] = typeFromText(name_type[1]);
        }

        ret.var = new cRset(ctFld, names, types);
    }
    private static void f_appendRow(_Container ret, cRset rset) throws Exception
    {
        ret.var = new cInt(rset.appendRow() + _Env.iBase);
    }
    private static void f_updateString(cRset rset, cInt row, cString columnName, cString data) throws Exception
    {
        rset.updateString((int)row.value - _Env.iBase, columnName.text, data.text);
    }
    private static void f_updateInt(cRset rset, cInt row, cString columnName, cInt data) throws Exception
    {
        rset.updateInt((int)row.value - _Env.iBase, columnName.text, data.value);
    }
    private static void f_updateDouble(cRset rset, cInt row, cString columnName, cDouble data) throws Exception
    {
        rset.updateDouble((int)row.value - _Env.iBase, columnName.text, data.value);
    }
    private static void f_getString(_Container ret, cRset rset, cInt row, cString columnName) throws Exception
    {
        ret.var = new cString(rset.getString((int)row.value - _Env.iBase, columnName.text));
    }
    private static void f_getInt(_Container ret, cRset rset, cInt row, cString columnName) throws Exception
    {
        ret.var = new cInt(rset.getLong((int)row.value - _Env.iBase, columnName.text));
    }
    private static void f_getDouble(_Container ret, cRset rset, cInt row, cString columnName) throws Exception
    {
        ret.var = new cDouble(rset.getDouble((int)row.value - _Env.iBase, columnName.text));
    }
    private static void f_rowCount(_Container ret, cRset rset)
    {
        ret.var = new cInt(rset.rowCount());
    }
    private static void f_fromText(_Container ret, cString data, cString separator) throws Exception
    {
        char sep = separator.text.charAt(0);

        ArrayList<String> list = new ArrayList<>();
        {
            String[] lines = _Util.splitLines(data.text);
            for (String s : lines)
            {
                String t = s.trim();
                if (t.length() < 1)
                    continue;
                list.add(s);
            }
        }
        if (list.size() < 2)
            throw new Exception("Header is missing.");

        // names
        String[] names = parseFlds(list.get(0), sep);
        int ctFld = names.length;

        // types
        int[] types = new int[ctFld];
        String[] stypes = parseFlds(list.get(1), sep);
        if (stypes.length != ctFld)
            throw new Exception("Number of types is different from number of names.");
        for (int i = 0; i < ctFld; i++)
            types[i] = typeFromText(stypes[i].trim());

        // data
        ArrayList<Object[]> records = new ArrayList<>();
        for (int i = 2, ct = list.size(); i < ct; i++)
        {
            try
            {
                records.add(parseDataFlds(list.get(i).trim(), types, sep));
            }
            catch(Exception e)
            {
                throw new Exception("line number:" + (i + 1) + "\n" + e.getMessage());
            }
        }

        cRset rset = new cRset();
        rset.ctFld_ = ctFld;
        rset.names_ = names;
        rset.types_ = types;
        rset.records_ = records;

        ret.var = rset;
    }

    private static String[] parseFlds(String line, char sep) throws Exception
    {
        ArrayList<String> list = new ArrayList<>();
        int i = 0;
        int len = line.length();
        while (i < len)
        {
            StringBuilder sb = new StringBuilder();
            while (i < len && line.charAt(i) != sep)
                sb.append(line.charAt(i++));
            list.add(new String(sb));
            i++;
        }
        String[] arr = new String[list.size()];
        for (int n = 0, ct = list.size(); n < ct; n++)
        {
            arr[n] = list.get(n).trim();
            if (arr[n].length() < 1)
                throw new Exception("Column name or type must not be blank.");
        }
        return arr;
    }
    private static Object[] parseDataFlds(String line, int[] types, char sep) throws Exception
    {
        int ctFld = types.length;
        Object[] rec = new Object[ctFld];
        int nfld = 0;
        int i = 0;
        int len = line.length();
        while (nfld < ctFld)
        {
            if (line.charAt(i) == '"')
            {
                i++;
                if (types[nfld] != cType.TSTRING)
                    throw new Exception("String type data found on number type column.");
                StringBuilder sb = new StringBuilder();
                while (i < len && line.charAt(i) != '"')
                {
                    sb.append(line.charAt(i));
                    i++;
                }
                if (i >= line.length())
                    throw new Exception("Closing quotation mark is missing.");
                rec[nfld++] = new String(sb);
                i++;
                // whitespace before sep
                while (i < len && line.charAt(i) <= ' ')
                    i++;
                if (i >= len)
                    break;
                if (line.charAt(i) != sep)
                    throw new Exception("Separator needed.");
                i++; // sep
                // whitespace after sep
                while (i < len && line.charAt(i) <= ' ')
                    i++;
                if (i >= len)
                    break;
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                while (i < line.length() && line.charAt(i) != sep)
                {
                    sb.append(line.charAt(i));
                    i++;
                }
                String value = new String(sb).trim();
                switch(types[nfld])
                {
                    case cType.TSTRING:
                        rec[nfld++] = value;
                        break;
                    case cType.TBIGINT:
                        rec[nfld++] = Long.parseLong(value);
                        break;
                    case cType.TDOUBLE:
                        rec[nfld++] = Double.parseDouble(value);
                        break;
                    default:
                        throw new Exception("Unsupported value type.");
                }
                i++;
                // whitespace after sep
                while (i < len && line.charAt(i) <= ' ')
                    i++;
                if (i >= len)
                    break;
            }
        }
        while (nfld < ctFld)
        {
            switch(types[nfld])
            {
                case cType.TSTRING:
                    rec[nfld++] = "";
                    break;
                case cType.TBIGINT:
                    rec[nfld++] = cInt.NULL;
                    break;
                case cType.TDOUBLE:
                    rec[nfld++] = cDouble.NULL;
                    break;
                default:
                    throw new Exception("Unsupported value type.");
            }
        }
        return rec;
    }
    private static void f_toText(_Container ret, cRset rset, cString separator) throws Exception
    {
        ret.var = new cString(rset.toText(separator.text));
    }
    private static void f_getColumnNames(_Container ret, cRset rset)
    {
        ret.var = (rset.names_ == null) ? new cStrs() : new cStrs(rset.names_);
    }
}
