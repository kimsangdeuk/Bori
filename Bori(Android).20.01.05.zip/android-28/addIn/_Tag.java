package bori.sangdeuk.db_memo;

import android.view.MotionEvent;
import android.view.View;

class _Tag
{
    private _BoriView boriview_;
    private View view_;
    private xLinearLayout parent_;
    private String	name;
    int x, y;
    int	width;
    int	height;
    long value;
    private String methodOnClick_;
    private String methodOnLongClick_;
    private String methodOnTouch_;

    private _Tag(_BoriView boriview, View view)
    {
        boriview_ = boriview;
        view_ = view;
        parent_ = null;
        name = "";
        x = 0;
        y = 0;
        width = 0;
        height = 0;
        value = cInt.NULL;
        methodOnClick_ = null;
        methodOnLongClick_ = null;
        methodOnTouch_ = null;
    }

    //---------------------------------------------------------------------
    private static int getUniqueID() { return R.string.app_name; }
    static void set(_BoriView boriview, View view)
    {
        view.setTag(getUniqueID(), new _Tag(boriview, view));
    }
    static _Tag get (View view)
    {
        return (_Tag)view.getTag(getUniqueID());
    }

    //---------------------------------------------------------------------
    void setName (String name0)	{	name = name0;	}
    String getName ()	{ return name; }
    void setParent(xLinearLayout parent) { parent_ = parent; }
    xLinearLayout getParent() { return parent_; }

    void setOnClick(String sig)
    {
        if (null == boriview_.findBoriMethod(sig))
            return;

        methodOnClick_ = sig;

        view_.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                _ConList params = new _ConList();

                cControl control = new cControl(v);
                params.add(new _Container(control));

                try
                {
                    boriview_.call(methodOnClick_, params);
                }
                catch (Exception e)
                {
                    _Alert.showException(boriview_.bori, "> " + methodOnClick_ + "\n" + e.getMessage());
                }
            }
        });
    }

    void setOnLongClick(String sig)
    {
        if (null == boriview_.findBoriMethod(sig))
            return;

        methodOnLongClick_ = sig;

        view_.setOnLongClickListener(new View.OnLongClickListener()
        {
            @Override
            public boolean onLongClick(View v)
            {
                _ConList params = new _ConList();

                cControl control = new cControl(v);
                params.add(new _Container(control));

                try
                {
                    boriview_.call(methodOnLongClick_, params);
                }
                catch (Exception e)
                {
                    _Alert.showException(boriview_.bori, "> " + methodOnLongClick_ + "\n" + e.getMessage());
                }
                return true;
            }
        });
    }

    void setOnTouch(String sig)
    {
        if (null == boriview_.findBoriMethod(sig))
            return;

        methodOnTouch_ = sig;

        view_.setOnTouchListener(new View.OnTouchListener()
            {
                @Override
                public boolean onTouch(View v, MotionEvent event)
                {
                    _Container ret = new _Container();
                    _ConList params = new _ConList();
                    params.add(new _Container(new cControl(v)));
                    params.add(new _Container(new cMotionEvent(event)));

                    try
                    {
                        boriview_.call(ret, methodOnTouch_, params);
                    }
                    catch (Exception e)
                    {
                        _Alert.showException(boriview_.bori, "> " + methodOnTouch_ + "\n" + e.getMessage());
                        return true;
                    }

                    if (event.getActionMasked() == MotionEvent.ACTION_UP)
                        v.performClick();

                    return (ret.var).isTrue();
                }
            });

    }

}
