package bori.example.actiongetimage;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v4.app.ActivityCompat;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.HashMap;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

class _BoriView
{
    protected BoriActivity bori;
    Object parent_; // for notify in cView
    private String filename_;
    private boolean asMain_;
    private boolean fullFrame_;
    private int baseViewWidth_;
    private int baseViewHeight_;

    private ArrayList<_Timer> listTimer_;

    private xLinearLayout layoutLinear_;

    ArrayList<_Item> listItems;

    private ArrayList<_Method> listMethods;
    private _ConList listVars;

    private String methodOnCreate = null;
    private String methodOnStart = null;
    private String methodOnResume = null;
    private String methodOnPause = null;
    private String methodOnStop = null;
    private String methodOnViewResult = null;
    private String methodOnBackPressed = null;
    private String methodOnTimer = null;
    private String methodOnCommand = null;
    private String methodOnNotify = null;
    private String methodOnOrientationChanged = null;

    private int viewWidth_ = 0;

    private HashMap<Integer, String> viewRequest_;
    private HashMap<Integer, String> actionRequest_;
    private int requestCode_;

    _BoriView(BoriActivity bori0, Object parent, boolean fullFrame)
    {
        bori = bori0;
        parent_ = parent;
        fullFrame_ = fullFrame;
        if (parent instanceof BoriActivity
                || parent instanceof _Fragment || parent instanceof _DialogFragment)
            asMain_ = true;
        else
            asMain_ = false;
        layoutLinear_ = createLayout();

        viewRequest_ = new HashMap<>();
        actionRequest_ = new HashMap<>();
        requestCode_ = 100;
    }

    private xLinearLayout createLayout()
    {
        xLinearLayout layout = new xLinearLayout(this, fullFrame_);
        _Tag.set(this, layout);
        layout.setBackgroundColor(Color.TRANSPARENT);
        layout.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, WRAP_CONTENT));
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setId(_Env.nextID());
        return layout;
    }

    xLinearLayout getLayout()
    {
        return layoutLinear_;
    }

    // should not put this procedure into constructor
    // or you can not control the exception
    void init(String viewFile) throws Exception
    {
        filename_ = viewFile;

        listTimer_ = new ArrayList<>();
        listItems = new ArrayList<>();
        listMethods = new ArrayList<>();
        listVars = new _ConList();

        Node nodeView = bori.findView(filename_);
        if (nodeView == null)
            throw new Exception("Can not find the view: " + filename_);

        if (asMain_)
        {
            readVars(nodeView);
            readMethods(nodeView);
        }

        // initialize view & widgets
        Node panel = _Xml.getChildElement(nodeView, "panel");
        if (panel == null)
            throw new Exception("No panel element");

        readDimension(panel);
        initItems(panel);

        layoutLinear_.setStyle(panel);
        if (asMain_)
        {
            setEvent(_Xml.getChildList(panel, "event"));
        }
    }

    private void readDimension(Node nodePanel) throws Exception
    {
        String value;
        value = _Xml.getAttributeValue(nodePanel, "width");
        if (value.equals(""))
            throw new Exception("View width was not specified.");
        baseViewWidth_ = Integer.parseInt(value);

        value = _Xml.getAttributeValue(nodePanel,"height");
        if (value.equals(""))
            throw new Exception("View height was not specified.");
        baseViewHeight_ = Integer.parseInt(value);

        // isLandscape
        boolean isLandscape = false;
        Display display = bori.getWindowManager().getDefaultDisplay();
        Point outSize = new Point();
        display.getSize(outSize);
        if (outSize.y < outSize.x)
            isLandscape = true;

//        if (isLandscape)
//        {
//            int t = projWidth_;
//            projWidth_ = projHeight_;
//            projHeight_ = t;
//        }
    }

    private int getProportionedWidthMain (int w)
    {
        if (w < 0)
            return w;
        return w * bori.getScreenWidth() / baseViewWidth_;
    }
    private int getProportionedHeightMain (int h)
    {
        if (h < 0)
            return h;
        return h * bori.getScreenHeight() / baseViewHeight_;
    }

    // items -------------------------------------------------------------------------------------------
    private void initItems(Node panel)
    {
        NodeList items = panel.getChildNodes();
        int ctItems = items.getLength();

        int yGroup = 0;

        ConstraintLayout cl = new ConstraintLayout(bori);
        _Tag.set(this, cl);
        cl.setBackgroundColor(Color.TRANSPARENT);
        cl.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, WRAP_CONTENT));
        cl.setId(_Env.nextID());

        // init items
        for (int i = 0; i < ctItems; i++)
        {
            Node node = items.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE)
            {
                String nodeName = node.getNodeName();
                if (nodeName.equals("Wrap"))
                {
                    yGroup = Integer.parseInt(_Xml.getAttributeValue(node, "y"));

                    layoutLinear_.addView(cl);

                    cl = new ConstraintLayout(bori);
                    _Tag.set(this, cl);
                    cl.setBackgroundColor(Color.TRANSPARENT);
                    cl.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, WRAP_CONTENT));
                    cl.setId(_Env.nextID());
                    continue;
                }

                cControl control = _ItemCreator.create(nodeName, this, node, asMain_);
                if (control == null)
                    continue;

                _Tag info = _Tag.get(control.view);
                String name = _Xml.getAttributeValue(node, "name");
                info.setName(name);
                info.setParent(layoutLinear_);
                info.x = Integer.parseInt(_Xml.getAttributeValue(node, "x"));
                info.y = Integer.parseInt(_Xml.getAttributeValue(node, "y")) - yGroup;
                info.width = Integer.parseInt(_Xml.getAttributeValue(node, "width"));
                info.height = Integer.parseInt(_Xml.getAttributeValue(node, "height"));

                String sheight = _Xml.getAttributeValue(node, "autoHeight");
                if (sheight.equals("true"))
                    info.height = WRAP_CONTENT;

                if (nodeName.equals("FloatingActionButton"))
                {
                    info.width = WRAP_CONTENT;
                    info.height = WRAP_CONTENT;
                }

                //registerContextMenu(node, control.view);

                _Item item = new _Item(name, control.view);
                listItems.add(item);
                listVars.add(new _Container(control));
                addChildToConstraint(cl, item);
            }
        }
        if (cl.getChildCount() > 0)
            layoutLinear_.addView(cl);
    }

    ArrayList<_Item> getItemList()
    {
        return listItems;
    }

    private void addChildToConstraint(ConstraintLayout cl, _Item item)
    {
        View view = item.view();

        ConstraintLayout.LayoutParams clp = new ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_CONSTRAINT, ConstraintLayout.LayoutParams.MATCH_CONSTRAINT);
        view.setLayoutParams(clp);
        view.setId(_Env.nextID());
        cl.addView(view);

        locateItem(cl, view);
    }
    private void locateItem(ConstraintLayout cl, View view)
    {
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(cl);

        _Tag info = _Tag.get(view);
        int x = getProportionedWidthMain(info.x);
        int y = getProportionedHeightMain(info.y);
        int w = getProportionedWidthMain(info.x + info.width) - x;
        int h = getProportionedHeightMain(info.y + info.height) - y;

        constraintSet.connect(view.getId(), ConstraintSet.TOP, cl.getId(), ConstraintSet.TOP, y);
        constraintSet.connect(view.getId(), ConstraintSet.LEFT, cl.getId(), ConstraintSet.LEFT, x);
        constraintSet.constrainWidth(view.getId(), w);
        constraintSet.constrainHeight(view.getId(), h);
        constraintSet.applyTo(cl);

        if (viewWidth_ < x + w)
            viewWidth_ = x + w;
    }

    int getViewWidth()
    {
        return viewWidth_;
    }

    private void relocateItems()
    {
        viewWidth_ = 0;
        for (int ncl = 0, ctcl = layoutLinear_.getChildCount(); ncl < ctcl; ncl++)
        {
            ConstraintLayout cl = (ConstraintLayout)layoutLinear_.getChildAt(ncl);
            for (int nitem = 0, ctitem = cl.getChildCount(); nitem < ctitem; nitem++)
            {
                View view = cl.getChildAt(nitem);
                locateItem(cl, view);
            }
        }
    }

    View findChild(String name)
    {
        for (int ncl = 0, ctcl = layoutLinear_.getChildCount(); ncl < ctcl; ncl++)
        {
            ConstraintLayout cl = (ConstraintLayout)layoutLinear_.getChildAt(ncl);
            for (int nitem = 0, ctitem = cl.getChildCount(); nitem < ctitem; nitem++)
            {
                View view = cl.getChildAt(nitem);
                _Tag info = _Tag.get(view);
                if (name.equals(info.getName()))
                    return view;
            }
        }
        return null;
    }

    // timer -------------------------------------------------------
    void setTimer(String name, int interval, int repeat)
    {
        killTimer(name);

        _Timer t = new _Timer(this, name, interval, repeat);
        listTimer_.add(t);
        t.start();
    }
    void killTimer(String name)
    {
        for (int i = 0, ct = listTimer_.size(); i < ct; i++)
        {
            _Timer timer = listTimer_.get(i);
            String name2 = timer.getName();
            if (name2.equals(name))
            {
                timer.cancel();
                listTimer_.remove(i);
                break;
            }
        }
    }
    boolean isTimerRunning(String name)
    {
        for (int i = 0, ct = listTimer_.size(); i < ct; i++)
        {
            _Timer timer = listTimer_.get(i);
            String name2 = timer.getName();
            if (name2.equals(name))
                return true;
        }
        return false;
    }
    private void killTimerAll()
    {
        for (int i = 0, ct = listTimer_.size(); i < ct; i++)
        {
            _Timer timer = listTimer_.get(i);
            timer.cancel();
        }
        listTimer_.clear();
    }

    //-----------------------------------
    private void readVars(Node nodeView) throws Exception
    {
        _Method method = null;
        NodeList nl = nodeView.getChildNodes();
        for (int i = 0, ct = nl.getLength(); i < ct; i++)
        {
            Node child = nl.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE)
            {
                if (child.getNodeName().equals("v"))
                {
                    Node nodeCode = _Xml.getChildElement(child, "code");
                    String code = _Xml.getText(nodeCode);
                    Node nodeData = _Xml.getChildElement(child, "data");
                    String data = _Xml.getText(nodeData);
                    method = new _Method("", "0", code, data);
                    break;
                }
            }
        }
        if (method != null)
        {
            _Run run = new _Run(this, method, listVars, null);
            run.runVar();
        }
    }

    private void readMethods(Node nodeView)
    {
        NodeList nl = nodeView.getChildNodes();
        for (int i = 0, ct = nl.getLength(); i < ct; i++)
        {
            Node child = nl.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE)
            {
                if (child.getNodeName().equals("p"))
                {
                    String name = _Xml.getAttributeValue(child, "name");
                    String type = _Xml.getAttributeValue(child, "type");
                    Node nodeCode = _Xml.getChildElement(child, "code");
                    String code = _Xml.getText(nodeCode);
                    Node nodeData = _Xml.getChildElement(child, "data");
                    String data = _Xml.getText(nodeData);
                    listMethods.add(new _Method(name, type, code, data));
                }
            }
        }
    }

    _Method findBoriMethod(String sig)
    {
        for (int i = 0, ct = listMethods.size(); i < ct; i++)
        {
            _Method method = listMethods.get(i);
            if (method.name.equals(sig))
                return method;
        }
        _Alert.showException(bori, "Method is missing: " + sig);
        return null;
    }

    private _Method findBoriMethod(int func) throws Exception
    {
        _Method method;
        try
        {
            method = listMethods.get(func);
        }
        catch (Exception e)
        {
            throw new Exception("Error in findBoriMethod(" + func + ")");
        }
        return method;
    }

    //----------------------------------------------------
    void onCreate(Bundle savedInstanceState, cVars varsIn)
    {
        if (methodOnCreate == null)
            return;

        try
        {
            cVars vars;
            Intent intent = bori.getIntent();
            if (varsIn != null)
                vars = varsIn;
            else if (_Bundle.isBoriBundle(intent))
                vars = _Bundle.readBundle(intent.getExtras());
            else
                vars = new cVars();

            _ConList params = new _ConList();
            params.add(new _Container(vars));

            _Run run = new _Run(this, findBoriMethod(methodOnCreate), listVars, params);
            run.run();
        }
        catch (Exception e) { _Alert.showException(bori, e.getMessage()); }
    }
    void onStart()
    {
        if (methodOnStart != null)
        {
            _ConList params = new _ConList();
            _Run run = new _Run(this, findBoriMethod(methodOnStart), listVars, params);
            run.run();
        }
    }
    void onResume()
    {
        if (methodOnResume != null)
        {
            _ConList params = new _ConList();
            _Run run = new _Run(this, findBoriMethod(methodOnResume), listVars, params);
            run.run();
        }
    }

    void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        if (actionRequest_.containsKey(requestCode))
        {
            String method = actionRequest_.get(requestCode);
            actionRequest_.remove(requestCode);

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                _ConList params = new _ConList();
                call(method + "()", params);
            }
        }
    }

    void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (actionRequest_.containsKey(requestCode))
        {
            String method = actionRequest_.get(requestCode);
            actionRequest_.remove(requestCode);

            _ConList params = new _ConList();
            params.add(new _Container(new cInt(resultCode)));
            params.add(new _Container(new cIntent(data)));
            call(method + "(Int,Intent)", params);
            return;
        }

        if (! viewRequest_.containsKey(requestCode))
        {
            _Alert.showException(bori, "Unidentified request code.");
            return;
        }

        String viewName = viewRequest_.get(requestCode);
        viewRequest_.remove(requestCode);

        if (methodOnViewResult == null)
            return;
        try
        {
            int index = viewName.indexOf(".view");
            if (index > -1)
                viewName = viewName.substring(0, index);

            cVars vars;
            if (data != null)
                vars = _Bundle.readBundle(data.getExtras());
            else
                vars = new cVars();

            _ConList params = new _ConList();
            params.add(new _Container(new cString(viewName)));
            params.add(new _Container(new cInt(resultCode)));
            params.add(new _Container(vars));

            _Run run = new _Run(this, findBoriMethod(methodOnViewResult), listVars, params);
            run.run();
        }
        catch (Exception e)
        {
            _Alert.showException(bori, e.getMessage());
        }
    }

    boolean onBackPressed()
    {
        if (methodOnBackPressed == null)
            return false;
        _ConList params = new _ConList();
        _Run run = new _Run(this, findBoriMethod(methodOnBackPressed), listVars, params);
        run.run();
        return true;
    }
    void onPause()
    {
        if (methodOnPause != null)
        {
            _ConList params = new _ConList();
            _Run run = new _Run(this, findBoriMethod(methodOnPause), listVars, params);
            run.run();
        }
    }
    void onStop()
    {
        if (methodOnStop != null)
        {
            _ConList params = new _ConList();
            _Run run = new _Run(this, findBoriMethod(methodOnStop), listVars, params);
            run.run();
        }
        killTimerAll();
    }

    void onTimer(String name)
    {
        if (methodOnTimer != null)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cString(name)));
            _Run run = new _Run(this, findBoriMethod(methodOnTimer), listVars, params);
            run.run();
        }
    }
    void onCommand(String message, cVars vars)
    {
        if (methodOnCommand != null)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cString(message)));
            params.add(new _Container(new cVars(vars)));
            _Run run = new _Run(this, findBoriMethod(methodOnCommand), listVars, params);
            run.run();
        }
    }
    void onNotify(String viewName, String message, cVars vars)
    {
        if (methodOnNotify != null)
        {
            _ConList params = new _ConList();
            params.add(new _Container(new cString(viewName)));
            params.add(new _Container(new cString(message)));
            params.add(new _Container(new cVars(vars)));
            _Run run = new _Run(this, findBoriMethod(methodOnNotify), listVars, params);
            run.run();
        }
    }
    void setOnOrientationChanged(String methodName)
    {
        methodOnOrientationChanged = methodName + "()";
    }
    void onOrientationChanged()
    {
        relocateItems();
        if (methodOnOrientationChanged != null)
        {
            _ConList params = new _ConList();
            _Run run = new _Run(this, findBoriMethod(methodOnOrientationChanged), listVars, params);
            run.run();
        }
    }

    void call(_Container ret, int func, _ConList params) throws Exception
    {
        _Run run = new _Run(this, findBoriMethod(func), listVars, params);
        run.run(ret);
    }
    void call(String sig)
    {
        _ConList params = new _ConList();
        _Run run = new _Run(this, findBoriMethod(sig), listVars, params);
        run.run();
    }
    void call(String sig, _ConList params)
    {
        _Run run = new _Run(this, findBoriMethod(sig), listVars, params);
        run.run();
    }
    void call(_Container ret, String sig, _ConList params) throws Exception
    {
        _Run run = new _Run(this, findBoriMethod(sig), listVars, params);
        run.run(ret);
    }

    //------------------------------------------------------
    private void setEvent(ArrayList<Node> list)
    {
        for (int i = 0, ct = list.size(); i < ct; i++)
        {
            Node node = list.get(i);
            String name = _Xml.getAttributeValue(node, "name");
            String method = _Xml.getAttributeValue(node, "method");
            switch (name)
            {
                case "onCreate": methodOnCreate = method; break;
                case "onStart": methodOnStart = method; break;
                case "onResume": methodOnResume = method; break;
                case "onPause": methodOnPause = method; break;
                case "onStop": methodOnStop = method; break;
                case "onViewResult": methodOnViewResult = method; break;
                case "onBackPressed": methodOnBackPressed = method; break;
//                case "onCreateMenu": methodOnCreateMenu = method; break;
//                case "onMenuItemSelected": methodOnMenuItemSelected = method; break;
//                case "onMenuOpened": methodOnMenuOpened = method; break;
                case "onTimer": methodOnTimer = method; break;
                case "onCommand": methodOnCommand = method; break;
                case "onNotify": methodOnNotify = method; break;
                case "onDraw": layoutLinear_.setDrawMethod(method); break;
                case "onTouch": layoutLinear_.setTouchMethod(method); break;
                case "onClick": layoutLinear_.setClickMethod(method); break;
                case "onLongClick": layoutLinear_.setLongClickMethod(method); break;
                case "onSizeChanged": layoutLinear_.setSizeChangedMethod(method); break;
            }
        }
    }

    //----------------------------------------------
    void openView(String viewfile, Intent intent)
    {
        viewRequest_.put(requestCode_, viewfile);
        bori.startActivityForResult (intent, requestCode_);
        requestCode_++;
    }
    void startAction(Intent intent, String method)
    {
        actionRequest_.put(requestCode_, method);
        bori.startActivityForResult (intent, requestCode_);
        requestCode_++;
    }
    void requestPermission(String permission, String funcName)
    {
        actionRequest_.put(requestCode_, funcName);
        ActivityCompat.requestPermissions(bori, new String[]{permission}, requestCode_);
        requestCode_++;
    }

    //----------------------------------------------
    // called by methods of cView
    private void invalidateRecursive(ViewGroup layout)
    {
        for (int i = 0, ct = layout.getChildCount(); i < ct; i++)
        {
            View child = layout.getChildAt(i);
            if(child instanceof ViewGroup)
                invalidateRecursive((ViewGroup) child);
            else
                child.invalidate();
        }
    }
    void repaint()
    {
        layoutLinear_.invalidate();
        invalidateRecursive(layoutLinear_);
    }
    void setBackColor(int color)
    {
        layoutLinear_.setBackgroundColor(color);
    }

    void notifyToParent(String message, cVars vars) throws Exception
    {
        if (parent_ instanceof _Fragment)
        {
            _Fragment fragment = (_Fragment) parent_;
            fragment.notify(message, vars);
        }
        else if (parent_ instanceof _DialogFragment)
        {
            _DialogFragment dlg = (_DialogFragment) parent_;
            dlg.notify(message, vars);

        }
        else
            throw new Exception("No parent to notify.");
    }
}

