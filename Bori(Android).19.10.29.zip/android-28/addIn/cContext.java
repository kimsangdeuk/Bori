package bori.sangdeuk.imagecapture_fileprovider;

import android.database.sqlite.SQLiteDatabase;

import static android.content.Context.MODE_PRIVATE;

class cContext extends cVar
{
    cContext()
    {
        super(cType.TCONTEXT);
    }

    //--------------------------------------------------------------------------------------
    private static final int FNC_GET_FILES_DIR = 0, FNC_GET_EXTERNAL_FILES_DIR = 1, FNC_GET_EXTERNAL_FILES_DIR_TYPE = 2,
            FNC_OPEN_DATABASE = 3, FNC_GET_PACKAGE_NAME = 4;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_GET_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getFilesDir(boriview, ret);
                    break;
                case FNC_GET_EXTERNAL_FILES_DIR:
                    methodName = "getFilesDir";
                    f_getExternalFilesDir(boriview, ret);
                    break;
                case FNC_GET_EXTERNAL_FILES_DIR_TYPE:
                    methodName = "getFilesDirWithType";
                    f_getExternalFilesDirWithType(boriview, ret, (cString)stack.get(ct-1).var);
                    break;
                case FNC_OPEN_DATABASE:
                    methodName = "openDatabase";
                    f_openDatabase(boriview, ret);
                    break;
                case FNC_GET_PACKAGE_NAME:
                    methodName = "getPackageName";
                    f_getPackageName(boriview, ret);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch (Exception e)
        {
            throw new Exception("> Context." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_getFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getFilesDir());
    }
    private static void f_getExternalFilesDir (_BoriView boriview, _Container ret)
    {
        ret.var = new cFile(boriview.bori.getExternalFilesDir(null));
    }
    private static void f_getExternalFilesDirWithType (_BoriView boriview, _Container ret, cString type)
    {
        ret.var = new cFile(boriview.bori.getExternalFilesDir(type.text.isEmpty() ? null : type.text));
    }
    private static void f_openDatabase (_BoriView boriview, _Container ret)
    {
        SQLiteDatabase db = boriview.bori.openOrCreateDatabase(boriview.bori.getPackageName(), MODE_PRIVATE, null);
        ret.var = new cSQLite(db);
    }
    private static void f_getPackageName (_BoriView boriview, _Container ret)
    {
        ret.var = new cString(boriview.bori.getPackageName());
    }
}
