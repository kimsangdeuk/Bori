package com.sangdeuk.fragment1;

public class cWebView extends cControl
{
    cWebView()
    {
        super(cType.TC_WEB);
    }
    cWebView(xWebView view_)
    {
        super(cType.TC_WEB);
        view = view_;
    }

    //---------------------------------------------------------------------
    private static final int FNC_LOAD_URL = 0,
    FNC_CAN_GO_BACK = 1, FNC_CAN_GO_FORWARD = 2, FNC_GO_BACK = 3, FNC_GO_FORWARD = 4,
    FNC_RELOAD = 5, FNC_GET_URL = 6, FNC_GET_TITLE = 7;

    static void call(_BoriView boriview, _Container ret, int nfunc, _ConList stack) throws Exception
    {
        String methodName = "";
        try
        {
            int ct = stack.size();
            switch (nfunc)
            {
                case FNC_LOAD_URL:
                    methodName = "loadUrl";
                    f_loadUrl((cWebView) stack.get(ct - 2).var, (cString) stack.get(ct - 1).var);
                    break;
                case FNC_CAN_GO_BACK:
                    methodName = "canGoBack";
                    f_canGoBack(ret, (cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_CAN_GO_FORWARD:
                    methodName = "canGoForward";
                    f_canGoForward(ret, (cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_GO_BACK:
                    methodName = "goBack";
                    f_goBack((cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_GO_FORWARD:
                    methodName = "goForward";
                    f_goForward((cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_RELOAD:
                    methodName = "reload";
                    f_reload((cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_GET_URL:
                    methodName = "getUrl";
                    f_getUrl(ret, (cWebView) stack.get(ct - 1).var);
                    break;
                case FNC_GET_TITLE:
                    methodName = "getTitle";
                    f_getTitle(ret, (cWebView) stack.get(ct - 1).var);
                    break;
                default:
                    throw new Exception("Unsupported class method:" + nfunc);
            }
        }
        catch(Exception e)
        {
            throw new Exception("> WebView." + methodName + "\n" + e.getMessage());
        }
    }

    private static void f_loadUrl(cWebView webView, cString url)
    {
        ((xWebView)webView.view).loadUrl(url.text());
    }
    private static void f_canGoBack(_Container ret, cWebView wv)
    {
        ret.var = new cBool(((xWebView)wv.view).canGoBack());
    }
    private static void f_canGoForward(_Container ret, cWebView wv)
    {
        ret.var = new cBool(((xWebView)wv.view).canGoForward());
    }
    private static void f_goBack(cWebView wv)
    {
        ((xWebView)wv.view).goBack();
    }
    private static void f_goForward(cWebView wv)
    {
        ((xWebView)wv.view).goForward();
    }
    private static void f_reload(cWebView wv)
    {
        ((xWebView)wv.view).reload();
    }
    private static void f_getUrl(_Container ret, cWebView wv)
    {
        ret.var = new cString(((xWebView)wv.view).getUrl());
    }
    private static void f_getTitle(_Container ret, cWebView wv)
    {
        ret.var = new cString(((xWebView)wv.view).getTitle());
    }
}
