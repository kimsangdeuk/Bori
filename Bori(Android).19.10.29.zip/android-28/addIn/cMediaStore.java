package bori.sangdeuk.imagecapture_fileprovider;

import android.provider.MediaStore;

class cMediaStore extends cVar
{

    cMediaStore()
    {
        super(cType.TMEDIASTORE);
    }

    //-----------------------------------------------------------
    private static final int
    ACTION_IMAGE_CAPTURE = 0, ACTION_IMAGE_CAPTURE_SECURE = 1,
    //ACTION_REVIEW = 2, ACTION_REVIEW_SECURE = 3,
    ACTION_VIDEO_CAPTURE = 4,
    AUTHORITY = 5,
    //EXTRA_BRIGHTNESS = 6,
    EXTRA_DURATION_LIMIT = 7, EXTRA_FINISH_ON_COMPLETION = 8, EXTRA_FULL_SCREEN = 9,
    EXTRA_MEDIA_ALBUM = 10, EXTRA_MEDIA_ARTIST = 11, EXTRA_MEDIA_FOCUS = 12, EXTRA_MEDIA_GENRE = 13, EXTRA_MEDIA_PLAYLIST = 14,
    EXTRA_MEDIA_RADIO_CHANNEL = 15, EXTRA_MEDIA_TITLE = 16, EXTRA_OUTPUT = 17, EXTRA_SCREEN_ORIENTATION = 18, EXTRA_SHOW_ACTION_ICONS = 19,
    EXTRA_SIZE_LIMIT = 20, EXTRA_VIDEO_QUALITY = 21,
    INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH = 22, INTENT_ACTION_MEDIA_SEARCH = 23,
//  INTENT_ACTION_MUSIC_PLAYER = 24,
    INTENT_ACTION_STILL_IMAGE_CAMERA = 25,
    INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE = 26, INTENT_ACTION_TEXT_OPEN_FROM_SEARCH = 27, INTENT_ACTION_VIDEO_CAMERA = 28, INTENT_ACTION_VIDEO_PLAY_FROM_SEARCH = 29,
    MEDIA_IGNORE_FILENAME = 30, MEDIA_SCANNER_VOLUME = 31, META_DATA_STILL_IMAGE_CAMERA_PREWARM_SERVICE = 32,
    UNKNOWN_STRING = 33;
//    VOLUME_EXTERNAL = 34, VOLUME_EXTERNAL_PRIMARY = 35, VOLUME_INTERNAL = 36;
 
    static void getVar(int n, _Container ret, _Container con)
    {
        switch(n)
        {
            case ACTION_IMAGE_CAPTURE: ret.var = new cString(MediaStore.ACTION_IMAGE_CAPTURE); break;
            case ACTION_IMAGE_CAPTURE_SECURE: ret.var = new cString(MediaStore.ACTION_IMAGE_CAPTURE_SECURE); break;
//            case ACTION_REVIEW: ret.var = new cString(MediaStore.ACTION_REVIEW); break;
//            case ACTION_REVIEW_SECURE: ret.var = new cString(MediaStore.ACTION_REVIEW_SECURE); break;
            case ACTION_VIDEO_CAPTURE: ret.var = new cString(MediaStore.ACTION_VIDEO_CAPTURE); break;
            case AUTHORITY: ret.var = new cString(MediaStore.AUTHORITY); break;
//            case EXTRA_BRIGHTNESS: ret.var = new cString(MediaStore.EXTRA_BRIGHTNESS); break;
            case EXTRA_DURATION_LIMIT: ret.var = new cString(MediaStore.EXTRA_DURATION_LIMIT); break;
            case EXTRA_FINISH_ON_COMPLETION: ret.var = new cString(MediaStore.EXTRA_FINISH_ON_COMPLETION); break;
            case EXTRA_FULL_SCREEN: ret.var = new cString(MediaStore.EXTRA_FULL_SCREEN); break;
            case EXTRA_MEDIA_ALBUM: ret.var = new cString(MediaStore.EXTRA_MEDIA_ALBUM); break;
            case EXTRA_MEDIA_ARTIST: ret.var = new cString(MediaStore.EXTRA_MEDIA_ARTIST); break;
            case EXTRA_MEDIA_FOCUS: ret.var = new cString(MediaStore.EXTRA_MEDIA_FOCUS); break;
            case EXTRA_MEDIA_GENRE: ret.var = new cString(MediaStore.EXTRA_MEDIA_GENRE); break;
            case EXTRA_MEDIA_PLAYLIST: ret.var = new cString(MediaStore.EXTRA_MEDIA_PLAYLIST); break;
            case EXTRA_MEDIA_RADIO_CHANNEL: ret.var = new cString(MediaStore.EXTRA_MEDIA_RADIO_CHANNEL); break;
            case EXTRA_MEDIA_TITLE: ret.var = new cString(MediaStore.EXTRA_MEDIA_TITLE); break;
            case EXTRA_OUTPUT: ret.var = new cString(MediaStore.EXTRA_OUTPUT); break;
            case EXTRA_SCREEN_ORIENTATION: ret.var = new cString(MediaStore.EXTRA_SCREEN_ORIENTATION); break;
            case EXTRA_SHOW_ACTION_ICONS: ret.var = new cString(MediaStore.EXTRA_SHOW_ACTION_ICONS); break;
            case EXTRA_SIZE_LIMIT: ret.var = new cString(MediaStore.EXTRA_SIZE_LIMIT); break;
            case EXTRA_VIDEO_QUALITY: ret.var = new cString(MediaStore.EXTRA_VIDEO_QUALITY); break;
            case INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH: ret.var = new cString(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH); break;
            case INTENT_ACTION_MEDIA_SEARCH: ret.var = new cString(MediaStore.INTENT_ACTION_MEDIA_SEARCH); break;
//            case INTENT_ACTION_MUSIC_PLAYER: ret.var = new cString(MediaStore.INTENT_ACTION_MUSIC_PLAYER); break;
            case INTENT_ACTION_STILL_IMAGE_CAMERA: ret.var = new cString(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA); break;
            case INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE: ret.var = new cString(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE); break;
            case INTENT_ACTION_TEXT_OPEN_FROM_SEARCH: ret.var = new cString(MediaStore.INTENT_ACTION_TEXT_OPEN_FROM_SEARCH); break;
            case INTENT_ACTION_VIDEO_CAMERA: ret.var = new cString(MediaStore.INTENT_ACTION_VIDEO_CAMERA); break;
            case INTENT_ACTION_VIDEO_PLAY_FROM_SEARCH: ret.var = new cString(MediaStore.INTENT_ACTION_VIDEO_PLAY_FROM_SEARCH); break;
            case MEDIA_IGNORE_FILENAME: ret.var = new cString(MediaStore.MEDIA_IGNORE_FILENAME); break;
            case MEDIA_SCANNER_VOLUME: ret.var = new cString(MediaStore.MEDIA_SCANNER_VOLUME); break;
            case META_DATA_STILL_IMAGE_CAMERA_PREWARM_SERVICE: ret.var = new cString(MediaStore.META_DATA_STILL_IMAGE_CAMERA_PREWARM_SERVICE); break;
            case UNKNOWN_STRING: ret.var = new cString(MediaStore.UNKNOWN_STRING); break;
//            case VOLUME_EXTERNAL: ret.var = new cString(MediaStore.VOLUME_EXTERNAL); break;
//            case VOLUME_EXTERNAL_PRIMARY: ret.var = new cString(MediaStore.VOLUME_EXTERNAL_PRIMARY); break;
//            case VOLUME_INTERNAL: ret.var = new cString(MediaStore.VOLUME_INTERNAL); break;
        }
    }

}
